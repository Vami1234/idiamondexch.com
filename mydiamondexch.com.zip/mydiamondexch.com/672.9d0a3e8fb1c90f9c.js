"use strict";
(self.webpackChunkuser = self.webpackChunkuser || []).push([
    [672], {
        8672: (X, b, p) => {
            p.r(b), p.d(b, {
                AuthModule: () => W
            });
            var g = p(6814),
                u = p(7133),
                s = p(95),
                _ = p(3760),
                t = p(5879),
                f = p(9229),
                m = p(3805),
                d = p(2614);

            function x(n, a) {
                if (1 & n && (t.TgZ(0, "div", 3)(1, "div", 1), t._UZ(2, "img", 4), t.qZA(), t.TgZ(3, "div", 5), t.O4$(), t.TgZ(4, "svg", 6), t._UZ(5, "use", 7), t.qZA()()()), 2 & n) {
                    const i = t.oxw();
                    t.xp6(2), t.Q6J("src", i.logoD, t.LSH)
                }
            }
            let C = (() => {
                var n;
                class a {
                    constructor(o, e) {
                        this._service = o, this._sharedService = e, this.isLoading = !0, this.baseUrl = this._service.BASE_IMAGE_URL
                    }
                    ngAfterViewInit() {
                        this.getGlobalSetting()
                    }
                    getGlobalSetting() {
                        this._service.get("globalSetting/getGlobalSetting").subscribe({
                            next: o => {
                                if (o.status) {
                                    this.isLoading = !1, this.globalSetting = o ? .data, this._sharedService.getGlobalDataUser = o.data;
                                    var e = document.body.style;
                                    if (e.setProperty("--bg-primary", o.data.bg_primary_color), e.setProperty("--bg-secondary", o.data.bg_secondry_color), e.setProperty("--text-primary", o.data.text_primary_color), e.setProperty("--text-secondary", o.data.text_secondry_color), e.setProperty("--bg-other", o.data.other_color), this._sharedService.setGlobalData(this.globalSetting), this._service.userLoginData.next(this.globalSetting), document.title = null != o.data.site_title && null != o.data.site_title && "" != o.data.site_title ? o.data.site_title : window.location.hostname, this.globalSetting ? .favicon) {
                                        let r = window.location.origin + "/api/upload/image/" + this.globalSetting ? .favicon;
                                        this._service.changeFavicon(r)
                                    }
                                    this.logoD = `${this._service.logoUrl}${this.baseUrl}api/upload/image/` + o ? .data ? .logo
                                }
                            },
                            error: o => {
                                this.isLoading = !1
                            },
                            complete: () => {}
                        })
                    }
                }
                return (n = a).\u0275fac = function(o) {
                    return new(o || n)(t.Y36(m.s), t.Y36(d.F))
                }, n.\u0275cmp = t.Xpm({
                    type: n,
                    selectors: [
                        ["app-logo"]
                    ],
                    decls: 3,
                    vars: 2,
                    consts: [
                        ["class", "load-inner", 4, "ngIf"],
                        [1, "logo-login"],
                        ["alt", "", 3, "src"],
                        [1, "load-inner"],
                        [3, "src"],
                        [1, "icon-loader"],
                        [1, "icon", "fa-spin"],
                        [0, "xlink", "href", "#spiner"]
                    ],
                    template: function(o, e) {
                        1 & o && (t.YNc(0, x, 6, 1, "div", 0), t.TgZ(1, "div", 1), t._UZ(2, "img", 2), t.qZA()), 2 & o && (t.Q6J("ngIf", e.isLoading), t.xp6(2), t.Q6J("src", e.logoD, t.LSH))
                    },
                    dependencies: [g.O5],
                    styles: [".d-block[_ngcontent-%COMP%]{display:block!important}.d-none[_ngcontent-%COMP%]{display:none!important}"]
                }), a
            })();

            function w(n, a) {
                if (1 & n) {
                    const i = t.EpF();
                    t.TgZ(0, "div", 2)(1, "button", 3), t.NdJ("click", function() {
                        t.CHM(i);
                        const e = t.oxw();
                        return t.KtG(e.onSignUp())
                    }), t._uU(2, "Signup "), t.O4$(), t.TgZ(3, "svg", 4), t._UZ(4, "use", 5), t.qZA()()()
                }
            }

            function S(n, a) {
                1 & n && (t.TgZ(0, "div", 6)(1, "button", 7), t._uU(2, "Download Apk "), t.O4$(), t.TgZ(3, "svg", 4), t._UZ(4, "use", 5), t.qZA()()())
            }

            function T(n, a) {
                if (1 & n && (t.TgZ(0, "div", 2)(1, "p", 8)(2, "a", 9), t._uU(3), t.qZA()()()), 2 & n) {
                    const i = t.oxw();
                    t.xp6(2), t.MGl("href", "mailto:", i.siteEmail, "", t.LSH), t.xp6(1), t.hij(" ", i.siteEmail, " ")
                }
            }
            let U = (() => {
                var n;
                class a {
                    constructor(o, e, r) {
                        this._service = o, this._sharedService = e, this.route = r, this.isLoading = !0, this.isSignUp = "0", this.isApk = "0", this.isMailId = "0", this.baseUrl = this._service.BASE_IMAGE_URL
                    }
                    getGlobalSetting() {
                        this._service.get("globalSetting/getGlobalSetting").subscribe({
                            next: o => {
                                o.status && (this.isLoading = !1, this.globalSetting = o ? .data, this.isSignUp = o ? .data ? .sign_up || "0", this.isApk = o ? .data ? .is_show_apk || "0", this.isMailId = o ? .data ? .is_show_email || "0", this.siteEmail = o ? .data ? .email)
                            },
                            error: o => {
                                this.isLoading = !1
                            },
                            complete: () => {}
                        })
                    }
                    ngAfterViewInit() {
                        this._service.userLoginData.subscribe(o => {
                            this.globalSetting = o, this.isSignUp = this.globalSetting ? .sign_up || "0", this.isApk = this.globalSetting ? .is_show_apk || "0", this.isMailId = this.globalSetting ? .is_show_email || "0", this.siteEmail = this.globalSetting ? .email
                        })
                    }
                    onSignUp() {
                        this.route.navigate(["/auth/sign-up"])
                    }
                }
                return (n = a).\u0275fac = function(o) {
                    return new(o || n)(t.Y36(m.s), t.Y36(d.F), t.Y36(u.F0))
                }, n.\u0275cmp = t.Xpm({
                    type: n,
                    selectors: [
                        ["app-login-btn"]
                    ],
                    decls: 3,
                    vars: 3,
                    consts: [
                        ["class", "d-grid", 4, "ngIf"],
                        ["class", "d-grid mt-3", 4, "ngIf"],
                        [1, "d-grid"],
                        ["type", "button", 1, "btn", "btn-primary", "btn-block", 3, "click"],
                        [1, "icon", "float-end"],
                        [0, "xlink", "href", "#signin"],
                        [1, "d-grid", "mt-3"],
                        ["type", "button", 1, "btn", "btn-primary", "btn-block"],
                        [1, "mt-1", "text-center", "mb-0"],
                        [1, "mail-link", 3, "href"]
                    ],
                    template: function(o, e) {
                        1 & o && (t.YNc(0, w, 5, 0, "div", 0), t.YNc(1, S, 5, 0, "div", 1), t.YNc(2, T, 4, 2, "div", 0)), 2 & o && (t.Q6J("ngIf", "1" == e.isSignUp), t.xp6(1), t.Q6J("ngIf", "1" == e.isApk), t.xp6(1), t.Q6J("ngIf", "1" == e.isMailId))
                    },
                    dependencies: [g.O5],
                    styles: [".d-block[_ngcontent-%COMP%]{display:block!important}.d-none[_ngcontent-%COMP%]{display:none!important}"]
                }), a
            })();

            function y(n, a) {
                if (1 & n && (t.O4$(), t.kcU(), t.TgZ(0, "div", 36)(1, "ul")(2, "li"), t._uU(3), t.qZA()()()), 2 & n) {
                    const i = t.oxw();
                    t.xp6(3), t.hij(" ", i.errorMessage, "")
                }
            }
            let Z = (() => {
                var n;
                class a {
                    constructor(o, e, r, l, c, h, v) {
                        this.renderer = o, this.fb = e, this.location = r, this.route = l, this.toaster = c, this._service = h, this._sharedService = v, this.user = new _.n, this.isError = !1, this.errorMessage = "", this.isSignUp = "0", this.isApk = "0", this.isMailId = "0", this.isLoading = !0, this.isLoadingLogin = !1, this.cacheBust = Date.now(), this.baseUrl = this._service.BASE_IMAGE_URL, this.loginForm = this.fb.group({
                            user_name: new s.NI(""),
                            password: new s.NI(""),
                            location: new s.NI("")
                        }), this._sharedService.isLoggedIn() && this._sharedService.getData() && this.route.navigate(["/home"])
                    }
                    ngOnInit() {
                        $("body").removeClass("modal-open"), $(".modal-backdrop").remove()
                    }
                    receiveDataFromChild(o) {
                        this.receivedDataFromChild = o
                    }
                    ngAfterViewInit() {}
                    Login(o) {
                        if (this.loginForm.invalid) return void this.loginForm.markAllAsTouched();
                        let e = {
                            user_name: this.loginForm.controls.user_name.value,
                            password: this.loginForm.controls.password.value,
                            location: this.loginForm.controls.location.value
                        };
                        this.isError = !1, this.isLoadingLogin = !0, this._service.post("user/login", e).subscribe(r => {
                            this.isLoadingLogin = !1, r.status && 7 == r.data.user_type_id ? r.status && "0" == r.data.is_telegram_enabled ? (new _.n, this._sharedService.setopenWelcomePopup("true"), this._sharedService.setData(r.data), this._sharedService.setlogedIn("true"), this._sharedService.setToken(r.data.token.toString()), this.route.navigate("0" == r ? .data ? .is_change_password ? ["/home"] : ["/setting/change-password"])) : (new _.n, this._sharedService.setData(r.data), this._sharedService.setlogedIn("true"), this._sharedService.setToken(r.data.token.toString()), this._sharedService.setuserId(r.data.user_id), this.route.navigate(["/auth/otp"])) : (this.isError = !0, this.isLoadingLogin = !1, this.screenWidth = this._sharedService.getInnerWidth(), this.screenWidth < 992 ? this.toaster.error(r.message.toString()) : this.errorMessage = r.message.toString())
                        })
                    }
                }
                return (n = a).\u0275fac = function(o) {
                    return new(o || n)(t.Y36(t.Qsj), t.Y36(s.qu), t.Y36(g.Ye), t.Y36(u.F0), t.Y36(f._W), t.Y36(m.s), t.Y36(d.F))
                }, n.\u0275cmp = t.Xpm({
                    type: n,
                    selectors: [
                        ["app-login"]
                    ],
                    decls: 48,
                    vars: 5,
                    consts: [
                        [1, "login-page"],
                        [3, "childDataEvent"],
                        [1, "login-box"],
                        [1, "login-form", "mt-xl-4", "mt-3"],
                        [1, "text-center", "login-title"],
                        [1, "icon"],
                        [0, "xlink", "href", "#thumbdown"],
                        ["role", "", "class", "alert alert-danger d-lg-block d-xl-block d-none ", 4, "ngIf"],
                        [3, "formGroup", "ngSubmit"],
                        [1, "input-group", "position-relative"],
                        ["name", "username", "type", "text", "placeholder", "User Name", "formControlName", "user_name", 1, "form-control", "d-xl-block", "d-none"],
                        ["name", "username", "type", "text", "placeholder", "Username", "formControlName", "user_name", 1, "form-control", "d-xl-none", "d-block"],
                        [1, "icon-from"],
                        [0, "xlink", "href", "#user"],
                        ["name", "password", "type", "password", "placeholder", "Password", "formControlName", "password", 1, "form-control"],
                        [0, "xlink", "href", "#key"],
                        [1, "d-grid"],
                        ["type", "submit"],
                        [1, "icon", "f-sign", "float-end"],
                        [0, "xlink", "href", "#signin"],
                        [1, "icon", "f-spin"],
                        [0, "xlink", "href", "#spiner"],
                        [1, "recaptchaTerms", "mt-1", "mb-2"],
                        ["href", "https://policies.google.com/privacy"],
                        ["href", "https://policies.google.com/terms"],
                        ["xmlns", "http://www.w3.org/2000/svg", 2, "display", "none"],
                        ["id", "thumbdown", "viewBox", "0 0 384 512"],
                        ["d", "M91.826 467.2V317.966c-8.248 5.841-16.558 10.57-24.918 14.153C35.098 345.752-.014 322.222 0 288c.008-18.616 10.897-32.203 29.092-40 28.286-12.122 64.329-78.648 77.323-107.534 7.956-17.857 25.479-28.453 43.845-28.464l.001-.002h171.526c11.812 0 21.897 8.596 23.703 20.269 7.25 46.837 38.483 61.76 38.315 123.731-.007 2.724.195 13.254.195 16 0 50.654-22.122 81.574-71.263 72.6-9.297 18.597-39.486 30.738-62.315 16.45-21.177 24.645-53.896 22.639-70.944 6.299V467.2c0 24.15-20.201 44.8-43.826 44.8-23.283 0-43.826-21.35-43.826-44.8zM112 72V24c0-13.255 10.745-24 24-24h192c13.255 0 24 10.745 24 24v48c0 13.255-10.745 24-24 24H136c-13.255 0-24-10.745-24-24zm212-24c0-11.046-8.954-20-20-20s-20 8.954-20 20 8.954 20 20 20 20-8.954 20-20z"],
                        ["id", "user", "viewBox", "0 0 512 512"],
                        ["d", "M256 288c79.5 0 144-64.5 144-144S335.5 0 256 0 112 64.5 112 144s64.5 144 144 144zm128 32h-55.1c-22.2 10.2-46.9 16-72.9 16s-50.6-5.8-72.9-16H128C57.3 320 0 377.3 0 448v16c0 26.5 21.5 48 48 48h416c26.5 0 48-21.5 48-48v-16c0-70.7-57.3-128-128-128z"],
                        ["id", "key", "viewBox", "0 0 512 512"],
                        ["d", "M512 176.001C512 273.203 433.202 352 336 352c-11.22 0-22.19-1.062-32.827-3.069l-24.012 27.014A23.999 23.999 0 0 1 261.223 384H224v40c0 13.255-10.745 24-24 24h-40v40c0 13.255-10.745 24-24 24H24c-13.255 0-24-10.745-24-24v-78.059c0-6.365 2.529-12.47 7.029-16.971l161.802-161.802C163.108 213.814 160 195.271 160 176 160 78.798 238.797.001 335.999 0 433.488-.001 512 78.511 512 176.001zM336 128c0 26.51 21.49 48 48 48s48-21.49 48-48-21.49-48-48-48-48 21.49-48 48z"],
                        ["id", "signin", "viewBox", "0 0 512 512"],
                        ["d", "M416 448h-84c-6.6 0-12-5.4-12-12v-40c0-6.6 5.4-12 12-12h84c17.7 0 32-14.3 32-32V160c0-17.7-14.3-32-32-32h-84c-6.6 0-12-5.4-12-12V76c0-6.6 5.4-12 12-12h84c53 0 96 43 96 96v192c0 53-43 96-96 96zm-47-201L201 79c-15-15-41-4.5-41 17v96H24c-13.3 0-24 10.7-24 24v96c0 13.3 10.7 24 24 24h136v96c0 21.5 26 32 41 17l168-168c9.3-9.4 9.3-24.6 0-34z"],
                        ["id", "spiner", "viewBox", "0 0 512 512"],
                        ["d", "M304 48c0 26.51-21.49 48-48 48s-48-21.49-48-48 21.49-48 48-48 48 21.49 48 48zm-48 368c-26.51 0-48 21.49-48 48s21.49 48 48 48 48-21.49 48-48-21.49-48-48-48zm208-208c-26.51 0-48 21.49-48 48s21.49 48 48 48 48-21.49 48-48-21.49-48-48-48zM96 256c0-26.51-21.49-48-48-48S0 229.49 0 256s21.49 48 48 48 48-21.49 48-48zm12.922 99.078c-26.51 0-48 21.49-48 48s21.49 48 48 48 48-21.49 48-48c0-26.509-21.491-48-48-48zm294.156 0c-26.51 0-48 21.49-48 48s21.49 48 48 48 48-21.49 48-48c0-26.509-21.49-48-48-48zM108.922 60.922c-26.51 0-48 21.49-48 48s21.49 48 48 48 48-21.49 48-48-21.491-48-48-48z"],
                        ["role", "", 1, "alert", "alert-danger", "d-lg-block", "d-xl-block", "d-none"]
                    ],
                    template: function(o, e) {
                        1 & o && (t.TgZ(0, "div", 0)(1, "app-logo", 1), t.NdJ("childDataEvent", function(l) {
                            return e.receiveDataFromChild(l)
                        }), t.qZA(), t.TgZ(2, "div", 2)(3, "div", 3)(4, "h4", 4), t._uU(5, "LOGIN"), t.O4$(), t.TgZ(6, "svg", 5), t._UZ(7, "use", 6), t.qZA()(), t.YNc(8, y, 4, 1, "div", 7), t.kcU(), t.TgZ(9, "form", 8), t.NdJ("ngSubmit", function() {
                            return e.Login(e.loginForm.value)
                        }), t.TgZ(10, "div", 9), t._UZ(11, "input", 10)(12, "input", 11), t.TgZ(13, "span", 12), t.O4$(), t.TgZ(14, "svg", 5), t._UZ(15, "use", 13), t.qZA()()(), t.kcU(), t.TgZ(16, "div", 9), t._UZ(17, "input", 14), t.TgZ(18, "span", 12), t.O4$(), t.TgZ(19, "svg", 5), t._UZ(20, "use", 15), t.qZA()()(), t.kcU(), t.TgZ(21, "div", 16)(22, "button", 17), t._uU(23, "Login "), t.O4$(), t.TgZ(24, "svg", 18), t._UZ(25, "use", 19), t.qZA(), t.TgZ(26, "svg", 20), t._UZ(27, "use", 21), t.qZA()()(), t.kcU(), t.TgZ(28, "small", 22), t._uU(29, "This site is protected by reCAPTCHA and the Google"), t.TgZ(30, "a", 23), t._uU(31, "Privacy Policy"), t.qZA(), t._uU(32, " and"), t.TgZ(33, "a", 24), t._uU(34, "Terms of Service"), t.qZA(), t._uU(35, " apply. "), t.qZA(), t._UZ(36, "app-login-btn"), t.qZA()()()(), t.O4$(), t.TgZ(37, "svg", 25)(38, "symbol", 26), t._UZ(39, "path", 27), t.qZA(), t.TgZ(40, "symbol", 28), t._UZ(41, "path", 29), t.qZA(), t.TgZ(42, "symbol", 30), t._UZ(43, "path", 31), t.qZA(), t.TgZ(44, "symbol", 32), t._UZ(45, "path", 33), t.qZA(), t.TgZ(46, "symbol", 34), t._UZ(47, "path", 35), t.qZA()()), 2 & o && (t.xp6(8), t.Q6J("ngIf", e.isError), t.xp6(1), t.Q6J("formGroup", e.loginForm), t.xp6(13), t.Gre("btn btn-primary btn-block ", 1 == e.isLoadingLogin ? "login-btn-loader" : "", " "))
                    },
                    dependencies: [g.O5, s._Y, s.Fj, s.JJ, s.JL, s.sg, s.u, C, U],
                    styles: [".alert-danger[_ngcontent-%COMP%]{padding:9px 13px;line-height:18px;margin-top:10px;text-align:left}dl[_ngcontent-%COMP%], ol[_ngcontent-%COMP%], ul[_ngcontent-%COMP%], li[_ngcontent-%COMP%]{margin-top:0;margin-bottom:1rem;list-style:none;padding:0;margin:0!important}"]
                }), a
            })();
            var k = p(8512);

            function A(n, a) {
                if (1 & n && (t.TgZ(0, "div", 27)(1, "ul")(2, "li"), t._uU(3), t.qZA()()()), 2 & n) {
                    const i = t.oxw();
                    t.xp6(3), t.Oqu(i.errorMessage)
                }
            }

            function O(n, a) {
                1 & n && (t.TgZ(0, "span", 29), t._uU(1, " Please enter name "), t.qZA())
            }

            function I(n, a) {
                if (1 & n && (t.O4$(), t.kcU(), t.TgZ(0, "span", 28), t.YNc(1, O, 2, 0, "span", 16), t.qZA()), 2 & n) {
                    const i = t.oxw();
                    t.xp6(1), t.Q6J("ngIf", null == i.signupForm.controls.name.errors ? null : i.signupForm.controls.name.errors.required)
                }
            }

            function F(n, a) {
                1 & n && (t.TgZ(0, "span", 29), t._uU(1, " Please enter username "), t.qZA())
            }

            function M(n, a) {
                1 & n && (t.TgZ(0, "span", 31), t._uU(1, " minimum four characters required , Space and special characters are not allowed "), t.qZA())
            }

            function L(n, a) {
                if (1 & n && (t.O4$(), t.kcU(), t.TgZ(0, "span", 28), t.YNc(1, F, 2, 0, "span", 16), t.YNc(2, M, 2, 0, "span", 30), t.qZA()), 2 & n) {
                    const i = t.oxw();
                    t.xp6(1), t.Q6J("ngIf", null == i.signupForm.controls.user_name.errors ? null : i.signupForm.controls.user_name.errors.required), t.xp6(1), t.Q6J("ngIf", null == i.signupForm.controls.user_name.errors ? null : i.signupForm.controls.user_name.errors.pattern)
                }
            }

            function q(n, a) {
                1 & n && (t.O4$(), t.kcU(), t.TgZ(0, "span", 29), t._uU(1, "Usermane already taken"), t.qZA())
            }

            function P(n, a) {
                1 & n && (t.TgZ(0, "span", 29), t._uU(1, " Please enter mobile "), t.qZA())
            }

            function N(n, a) {
                if (1 & n && (t.O4$(), t.kcU(), t.TgZ(0, "span", 28), t.YNc(1, P, 2, 0, "span", 16), t.qZA()), 2 & n) {
                    const i = t.oxw();
                    t.xp6(1), t.Q6J("ngIf", null == i.signupForm.controls.mobile.errors ? null : i.signupForm.controls.mobile.errors.required)
                }
            }

            function Y(n, a) {
                1 & n && (t.TgZ(0, "span", 29), t._uU(1, " Please enter password "), t.qZA())
            }

            function J(n, a) {
                1 & n && (t.TgZ(0, "span", 29), t._uU(1, " Password Minimum eight characters, at least one letter and one number! "), t.qZA())
            }

            function E(n, a) {
                if (1 & n && (t.O4$(), t.kcU(), t.TgZ(0, "span", 28), t.YNc(1, Y, 2, 0, "span", 16), t.YNc(2, J, 2, 0, "span", 16), t.qZA()), 2 & n) {
                    const i = t.oxw();
                    t.xp6(1), t.Q6J("ngIf", null == i.signupForm.controls.password.errors ? null : i.signupForm.controls.password.errors.required), t.xp6(1), t.Q6J("ngIf", null == i.signupForm.controls.password.errors ? null : i.signupForm.controls.password.errors.pattern)
                }
            }

            function G(n, a) {
                1 & n && (t.TgZ(0, "span", 29), t._uU(1, " Please enter confirm password "), t.qZA())
            }

            function Q(n, a) {
                1 & n && (t.TgZ(0, "span", 29), t._uU(1, " Confirm Password does not match "), t.qZA())
            }

            function B(n, a) {
                if (1 & n && (t.O4$(), t.kcU(), t.TgZ(0, "span", 28), t.YNc(1, G, 2, 0, "span", 16), t.YNc(2, Q, 2, 0, "span", 16), t.qZA()), 2 & n) {
                    const i = t.oxw();
                    t.xp6(1), t.Q6J("ngIf", null == i.signupForm.controls.confirm_password.errors ? null : i.signupForm.controls.confirm_password.errors.required), t.xp6(1), t.Q6J("ngIf", null == i.signupForm.controls.confirm_password.errors ? null : i.signupForm.controls.confirm_password.errors.matching)
                }
            }
            let D = (() => {
                var n;
                class a {
                    constructor(o, e, r, l, c, h) {
                        this.renderer = o, this.fb = e, this.route = r, this.toaster = l, this._service = c, this._sharedService = h, this.user = new _.n, this.isError = !1, this.errorMessage = "", this.isSignUp = "0", this.isApk = "0", this.isMailId = "0", this.isLoading = !0, this.flagExits = !1, this.userNameRegex = new RegExp("^[a-z0-9_-]{4,15}$"), this.baseUrl = this._service.BASE_IMAGE_URL, this.getGlobalSetting(), this.signupForm = this.fb.group({
                            user_name: ["", [s.kI.required, s.kI.pattern(this.userNameRegex)]],
                            name: new s.NI("", s.kI.required),
                            mobile: new s.NI("", s.kI.required),
                            password: ["", [s.kI.required, s.kI.pattern(/^(?=.*[A-Za-z])(?=.*\d)[A-Za-z\d@$!%*#?&]{8,}$/)]],
                            confirm_password: new s.NI("", s.kI.required)
                        }, {
                            validators: [k.Z.match("password", "confirm_password")]
                        }), this._sharedService.isLoggedIn() && this._sharedService.getData() && this.route.navigate(["/home"])
                    }
                    gotoLogin() {
                        this.route.navigate(["/auth/login"])
                    }
                    ngOnInit() {}
                    Register(o) {
                        if (this.signupForm.invalid) return void this.signupForm.markAllAsTouched();
                        if (this.flagExits) return;
                        let e = {
                            user_name: this.signupForm.controls.user_name.value,
                            password: this.signupForm.controls.password.value,
                            name: this.signupForm.controls.name.value,
                            mobile: this.signupForm.controls.mobile.value
                        };
                        this.isError = !1, this._service.post("user/signup", e).subscribe(r => {
                            r.status ? this.route.navigate(["/auth/login"]) : (this.isError = !0, this.errorMessage = r.message.toString())
                        })
                    }
                    getGlobalSetting() {
                        this._service.get("globalSetting/getGlobalSetting").subscribe({
                            next: e => {
                                e.status && (this.globalSetting = e ? .data, this.isSignUp = e ? .data ? .sign_up || "0", this.isApk = e ? .data ? .is_show_apk || "0", this.isMailId = e ? .data ? .is_show_email || "0", this.siteEmail = e ? .data ? .email, this.logoD = `${this._service.logoUrl}${this.baseUrl}api/upload/image/` + e ? .data ? .logo)
                            },
                            error: e => {},
                            complete: () => {}
                        })
                    }
                    checkUserExist() {
                        this.signupForm.controls.user_name.value && this._service.post("user/checkUserNameExist", {
                            user_name: this.signupForm.controls.user_name.value
                        }).subscribe(e => {
                            this.flagExits = !e ? .status
                        })
                    }
                }
                return (n = a).\u0275fac = function(o) {
                    return new(o || n)(t.Y36(t.Qsj), t.Y36(s.qu), t.Y36(u.F0), t.Y36(f._W), t.Y36(m.s), t.Y36(d.F))
                }, n.\u0275cmp = t.Xpm({
                    type: n,
                    selectors: [
                        ["app-signup"]
                    ],
                    decls: 51,
                    vars: 9,
                    consts: [
                        [1, "login-page"],
                        [1, "login-box"],
                        [1, "logo-login"],
                        ["alt", "", 3, "src"],
                        [1, "login-form", "mt-4"],
                        [1, "text-center", "login-title"],
                        [1, "fas", "fa-hand-point-down"],
                        ["role", "", "class", "alert alert-danger", 4, "ngIf"],
                        [3, "formGroup", "ngSubmit"],
                        [1, "input-group", "position-relative"],
                        ["name", "name", "type", "text", "placeholder", "name", "formControlName", "name", 1, "form-control"],
                        [1, "icon-from"],
                        [1, "icon"],
                        [0, "xlink", "href", "#user"],
                        ["class", "", 4, "ngIf"],
                        ["name", "username", "type", "text", "placeholder", "Username", "formControlName", "user_name", 1, "form-control", 3, "focusout", "input"],
                        ["class", "text-danger", 4, "ngIf"],
                        ["name", "mobile", "type", "text", "placeholder", "mobile", "formControlName", "mobile", 1, "form-control"],
                        [0, "xlink", "href", "#phone"],
                        ["name", "password", "type", "password", "placeholder", "Password", "formControlName", "password", 1, "form-control"],
                        [0, "xlink", "href", "#key"],
                        ["name", "confirm_password", "type", "password", "placeholder", "Confirm Password", "formControlName", "confirm_password", 1, "form-control"],
                        [1, "d-grid"],
                        ["type", "submit", 1, "btn", "btn-primary", "btn-block"],
                        [1, "icon", "float-end"],
                        [0, "xlink", "href", "#signin"],
                        ["type", "button", 1, "btn", "btn-primary", "btn-block", "my-3", 3, "click"],
                        ["role", "", 1, "alert", "alert-danger"],
                        [1, ""],
                        [1, "text-danger"],
                        ["style", "margin: 0px", "class", "text-danger", 4, "ngIf"],
                        [1, "text-danger", 2, "margin", "0px"]
                    ],
                    template: function(o, e) {
                        1 & o && (t.TgZ(0, "div", 0)(1, "div", 1)(2, "div", 2), t._UZ(3, "img", 3), t.qZA(), t.TgZ(4, "div", 4)(5, "h4", 5), t._uU(6, " SIGN UP "), t._UZ(7, "i", 6), t.qZA(), t.YNc(8, A, 4, 1, "div", 7), t.TgZ(9, "form", 8), t.NdJ("ngSubmit", function() {
                            return e.Register(e.signupForm.value)
                        }), t.TgZ(10, "div", 9), t._UZ(11, "input", 10), t.TgZ(12, "span", 11), t.O4$(), t.TgZ(13, "svg", 12), t._UZ(14, "use", 13), t.qZA()(), t.YNc(15, I, 2, 1, "span", 14), t.qZA(), t.kcU(), t.TgZ(16, "div", 9)(17, "input", 15), t.NdJ("focusout", function() {
                            return e.checkUserExist()
                        })("input", function() {
                            return e.flagExits = !1
                        }), t.qZA(), t.TgZ(18, "span", 11), t.O4$(), t.TgZ(19, "svg", 12), t._UZ(20, "use", 13), t.qZA()(), t.YNc(21, L, 3, 2, "span", 14), t.YNc(22, q, 2, 0, "span", 16), t.qZA(), t.kcU(), t.TgZ(23, "div", 9), t._UZ(24, "input", 17), t.TgZ(25, "span", 11), t.O4$(), t.TgZ(26, "svg", 12), t._UZ(27, "use", 18), t.qZA()(), t.YNc(28, N, 2, 1, "span", 14), t.qZA(), t.kcU(), t.TgZ(29, "div", 9), t._UZ(30, "input", 19), t.TgZ(31, "span", 11), t.O4$(), t.TgZ(32, "svg", 12), t._UZ(33, "use", 20), t.qZA()(), t.YNc(34, E, 3, 2, "span", 14), t.qZA(), t.kcU(), t.TgZ(35, "div", 9), t._UZ(36, "input", 21), t.TgZ(37, "span", 11), t.O4$(), t.TgZ(38, "svg", 12), t._UZ(39, "use", 20), t.qZA()(), t.YNc(40, B, 3, 2, "span", 14), t.qZA(), t.kcU(), t.TgZ(41, "div", 22)(42, "button", 23), t._uU(43, " Signup "), t.O4$(), t.TgZ(44, "svg", 24), t._UZ(45, "use", 25), t.qZA()()(), t.kcU(), t.TgZ(46, "div", 22)(47, "button", 26), t.NdJ("click", function() {
                            return e.gotoLogin()
                        }), t._uU(48, " Back to Login "), t.O4$(), t.TgZ(49, "svg", 24), t._UZ(50, "use", 25), t.qZA()()()()()()()), 2 & o && (t.xp6(3), t.Q6J("src", e.logoD, t.LSH), t.xp6(5), t.Q6J("ngIf", e.isError), t.xp6(1), t.Q6J("formGroup", e.signupForm), t.xp6(6), t.Q6J("ngIf", e.signupForm.controls.name.invalid && (e.signupForm.controls.name.dirty || e.signupForm.controls.name.touched)), t.xp6(6), t.Q6J("ngIf", e.signupForm.controls.user_name.invalid && (e.signupForm.controls.user_name.dirty || e.signupForm.controls.user_name.touched)), t.xp6(1), t.Q6J("ngIf", e.flagExits), t.xp6(6), t.Q6J("ngIf", e.signupForm.controls.mobile.invalid && (e.signupForm.controls.mobile.dirty || e.signupForm.controls.mobile.touched)), t.xp6(6), t.Q6J("ngIf", e.signupForm.controls.password.invalid && (e.signupForm.controls.password.dirty || e.signupForm.controls.password.touched)), t.xp6(6), t.Q6J("ngIf", e.signupForm.controls.confirm_password.invalid && (e.signupForm.controls.confirm_password.dirty || e.signupForm.controls.confirm_password.touched)))
                    },
                    dependencies: [g.O5, s._Y, s.Fj, s.JJ, s.JL, s.sg, s.u],
                    styles: [".d-block[_ngcontent-%COMP%]{display:block!important}.d-none[_ngcontent-%COMP%]{display:none!important}"]
                }), a
            })();
            var z = p(4182);
            const R = ["formRow"];

            function H(n, a) {
                if (1 & n) {
                    const i = t.EpF();
                    t.TgZ(0, "div", 11)(1, "input", 12, 13), t.NdJ("keyup", function(e) {
                        const l = t.CHM(i).index,
                            c = t.oxw();
                        return t.KtG(c.keyUpEvent(e, l))
                    }), t.qZA()()
                }
                if (2 & n) {
                    const i = a.$implicit;
                    t.xp6(1), t.s9C("formControlName", i)
                }
            }
            const j = [{
                path: "",
                redirectTo: "login",
                pathMatch: "full"
            }, {
                path: "",
                component: Z
            }, {
                path: "login",
                component: Z
            }, {
                path: "sign-up",
                component: D
            }, {
                path: "otp",
                component: (() => {
                    var n;
                    class a {
                        constructor(o, e, r, l, c, h, v) {
                            this.renderer = o, this.fb = e, this.authService = r, this.route = l, this.toaster = c, this._service = h, this._sharedService = v, this.formInput = ["input1", "input2", "input3", "input4", "input5", "input6"], this.cacheBust = Date.now(), this.baseUrl = this._service.BASE_IMAGE_URL, this.isSignUp = "0", this.showOtpComponent = !0, this.config = {
                                allowNumbersOnly: !1,
                                length: 6,
                                isPasswordInput: !1,
                                disableAutoFocus: !1,
                                placeholder: "",
                                inputStyles: {
                                    width: "50px",
                                    height: "50px"
                                }
                            }, this.form = this.toFormGroup(this.formInput)
                        }
                        onOtpChange() {
                            if (this.otp = this.form.value.input1.toString() + this.form.value.input2.toString() + this.form.value.input3.toString() + this.form.value.input4.toString() + this.form.value.input5.toString() + this.form.value.input6.toString(), 6 == this.otp.length) {
                                let o = {
                                    user_id: +this.userId,
                                    otp: this.otp.toString()
                                };
                                this._service.post("telegram/verifyLoginOtp", o).subscribe(e => {
                                    e.status ? this.route.navigate(["/home"]) : (this.showOtpComponent = !1, this.otp = null, setTimeout(() => {
                                        this.showOtpComponent = !0
                                    }, 0), this.toaster.error(e.message.toString()))
                                })
                            }
                        }
                        ngOnInit() {
                            this.userId = this._sharedService.getUserId(), this._service.get("globalSetting/getGlobalSetting").subscribe(o => {
                                o.status && (this.logo = `${this._service.logoUrl}${this.baseUrl}api/upload/image/` + o ? .data ? .logo)
                            }), this.loginForm = this.fb.group({
                                otp1: new s.NI("", s.kI.required),
                                otp2: new s.NI("", s.kI.required),
                                otp3: new s.NI("", s.kI.required),
                                otp4: new s.NI("", s.kI.required),
                                otp5: new s.NI("", s.kI.required),
                                otp6: new s.NI("", s.kI.required)
                            })
                        }
                        Login(o) {
                            if (this.loginForm.invalid) return void this.loginForm.markAllAsTouched();
                            let r = {
                                user_id: +this.userId,
                                otp: (this.loginForm.value.otp1 + this.loginForm.value.otp2 + this.loginForm.value.otp3 + this.loginForm.value.otp4 + this.loginForm.value.otp5 + this.loginForm.value.otp6).toString()
                            };
                            this._service.post("telegram/verifyLoginOtp", r).subscribe(l => {
                                l.status ? (localStorage.setItem("openWelcomePopup", "true"), this.route.navigate(["/home"])) : this.toaster.error(l.message.toString())
                            })
                        }
                        resendLoginOtp() {
                            this._service.post("telegram/resendLoginOtp", {
                                user_id: +this.userId
                            }).subscribe(e => {
                                e.status || this.toaster.error(e.message)
                            }, e => {}, () => {})
                        }
                        ngOnDestroy() {
                            this.renderer.removeStyle(document.body, "background-color")
                        }
                        toFormGroup(o) {
                            const e = {};
                            return o.forEach(r => {
                                e[r] = new s.NI("", s.kI.required)
                            }), new s.cw(e)
                        }
                        keyUpEvent(o, e) {
                            let r = e;
                            r = 8 === o.keyCode && 8 === o.which ? e - 1 : e + 1, r > -1 && r < this.formInput.length && this.rows._results[r].nativeElement.focus(), this.onOtpChange()
                        }
                        onSubmit1() {}
                    }
                    return (n = a).\u0275fac = function(o) {
                        return new(o || n)(t.Y36(t.Qsj), t.Y36(s.qu), t.Y36(z.e), t.Y36(u.F0), t.Y36(f._W), t.Y36(m.s), t.Y36(d.F))
                    }, n.\u0275cmp = t.Xpm({
                        type: n,
                        selectors: [
                            ["app-otp"]
                        ],
                        viewQuery: function(o, e) {
                            if (1 & o && t.Gf(R, 5), 2 & o) {
                                let r;
                                t.iGM(r = t.CRH()) && (e.rows = r)
                            }
                        },
                        decls: 15,
                        vars: 3,
                        consts: [
                            [1, "login-page"],
                            [1, ""],
                            [1, "logo-login"],
                            [3, "src"],
                            [1, "login-form", "mt-xl-4", "mt-3"],
                            [1, "featured-box-login", "featured-box-secundary", "default"],
                            [1, "text-center"],
                            [1, "my-3", "text-center"],
                            ["href", "javascript:void(0)", 3, "click"],
                            [3, "formGroup", "ngSubmit"],
                            ["class", "input-login", 4, "ngFor", "ngForOf"],
                            [1, "input-login"],
                            ["type", "number", "maxlength", "1", 1, "otp-input", 3, "formControlName", "keyup"],
                            ["formRow", ""]
                        ],
                        template: function(o, e) {
                            1 & o && (t.TgZ(0, "div", 0)(1, "div", 1)(2, "div", 2), t._UZ(3, "img", 3), t.qZA(), t.TgZ(4, "div", 4)(5, "div", 5)(6, "h3", 6), t._uU(7, "Security Code Verification Using Telegram App"), t.qZA(), t.TgZ(8, "div", 7), t._uU(9, " Enter 6-digit code from your telegram bot "), t.TgZ(10, "span")(11, "a", 8), t.NdJ("click", function() {
                                return e.resendLoginOtp()
                            }), t._uU(12, "Resend Code"), t.qZA()()(), t.TgZ(13, "form", 9), t.NdJ("ngSubmit", function() {
                                return e.onOtpChange()
                            }), t.YNc(14, H, 3, 1, "div", 10), t.qZA()()()()()), 2 & o && (t.xp6(3), t.Q6J("src", e.logo, t.LSH), t.xp6(10), t.Q6J("formGroup", e.form), t.xp6(1), t.Q6J("ngForOf", e.formInput))
                        },
                        dependencies: [g.sg, s._Y, s.Fj, s.wV, s.JJ, s.JL, s.nD, s.sg, s.u],
                        styles: ["input[type=number][_ngcontent-%COMP%]::-webkit-inner-spin-button, input[type=number][_ngcontent-%COMP%]::-webkit-outer-spin-button{-webkit-appearance:none;appearance:none;margin:0}.login-page[_ngcontent-%COMP%]   .logo-login[_ngcontent-%COMP%]{width:auto!important}.login-form[_ngcontent-%COMP%]{width:100%!important}.logo-login[_ngcontent-%COMP%]{text-align:center!important}.login.otp[_ngcontent-%COMP%]{display:flex;align-items:center;justify-content:center}.login.otp[_ngcontent-%COMP%]   .loginInner1[_ngcontent-%COMP%]{width:100%;max-width:650px;margin:auto}.login.otp[_ngcontent-%COMP%]   .loginInner1[_ngcontent-%COMP%]   .log-logo[_ngcontent-%COMP%]   img[_ngcontent-%COMP%]{max-height:65px}.login.otp[_ngcontent-%COMP%]   .loginInner1[_ngcontent-%COMP%]   .featured-box-login[_ngcontent-%COMP%]{padding:60px 50px}.login.otp[_ngcontent-%COMP%]   .loginInner1[_ngcontent-%COMP%]   ul[_ngcontent-%COMP%]{text-align:center}.input-login[_ngcontent-%COMP%], .login.otp[_ngcontent-%COMP%]   .loginInner1[_ngcontent-%COMP%]   .input-login[_ngcontent-%COMP%]{display:inline-block}.otp-input[_ngcontent-%COMP%]{width:70px;height:70px;padding:5px;margin:0 10px;font-size:30px;border-radius:4px;border:1px solid rgba(0,0,0,.3);text-align:center}.featured-box-login.featured-box-secundary.default[_ngcontent-%COMP%]{text-align:center}.spinner-border[_ngcontent-%COMP%]{width:1rem;height:1rem;vertical-align:text-bottom;border:.15em solid currentColor;border-right-color:transparent;border-radius:50%;animation:spinner-border .75s linear infinite;color:#f8f9fa!important;display:inline-flex;margin-right:4px;margin-top:0;display:inline-block}.sr-only[_ngcontent-%COMP%]{position:absolute;width:1px;height:1px;padding:0;overflow:hidden;clip:rect(0,0,0,0);white-space:nowrap;border:0}.d-block[_ngcontent-%COMP%]{display:block!important}.d-none[_ngcontent-%COMP%]{display:none!important}@media only screen and (max-width: 576px){.otp-input[_ngcontent-%COMP%]{width:60px;height:60px;padding:2px;margin:0 3px}}@media only screen and (max-width: 425px){.login-form[_ngcontent-%COMP%]{width:98%!important}.otp-input[_ngcontent-%COMP%]{width:45px;height:45px;padding:2px;margin:0 3px}}"]
                    }), a
                })()
            }];
            let V = (() => {
                    var n;
                    class a {}
                    return (n = a).\u0275fac = function(o) {
                        return new(o || n)
                    }, n.\u0275mod = t.oAB({
                        type: n
                    }), n.\u0275inj = t.cJS({
                        imports: [u.Bz.forChild(j), u.Bz]
                    }), a
                })(),
                W = (() => {
                    var n;
                    class a {}
                    return (n = a).\u0275fac = function(o) {
                        return new(o || n)
                    }, n.\u0275mod = t.oAB({
                        type: n
                    }), n.\u0275inj = t.cJS({
                        imports: [g.ez, V, s.UX]
                    }), a
                })()
        }
    }
]);