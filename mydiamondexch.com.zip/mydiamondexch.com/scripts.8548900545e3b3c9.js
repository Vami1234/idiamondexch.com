! function(F, at) {
    "use strict";
    "object" == typeof module && "object" == typeof module.exports ? module.exports = F.document ? at(F, !0) : function(Ye) {
        if (!Ye.document) throw new Error("jQuery requires a window with a document");
        return at(Ye)
    } : at(F)
}(typeof window < "u" ? window : this, function(F, at) {
    "use strict";
    var Ye = [],
        J = F.document,
        ji = Object.getPrototypeOf,
        Fe = Ye.slice,
        dt = Ye.concat,
        Ke = Ye.push,
        xt = Ye.indexOf,
        lt = {},
        Gn = lt.toString,
        Lt = lt.hasOwnProperty,
        jt = Lt.toString,
        Ii = jt.call(Object),
        de = {};

    function De(e, n) {
        var i = (n = n || J).createElement("script");
        i.text = e, n.head.appendChild(i).parentNode.removeChild(i)
    }
    var r = function(e, n) {
            return new r.fn.init(e, n)
        },
        Pi = /^[\s\uFEFF\xA0]+|[\s\uFEFF\xA0]+$/g,
        qi = /^-ms-/,
        _r = /-([a-z])/g,
        wr = function(e, n) {
            return n.toUpperCase()
        };

    function Jn(e) {
        var n = !!e && "length" in e && e.length,
            i = r.type(e);
        return "function" !== i && !r.isWindow(e) && ("array" === i || 0 === n || "number" == typeof n && n > 0 && n - 1 in e)
    }
    r.fn = r.prototype = {
        jquery: "3.1.0",
        constructor: r,
        length: 0,
        toArray: function() {
            return Fe.call(this)
        },
        get: function(e) {
            return null != e ? e < 0 ? this[e + this.length] : this[e] : Fe.call(this)
        },
        pushStack: function(e) {
            var n = r.merge(this.constructor(), e);
            return n.prevObject = this, n
        },
        each: function(e) {
            return r.each(this, e)
        },
        map: function(e) {
            return this.pushStack(r.map(this, function(n, i) {
                return e.call(n, i, n)
            }))
        },
        slice: function() {
            return this.pushStack(Fe.apply(this, arguments))
        },
        first: function() {
            return this.eq(0)
        },
        last: function() {
            return this.eq(-1)
        },
        eq: function(e) {
            var n = this.length,
                i = +e + (e < 0 ? n : 0);
            return this.pushStack(i >= 0 && i < n ? [this[i]] : [])
        },
        end: function() {
            return this.prevObject || this.constructor()
        },
        push: Ke,
        sort: Ye.sort,
        splice: Ye.splice
    }, r.extend = r.fn.extend = function() {
        var e, n, i, o, l, a, u = arguments[0] || {},
            g = 1,
            v = arguments.length,
            b = !1;
        for ("boolean" == typeof u && (b = u, u = arguments[g] || {}, g++), "object" == typeof u || r.isFunction(u) || (u = {}), g === v && (u = this, g--); g < v; g++)
            if (null != (e = arguments[g]))
                for (n in e) i = u[n], u !== (o = e[n]) && (b && o && (r.isPlainObject(o) || (l = r.isArray(o))) ? (l ? (l = !1, a = i && r.isArray(i) ? i : []) : a = i && r.isPlainObject(i) ? i : {}, u[n] = r.extend(b, a, o)) : void 0 !== o && (u[n] = o));
        return u
    }, r.extend({
        expando: "jQuery" + ("3.1.0" + Math.random()).replace(/\D/g, ""),
        isReady: !0,
        error: function(e) {
            throw new Error(e)
        },
        noop: function() {},
        isFunction: function(e) {
            return "function" === r.type(e)
        },
        isArray: Array.isArray,
        isWindow: function(e) {
            return null != e && e === e.window
        },
        isNumeric: function(e) {
            var n = r.type(e);
            return ("number" === n || "string" === n) && !isNaN(e - parseFloat(e))
        },
        isPlainObject: function(e) {
            var n, i;
            return !(!e || "[object Object]" !== Gn.call(e) || (n = ji(e)) && (i = Lt.call(n, "constructor") && n.constructor, "function" != typeof i || jt.call(i) !== Ii))
        },
        isEmptyObject: function(e) {
            var n;
            for (n in e) return !1;
            return !0
        },
        type: function(e) {
            return null == e ? e + "" : "object" == typeof e || "function" == typeof e ? lt[Gn.call(e)] || "object" : typeof e
        },
        globalEval: function(e) {
            De(e)
        },
        camelCase: function(e) {
            return e.replace(qi, "ms-").replace(_r, wr)
        },
        nodeName: function(e, n) {
            return e.nodeName && e.nodeName.toLowerCase() === n.toLowerCase()
        },
        each: function(e, n) {
            var i, o = 0;
            if (Jn(e))
                for (i = e.length; o < i && !1 !== n.call(e[o], o, e[o]); o++);
            else
                for (o in e)
                    if (!1 === n.call(e[o], o, e[o])) break;
            return e
        },
        trim: function(e) {
            return null == e ? "" : (e + "").replace(Pi, "")
        },
        makeArray: function(e, n) {
            var i = n || [];
            return null != e && (Jn(Object(e)) ? r.merge(i, "string" == typeof e ? [e] : e) : Ke.call(i, e)), i
        },
        inArray: function(e, n, i) {
            return null == n ? -1 : xt.call(n, e, i)
        },
        merge: function(e, n) {
            for (var i = +n.length, o = 0, l = e.length; o < i; o++) e[l++] = n[o];
            return e.length = l, e
        },
        grep: function(e, n, i) {
            for (var l = [], a = 0, u = e.length, g = !i; a < u; a++) !n(e[a], a) !== g && l.push(e[a]);
            return l
        },
        map: function(e, n, i) {
            var o, l, a = 0,
                u = [];
            if (Jn(e))
                for (o = e.length; a < o; a++) null != (l = n(e[a], a, i)) && u.push(l);
            else
                for (a in e) null != (l = n(e[a], a, i)) && u.push(l);
            return dt.apply([], u)
        },
        guid: 1,
        proxy: function(e, n) {
            var i, o, l;
            if ("string" == typeof n && (i = e[n], n = e, e = i), r.isFunction(e)) return o = Fe.call(arguments, 2), l = function() {
                return e.apply(n || this, o.concat(Fe.call(arguments)))
            }, l.guid = e.guid = e.guid || r.guid++, l
        },
        now: Date.now,
        support: de
    }), "function" == typeof Symbol && (r.fn[Symbol.iterator] = Ye[Symbol.iterator]), r.each("Boolean Number String Function Array Date RegExp Object Error Symbol".split(" "), function(e, n) {
        lt["[object " + n + "]"] = n.toLowerCase()
    });
    var pt = function(e) {
        var n, i, o, l, a, u, g, v, b, T, D, w, A, W, K, M, oe, _e, Pe, ce = "sizzle" + 1 * new Date,
            X = e.document,
            qe = 0,
            ne = 0,
            me = Si(),
            rn = Si(),
            on = Si(),
            ot = function(f, d) {
                return f === d && (D = !0), 0
            },
            sn = {}.hasOwnProperty,
            He = [],
            vt = He.pop,
            yt = He.push,
            xe = He.push,
            bi = He.slice,
            zt = function(f, d) {
                for (var y = 0, E = f.length; y < E; y++)
                    if (f[y] === d) return y;
                return -1
            },
            zn = "checked|selected|async|autofocus|autoplay|controls|defer|disabled|hidden|ismap|loop|multiple|open|readonly|required|scoped",
            ue = "[\\x20\\t\\r\\n\\f]",
            Ot = "(?:\\\\.|[\\w-]|[^\0-\\xa0])+",
            Ei = "\\[" + ue + "*(" + Ot + ")(?:" + ue + "*([*^$|!~]?=)" + ue + "*(?:'((?:\\\\.|[^\\\\'])*)'|\"((?:\\\\.|[^\\\\\"])*)\"|(" + Ot + "))|)" + ue + "*\\]",
            Un = ":(" + Ot + ")(?:\\((('((?:\\\\.|[^\\\\'])*)'|\"((?:\\\\.|[^\\\\\"])*)\")|((?:\\\\.|[^\\\\()[\\]]|" + Ei + ")*)|.*)\\)|)",
            cr = new RegExp(ue + "+", "g"),
            xn = new RegExp("^" + ue + "+|((?:^|[^\\\\])(?:\\\\.)*)" + ue + "+$", "g"),
            ur = new RegExp("^" + ue + "*," + ue + "*"),
            Ti = new RegExp("^" + ue + "*([>+~]|" + ue + ")" + ue + "*"),
            Ut = new RegExp("=" + ue + "*([^\\]'\"]*?)" + ue + "*\\]", "g"),
            hr = new RegExp(Un),
            fr = new RegExp("^" + Ot + "$"),
            Xn = {
                ID: new RegExp("^#(" + Ot + ")"),
                CLASS: new RegExp("^\\.(" + Ot + ")"),
                TAG: new RegExp("^(" + Ot + "|[*])"),
                ATTR: new RegExp("^" + Ei),
                PSEUDO: new RegExp("^" + Un),
                CHILD: new RegExp("^:(only|first|last|nth|nth-last)-(child|of-type)(?:\\(" + ue + "*(even|odd|(([+-]|)(\\d*)n|)" + ue + "*(?:([+-]|)" + ue + "*(\\d+)|))" + ue + "*\\)|)", "i"),
                bool: new RegExp("^(?:" + zn + ")$", "i"),
                needsContext: new RegExp("^" + ue + "*[>+~]|:(even|odd|eq|gt|lt|nth|first|last)(?:\\(" + ue + "*((?:-\\d)?\\d*)" + ue + "*\\)|)(?=[^-]|$)", "i")
            },
            dr = /^(?:input|select|textarea|button)$/i,
            pr = /^h\d$/i,
            an = /^[^{]+\{\s*\[native \w/,
            Dt = /^(?:#([\w-]+)|(\w+)|\.([\w-]+))$/,
            Ci = /[+~]/,
            _t = new RegExp("\\\\([\\da-f]{1,6}" + ue + "?|(" + ue + ")|.)", "ig"),
            wt = function(f, d, y) {
                var E = "0x" + d - 65536;
                return E != E || y ? d : E < 0 ? String.fromCharCode(E + 65536) : String.fromCharCode(E >> 10 | 55296, 1023 & E | 56320)
            },
            gr = /([\0-\x1f\x7f]|^-?\d)|^-$|[^\x80-\uFFFF\w-]/g,
            Ai = function(f, d) {
                return d ? "\0" === f ? "\ufffd" : f.slice(0, -1) + "\\" + f.charCodeAt(f.length - 1).toString(16) + " " : "\\" + f
            },
            ki = function() {
                w()
            },
            Tr = ut(function(f) {
                return !0 === f.disabled
            }, {
                dir: "parentNode",
                next: "legend"
            });
        try {
            xe.apply(He = bi.call(X.childNodes), X.childNodes)
        } catch {
            xe = {
                apply: He.length ? function(d, y) {
                    yt.apply(d, bi.call(y))
                } : function(d, y) {
                    for (var E = d.length, _ = 0; d[E++] = y[_++];);
                    d.length = E - 1
                }
            }
        }

        function pe(f, d, y, E) {
            var _, C, O, j, I, V, H, $ = d && d.ownerDocument,
                Z = d ? d.nodeType : 9;
            if (y = y || [], "string" != typeof f || !f || 1 !== Z && 9 !== Z && 11 !== Z) return y;
            if (!E && ((d ? d.ownerDocument || d : X) !== A && w(d), d = d || A, K)) {
                if (11 !== Z && (I = Dt.exec(f)))
                    if (_ = I[1]) {
                        if (9 === Z) {
                            if (!(O = d.getElementById(_))) return y;
                            if (O.id === _) return y.push(O), y
                        } else if ($ && (O = $.getElementById(_)) && Pe(d, O) && O.id === _) return y.push(O), y
                    } else {
                        if (I[2]) return xe.apply(y, d.getElementsByTagName(f)), y;
                        if ((_ = I[3]) && i.getElementsByClassName && d.getElementsByClassName) return xe.apply(y, d.getElementsByClassName(_)), y
                    }
                if (i.qsa && !on[f + " "] && (!M || !M.test(f))) {
                    if (1 !== Z) $ = d, H = f;
                    else if ("object" !== d.nodeName.toLowerCase()) {
                        for ((j = d.getAttribute("id")) ? j = j.replace(gr, Ai) : d.setAttribute("id", j = ce), C = (V = u(f)).length; C--;) V[C] = "#" + j + " " + Tn(V[C]);
                        H = V.join(","), $ = Ci.test(f) && Vn(d.parentNode) || d
                    }
                    if (H) try {
                        return xe.apply(y, $.querySelectorAll(H)), y
                    } catch {} finally {
                        j === ce && d.removeAttribute("id")
                    }
                }
            }
            return v(f.replace(xn, "$1"), d, y, E)
        }

        function Si() {
            var f = [];
            return function d(y, E) {
                return f.push(y + " ") > o.cacheLength && delete d[f.shift()], d[y + " "] = E
            }
        }

        function st(f) {
            return f[ce] = !0, f
        }

        function ct(f) {
            var d = A.createElement("fieldset");
            try {
                return !!f(d)
            } catch {
                return !1
            } finally {
                d.parentNode && d.parentNode.removeChild(d), d = null
            }
        }

        function ln(f, d) {
            for (var y = f.split("|"), E = y.length; E--;) o.attrHandle[y[E]] = d
        }

        function cn(f, d) {
            var y = d && f,
                E = y && 1 === f.nodeType && 1 === d.nodeType && f.sourceIndex - d.sourceIndex;
            if (E) return E;
            if (y)
                for (; y = y.nextSibling;)
                    if (y === d) return -1;
            return f ? 1 : -1
        }

        function bn(f) {
            return function(d) {
                return "input" === d.nodeName.toLowerCase() && d.type === f
            }
        }

        function Oi(f) {
            return function(d) {
                var y = d.nodeName.toLowerCase();
                return ("input" === y || "button" === y) && d.type === f
            }
        }

        function Di(f) {
            return function(d) {
                return "label" in d && d.disabled === f || "form" in d && d.disabled === f || "form" in d && !1 === d.disabled && (d.isDisabled === f || d.isDisabled !== !f && ("label" in d || !Tr(d)) !== f)
            }
        }

        function Nt(f) {
            return st(function(d) {
                return d = +d, st(function(y, E) {
                    for (var _, C = f([], y.length, d), O = C.length; O--;) y[_ = C[O]] && (y[_] = !(E[_] = y[_]))
                })
            })
        }

        function Vn(f) {
            return f && typeof f.getElementsByTagName < "u" && f
        }
        for (n in i = pe.support = {}, a = pe.isXML = function(f) {
                var d = f && (f.ownerDocument || f).documentElement;
                return !!d && "HTML" !== d.nodeName
            }, w = pe.setDocument = function(f) {
                var d, y, E = f ? f.ownerDocument || f : X;
                return E !== A && 9 === E.nodeType && E.documentElement && (W = (A = E).documentElement, K = !a(A), X !== A && (y = A.defaultView) && y.top !== y && (y.addEventListener ? y.addEventListener("unload", ki, !1) : y.attachEvent && y.attachEvent("onunload", ki)), i.attributes = ct(function(_) {
                    return _.className = "i", !_.getAttribute("className")
                }), i.getElementsByTagName = ct(function(_) {
                    return _.appendChild(A.createComment("")), !_.getElementsByTagName("*").length
                }), i.getElementsByClassName = an.test(A.getElementsByClassName), i.getById = ct(function(_) {
                    return W.appendChild(_).id = ce, !A.getElementsByName || !A.getElementsByName(ce).length
                }), i.getById ? (o.find.ID = function(_, C) {
                    if (typeof C.getElementById < "u" && K) {
                        var O = C.getElementById(_);
                        return O ? [O] : []
                    }
                }, o.filter.ID = function(_) {
                    var C = _.replace(_t, wt);
                    return function(O) {
                        return O.getAttribute("id") === C
                    }
                }) : (delete o.find.ID, o.filter.ID = function(_) {
                    var C = _.replace(_t, wt);
                    return function(O) {
                        var j = typeof O.getAttributeNode < "u" && O.getAttributeNode("id");
                        return j && j.value === C
                    }
                }), o.find.TAG = i.getElementsByTagName ? function(_, C) {
                    return typeof C.getElementsByTagName < "u" ? C.getElementsByTagName(_) : i.qsa ? C.querySelectorAll(_) : void 0
                } : function(_, C) {
                    var O, j = [],
                        I = 0,
                        V = C.getElementsByTagName(_);
                    if ("*" === _) {
                        for (; O = V[I++];) 1 === O.nodeType && j.push(O);
                        return j
                    }
                    return V
                }, o.find.CLASS = i.getElementsByClassName && function(_, C) {
                    if (typeof C.getElementsByClassName < "u" && K) return C.getElementsByClassName(_)
                }, oe = [], M = [], (i.qsa = an.test(A.querySelectorAll)) && (ct(function(_) {
                    W.appendChild(_).innerHTML = "<a id='" + ce + "'></a><select id='" + ce + "-\r\\' msallowcapture=''><option selected=''></option></select>", _.querySelectorAll("[msallowcapture^='']").length && M.push("[*^$]=" + ue + "*(?:''|\"\")"), _.querySelectorAll("[selected]").length || M.push("\\[" + ue + "*(?:value|" + zn + ")"), _.querySelectorAll("[id~=" + ce + "-]").length || M.push("~="), _.querySelectorAll(":checked").length || M.push(":checked"), _.querySelectorAll("a#" + ce + "+*").length || M.push(".#.+[+~]")
                }), ct(function(_) {
                    _.innerHTML = "<a href='' disabled='disabled'></a><select disabled='disabled'><option/></select>";
                    var C = A.createElement("input");
                    C.setAttribute("type", "hidden"), _.appendChild(C).setAttribute("name", "D"), _.querySelectorAll("[name=d]").length && M.push("name" + ue + "*[*^$|!~]?="), 2 !== _.querySelectorAll(":enabled").length && M.push(":enabled", ":disabled"), W.appendChild(_).disabled = !0, 2 !== _.querySelectorAll(":disabled").length && M.push(":enabled", ":disabled"), _.querySelectorAll("*,:x"), M.push(",.*:")
                })), (i.matchesSelector = an.test(_e = W.matches || W.webkitMatchesSelector || W.mozMatchesSelector || W.oMatchesSelector || W.msMatchesSelector)) && ct(function(_) {
                    i.disconnectedMatch = _e.call(_, "*"), _e.call(_, "[s!='']:x"), oe.push("!=", Un)
                }), M = M.length && new RegExp(M.join("|")), oe = oe.length && new RegExp(oe.join("|")), d = an.test(W.compareDocumentPosition), Pe = d || an.test(W.contains) ? function(_, C) {
                    var O = 9 === _.nodeType ? _.documentElement : _,
                        j = C && C.parentNode;
                    return _ === j || !(!j || 1 !== j.nodeType || !(O.contains ? O.contains(j) : _.compareDocumentPosition && 16 & _.compareDocumentPosition(j)))
                } : function(_, C) {
                    if (C)
                        for (; C = C.parentNode;)
                            if (C === _) return !0;
                    return !1
                }, ot = d ? function(_, C) {
                    if (_ === C) return D = !0, 0;
                    var O = !_.compareDocumentPosition - !C.compareDocumentPosition;
                    return O || (1 & (O = (_.ownerDocument || _) === (C.ownerDocument || C) ? _.compareDocumentPosition(C) : 1) || !i.sortDetached && C.compareDocumentPosition(_) === O ? _ === A || _.ownerDocument === X && Pe(X, _) ? -1 : C === A || C.ownerDocument === X && Pe(X, C) ? 1 : T ? zt(T, _) - zt(T, C) : 0 : 4 & O ? -1 : 1)
                } : function(_, C) {
                    if (_ === C) return D = !0, 0;
                    var O, j = 0,
                        I = _.parentNode,
                        V = C.parentNode,
                        H = [_],
                        $ = [C];
                    if (!I || !V) return _ === A ? -1 : C === A ? 1 : I ? -1 : V ? 1 : T ? zt(T, _) - zt(T, C) : 0;
                    if (I === V) return cn(_, C);
                    for (O = _; O = O.parentNode;) H.unshift(O);
                    for (O = C; O = O.parentNode;) $.unshift(O);
                    for (; H[j] === $[j];) j++;
                    return j ? cn(H[j], $[j]) : H[j] === X ? -1 : $[j] === X ? 1 : 0
                }), A
            }, pe.matches = function(f, d) {
                return pe(f, null, null, d)
            }, pe.matchesSelector = function(f, d) {
                if ((f.ownerDocument || f) !== A && w(f), d = d.replace(Ut, "='$1']"), i.matchesSelector && K && !on[d + " "] && (!oe || !oe.test(d)) && (!M || !M.test(d))) try {
                    var y = _e.call(f, d);
                    if (y || i.disconnectedMatch || f.document && 11 !== f.document.nodeType) return y
                } catch {}
                return pe(d, A, null, [f]).length > 0
            }, pe.contains = function(f, d) {
                return (f.ownerDocument || f) !== A && w(f), Pe(f, d)
            }, pe.attr = function(f, d) {
                (f.ownerDocument || f) !== A && w(f);
                var y = o.attrHandle[d.toLowerCase()],
                    E = y && sn.call(o.attrHandle, d.toLowerCase()) ? y(f, d, !K) : void 0;
                return void 0 !== E ? E : i.attributes || !K ? f.getAttribute(d) : (E = f.getAttributeNode(d)) && E.specified ? E.value : null
            }, pe.escape = function(f) {
                return (f + "").replace(gr, Ai)
            }, pe.error = function(f) {
                throw new Error("Syntax error, unrecognized expression: " + f)
            }, pe.uniqueSort = function(f) {
                var d, y = [],
                    E = 0,
                    _ = 0;
                if (D = !i.detectDuplicates, T = !i.sortStable && f.slice(0), f.sort(ot), D) {
                    for (; d = f[_++];) d === f[_] && (E = y.push(_));
                    for (; E--;) f.splice(y[E], 1)
                }
                return T = null, f
            }, l = pe.getText = function(f) {
                var d, y = "",
                    E = 0,
                    _ = f.nodeType;
                if (_) {
                    if (1 === _ || 9 === _ || 11 === _) {
                        if ("string" == typeof f.textContent) return f.textContent;
                        for (f = f.firstChild; f; f = f.nextSibling) y += l(f)
                    } else if (3 === _ || 4 === _) return f.nodeValue
                } else
                    for (; d = f[E++];) y += l(d);
                return y
            }, (o = pe.selectors = {
                cacheLength: 50,
                createPseudo: st,
                match: Xn,
                attrHandle: {},
                find: {},
                relative: {
                    ">": {
                        dir: "parentNode",
                        first: !0
                    },
                    " ": {
                        dir: "parentNode"
                    },
                    "+": {
                        dir: "previousSibling",
                        first: !0
                    },
                    "~": {
                        dir: "previousSibling"
                    }
                },
                preFilter: {
                    ATTR: function(f) {
                        return f[1] = f[1].replace(_t, wt), f[3] = (f[3] || f[4] || f[5] || "").replace(_t, wt), "~=" === f[2] && (f[3] = " " + f[3] + " "), f.slice(0, 4)
                    },
                    CHILD: function(f) {
                        return f[1] = f[1].toLowerCase(), "nth" === f[1].slice(0, 3) ? (f[3] || pe.error(f[0]), f[4] = +(f[4] ? f[5] + (f[6] || 1) : 2 * ("even" === f[3] || "odd" === f[3])), f[5] = +(f[7] + f[8] || "odd" === f[3])) : f[3] && pe.error(f[0]), f
                    },
                    PSEUDO: function(f) {
                        var d, y = !f[6] && f[2];
                        return Xn.CHILD.test(f[0]) ? null : (f[3] ? f[2] = f[4] || f[5] || "" : y && hr.test(y) && (d = u(y, !0)) && (d = y.indexOf(")", y.length - d) - y.length) && (f[0] = f[0].slice(0, d), f[2] = y.slice(0, d)), f.slice(0, 3))
                    }
                },
                filter: {
                    TAG: function(f) {
                        var d = f.replace(_t, wt).toLowerCase();
                        return "*" === f ? function() {
                            return !0
                        } : function(y) {
                            return y.nodeName && y.nodeName.toLowerCase() === d
                        }
                    },
                    CLASS: function(f) {
                        var d = me[f + " "];
                        return d || (d = new RegExp("(^|" + ue + ")" + f + "(" + ue + "|$)")) && me(f, function(y) {
                            return d.test("string" == typeof y.className && y.className || typeof y.getAttribute < "u" && y.getAttribute("class") || "")
                        })
                    },
                    ATTR: function(f, d, y) {
                        return function(E) {
                            var _ = pe.attr(E, f);
                            return null == _ ? "!=" === d : !d || (_ += "", "=" === d ? _ === y : "!=" === d ? _ !== y : "^=" === d ? y && 0 === _.indexOf(y) : "*=" === d ? y && _.indexOf(y) > -1 : "$=" === d ? y && _.slice(-y.length) === y : "~=" === d ? (" " + _.replace(cr, " ") + " ").indexOf(y) > -1 : "|=" === d && (_ === y || _.slice(0, y.length + 1) === y + "-"))
                        }
                    },
                    CHILD: function(f, d, y, E, _) {
                        var C = "nth" !== f.slice(0, 3),
                            O = "last" !== f.slice(-4),
                            j = "of-type" === d;
                        return 1 === E && 0 === _ ? function(I) {
                            return !!I.parentNode
                        } : function(I, V, H) {
                            var $, Z, se, R, Ee, ke, Se = C !== O ? "nextSibling" : "previousSibling",
                                c = I.parentNode,
                                t = j && I.nodeName.toLowerCase(),
                                s = !H && !j,
                                h = !1;
                            if (c) {
                                if (C) {
                                    for (; Se;) {
                                        for (R = I; R = R[Se];)
                                            if (j ? R.nodeName.toLowerCase() === t : 1 === R.nodeType) return !1;
                                        ke = Se = "only" === f && !ke && "nextSibling"
                                    }
                                    return !0
                                }
                                if (ke = [O ? c.firstChild : c.lastChild], O && s) {
                                    for (h = (Ee = ($ = (Z = (se = (R = c)[ce] || (R[ce] = {}))[R.uniqueID] || (se[R.uniqueID] = {}))[f] || [])[0] === qe && $[1]) && $[2], R = Ee && c.childNodes[Ee]; R = ++Ee && R && R[Se] || (h = Ee = 0) || ke.pop();)
                                        if (1 === R.nodeType && ++h && R === I) {
                                            Z[f] = [qe, Ee, h];
                                            break
                                        }
                                } else if (s && (h = Ee = ($ = (Z = (se = (R = I)[ce] || (R[ce] = {}))[R.uniqueID] || (se[R.uniqueID] = {}))[f] || [])[0] === qe && $[1]), !1 === h)
                                    for (;
                                        (R = ++Ee && R && R[Se] || (h = Ee = 0) || ke.pop()) && ((j ? R.nodeName.toLowerCase() !== t : 1 !== R.nodeType) || !++h || (s && ((Z = (se = R[ce] || (R[ce] = {}))[R.uniqueID] || (se[R.uniqueID] = {}))[f] = [qe, h]), R !== I)););
                                return (h -= _) === E || h % E == 0 && h / E >= 0
                            }
                        }
                    },
                    PSEUDO: function(f, d) {
                        var y, E = o.pseudos[f] || o.setFilters[f.toLowerCase()] || pe.error("unsupported pseudo: " + f);
                        return E[ce] ? E(d) : E.length > 1 ? (y = [f, f, "", d], o.setFilters.hasOwnProperty(f.toLowerCase()) ? st(function(_, C) {
                            for (var O, j = E(_, d), I = j.length; I--;) _[O = zt(_, j[I])] = !(C[O] = j[I])
                        }) : function(_) {
                            return E(_, 0, y)
                        }) : E
                    }
                },
                pseudos: {
                    not: st(function(f) {
                        var d = [],
                            y = [],
                            E = g(f.replace(xn, "$1"));
                        return E[ce] ? st(function(_, C, O, j) {
                            for (var I, V = E(_, null, j, []), H = _.length; H--;)(I = V[H]) && (_[H] = !(C[H] = I))
                        }) : function(_, C, O) {
                            return d[0] = _, E(d, null, O, y), d[0] = null, !y.pop()
                        }
                    }),
                    has: st(function(f) {
                        return function(d) {
                            return pe(f, d).length > 0
                        }
                    }),
                    contains: st(function(f) {
                        return f = f.replace(_t, wt),
                            function(d) {
                                return (d.textContent || d.innerText || l(d)).indexOf(f) > -1
                            }
                    }),
                    lang: st(function(f) {
                        return fr.test(f || "") || pe.error("unsupported lang: " + f), f = f.replace(_t, wt).toLowerCase(),
                            function(d) {
                                var y;
                                do {
                                    if (y = K ? d.lang : d.getAttribute("xml:lang") || d.getAttribute("lang")) return (y = y.toLowerCase()) === f || 0 === y.indexOf(f + "-")
                                } while ((d = d.parentNode) && 1 === d.nodeType);
                                return !1
                            }
                    }),
                    target: function(f) {
                        var d = e.location && e.location.hash;
                        return d && d.slice(1) === f.id
                    },
                    root: function(f) {
                        return f === W
                    },
                    focus: function(f) {
                        return f === A.activeElement && (!A.hasFocus || A.hasFocus()) && !!(f.type || f.href || ~f.tabIndex)
                    },
                    enabled: Di(!1),
                    disabled: Di(!0),
                    checked: function(f) {
                        var d = f.nodeName.toLowerCase();
                        return "input" === d && !!f.checked || "option" === d && !!f.selected
                    },
                    selected: function(f) {
                        return !0 === f.selected
                    },
                    empty: function(f) {
                        for (f = f.firstChild; f; f = f.nextSibling)
                            if (f.nodeType < 6) return !1;
                        return !0
                    },
                    parent: function(f) {
                        return !o.pseudos.empty(f)
                    },
                    header: function(f) {
                        return pr.test(f.nodeName)
                    },
                    input: function(f) {
                        return dr.test(f.nodeName)
                    },
                    button: function(f) {
                        var d = f.nodeName.toLowerCase();
                        return "input" === d && "button" === f.type || "button" === d
                    },
                    text: function(f) {
                        var d;
                        return "input" === f.nodeName.toLowerCase() && "text" === f.type && (null == (d = f.getAttribute("type")) || "text" === d.toLowerCase())
                    },
                    first: Nt(function() {
                        return [0]
                    }),
                    last: Nt(function(f, d) {
                        return [d - 1]
                    }),
                    eq: Nt(function(f, d, y) {
                        return [y < 0 ? y + d : y]
                    }),
                    even: Nt(function(f, d) {
                        for (var y = 0; y < d; y += 2) f.push(y);
                        return f
                    }),
                    odd: Nt(function(f, d) {
                        for (var y = 1; y < d; y += 2) f.push(y);
                        return f
                    }),
                    lt: Nt(function(f, d, y) {
                        for (var E = y < 0 ? y + d : y; --E >= 0;) f.push(E);
                        return f
                    }),
                    gt: Nt(function(f, d, y) {
                        for (var E = y < 0 ? y + d : y; ++E < d;) f.push(E);
                        return f
                    })
                }
            }).pseudos.nth = o.pseudos.eq, {
                radio: !0,
                checkbox: !0,
                file: !0,
                password: !0,
                image: !0
            }) o.pseudos[n] = bn(n);
        for (n in {
                submit: !0,
                reset: !0
            }) o.pseudos[n] = Oi(n);

        function En() {}

        function Tn(f) {
            for (var d = 0, y = f.length, E = ""; d < y; d++) E += f[d].value;
            return E
        }

        function ut(f, d, y) {
            var E = d.dir,
                _ = d.next,
                C = _ || E,
                O = y && "parentNode" === C,
                j = ne++;
            return d.first ? function(I, V, H) {
                for (; I = I[E];)
                    if (1 === I.nodeType || O) return f(I, V, H)
            } : function(I, V, H) {
                var $, Z, se, R = [qe, j];
                if (H) {
                    for (; I = I[E];)
                        if ((1 === I.nodeType || O) && f(I, V, H)) return !0
                } else
                    for (; I = I[E];)
                        if (1 === I.nodeType || O)
                            if (Z = (se = I[ce] || (I[ce] = {}))[I.uniqueID] || (se[I.uniqueID] = {}), _ && _ === I.nodeName.toLowerCase()) I = I[E] || I;
                            else {
                                if (($ = Z[C]) && $[0] === qe && $[1] === j) return R[2] = $[2];
                                if (Z[C] = R, R[2] = f(I, V, H)) return !0
                            }
            }
        }

        function Ni(f) {
            return f.length > 1 ? function(d, y, E) {
                for (var _ = f.length; _--;)
                    if (!f[_](d, y, E)) return !1;
                return !0
            } : f[0]
        }

        function Yn(f, d, y, E, _) {
            for (var C, O = [], j = 0, I = f.length, V = null != d; j < I; j++)(C = f[j]) && (y && !y(C, E, _) || (O.push(C), V && d.push(j)));
            return O
        }

        function un(f, d, y, E, _, C) {
            return E && !E[ce] && (E = un(E)), _ && !_[ce] && (_ = un(_, C)), st(function(O, j, I, V) {
                var H, $, Z, se = [],
                    R = [],
                    Ee = j.length,
                    ke = O || function Cr(f, d, y) {
                        for (var E = 0, _ = d.length; E < _; E++) pe(f, d[E], y);
                        return y
                    }(d || "*", I.nodeType ? [I] : I, []),
                    Se = !f || !O && d ? ke : Yn(ke, se, f, I, V),
                    c = y ? _ || (O ? f : Ee || E) ? [] : j : Se;
                if (y && y(Se, c, I, V), E)
                    for (H = Yn(c, R), E(H, [], I, V), $ = H.length; $--;)(Z = H[$]) && (c[R[$]] = !(Se[R[$]] = Z));
                if (O) {
                    if (_ || f) {
                        if (_) {
                            for (H = [], $ = c.length; $--;)(Z = c[$]) && H.push(Se[$] = Z);
                            _(null, c = [], H, V)
                        }
                        for ($ = c.length; $--;)(Z = c[$]) && (H = _ ? zt(O, Z) : se[$]) > -1 && (O[H] = !(j[H] = Z))
                    }
                } else c = Yn(c === j ? c.splice(Ee, c.length) : c), _ ? _(null, j, c, V) : xe.apply(j, c)
            })
        }

        function Kn(f) {
            for (var d, y, E, _ = f.length, C = o.relative[f[0].type], O = C || o.relative[" "], j = C ? 1 : 0, I = ut(function($) {
                    return $ === d
                }, O, !0), V = ut(function($) {
                    return zt(d, $) > -1
                }, O, !0), H = [function($, Z, se) {
                    var R = !C && (se || Z !== b) || ((d = Z).nodeType ? I($, Z, se) : V($, Z, se));
                    return d = null, R
                }]; j < _; j++)
                if (y = o.relative[f[j].type]) H = [ut(Ni(H), y)];
                else {
                    if ((y = o.filter[f[j].type].apply(null, f[j].matches))[ce]) {
                        for (E = ++j; E < _ && !o.relative[f[E].type]; E++);
                        return un(j > 1 && Ni(H), j > 1 && Tn(f.slice(0, j - 1).concat({
                            value: " " === f[j - 2].type ? "*" : ""
                        })).replace(xn, "$1"), y, j < E && Kn(f.slice(j, E)), E < _ && Kn(f = f.slice(E)), E < _ && Tn(f))
                    }
                    H.push(y)
                }
            return Ni(H)
        }
        return En.prototype = o.filters = o.pseudos, o.setFilters = new En, u = pe.tokenize = function(f, d) {
            var y, E, _, C, O, j, I, V = rn[f + " "];
            if (V) return d ? 0 : V.slice(0);
            for (O = f, j = [], I = o.preFilter; O;) {
                for (C in y && !(E = ur.exec(O)) || (E && (O = O.slice(E[0].length) || O), j.push(_ = [])), y = !1, (E = Ti.exec(O)) && (y = E.shift(), _.push({
                        value: y,
                        type: E[0].replace(xn, " ")
                    }), O = O.slice(y.length)), o.filter) !(E = Xn[C].exec(O)) || I[C] && !(E = I[C](E)) || (y = E.shift(), _.push({
                    value: y,
                    type: C,
                    matches: E
                }), O = O.slice(y.length));
                if (!y) break
            }
            return d ? O.length : O ? pe.error(f) : rn(f, j).slice(0)
        }, g = pe.compile = function(f, d) {
            var y, E = [],
                _ = [],
                C = on[f + " "];
            if (!C) {
                for (d || (d = u(f)), y = d.length; y--;)(C = Kn(d[y]))[ce] ? E.push(C) : _.push(C);
                C = on(f, function mr(f, d) {
                    var y = d.length > 0,
                        E = f.length > 0,
                        _ = function(C, O, j, I, V) {
                            var H, $, Z, se = 0,
                                R = "0",
                                Ee = C && [],
                                ke = [],
                                Se = b,
                                c = C || E && o.find.TAG("*", V),
                                t = qe += null == Se ? 1 : Math.random() || .1,
                                s = c.length;
                            for (V && (b = O === A || O || V); R !== s && null != (H = c[R]); R++) {
                                if (E && H) {
                                    for ($ = 0, O || H.ownerDocument === A || (w(H), j = !K); Z = f[$++];)
                                        if (Z(H, O || A, j)) {
                                            I.push(H);
                                            break
                                        }
                                    V && (qe = t)
                                }
                                y && ((H = !Z && H) && se--, C && Ee.push(H))
                            }
                            if (se += R, y && R !== se) {
                                for ($ = 0; Z = d[$++];) Z(Ee, ke, O, j);
                                if (C) {
                                    if (se > 0)
                                        for (; R--;) Ee[R] || ke[R] || (ke[R] = vt.call(I));
                                    ke = Yn(ke)
                                }
                                xe.apply(I, ke), V && !C && ke.length > 0 && se + d.length > 1 && pe.uniqueSort(I)
                            }
                            return V && (qe = t, b = Se), Ee
                        };
                    return y ? st(_) : _
                }(_, E)), C.selector = f
            }
            return C
        }, v = pe.select = function(f, d, y, E) {
            var _, C, O, j, I, V = "function" == typeof f && f,
                H = !E && u(f = V.selector || f);
            if (y = y || [], 1 === H.length) {
                if ((C = H[0] = H[0].slice(0)).length > 2 && "ID" === (O = C[0]).type && i.getById && 9 === d.nodeType && K && o.relative[C[1].type]) {
                    if (!(d = (o.find.ID(O.matches[0].replace(_t, wt), d) || [])[0])) return y;
                    V && (d = d.parentNode), f = f.slice(C.shift().value.length)
                }
                for (_ = Xn.needsContext.test(f) ? 0 : C.length; _-- && !o.relative[j = (O = C[_]).type];)
                    if ((I = o.find[j]) && (E = I(O.matches[0].replace(_t, wt), Ci.test(C[0].type) && Vn(d.parentNode) || d))) {
                        if (C.splice(_, 1), !(f = E.length && Tn(C))) return xe.apply(y, E), y;
                        break
                    }
            }
            return (V || g(f, H))(E, d, !K, y, !d || Ci.test(f) && Vn(d.parentNode) || d), y
        }, i.sortStable = ce.split("").sort(ot).join("") === ce, i.detectDuplicates = !!D, w(), i.sortDetached = ct(function(f) {
            return 1 & f.compareDocumentPosition(A.createElement("fieldset"))
        }), ct(function(f) {
            return f.innerHTML = "<a href='#'></a>", "#" === f.firstChild.getAttribute("href")
        }) || ln("type|href|height|width", function(f, d, y) {
            if (!y) return f.getAttribute(d, "type" === d.toLowerCase() ? 1 : 2)
        }), i.attributes && ct(function(f) {
            return f.innerHTML = "<input/>", f.firstChild.setAttribute("value", ""), "" === f.firstChild.getAttribute("value")
        }) || ln("value", function(f, d, y) {
            if (!y && "input" === f.nodeName.toLowerCase()) return f.defaultValue
        }), ct(function(f) {
            return null == f.getAttribute("disabled")
        }) || ln(zn, function(f, d, y) {
            var E;
            if (!y) return !0 === f[d] ? d.toLowerCase() : (E = f.getAttributeNode(d)) && E.specified ? E.value : null
        }), pe
    }(F);
    r.find = pt, r.expr = pt.selectors, r.expr[":"] = r.expr.pseudos, r.uniqueSort = r.unique = pt.uniqueSort, r.text = pt.getText, r.isXMLDoc = pt.isXML, r.contains = pt.contains, r.escapeSelector = pt.escape;
    var It = function(e, n, i) {
            for (var o = [], l = void 0 !== i;
                (e = e[n]) && 9 !== e.nodeType;)
                if (1 === e.nodeType) {
                    if (l && r(e).is(i)) break;
                    o.push(e)
                }
            return o
        },
        Hi = function(e, n) {
            for (var i = []; e; e = e.nextSibling) 1 === e.nodeType && e !== n && i.push(e);
            return i
        },
        Mi = r.expr.match.needsContext,
        Zn = /^<([a-z][^\/\0>:\x20\t\r\n\f]*)[\x20\t\r\n\f]*\/?>(?:<\/\1>|)$/i,
        Ri = /^.[^:#\[\.,]*$/;

    function kn(e, n, i) {
        if (r.isFunction(n)) return r.grep(e, function(o, l) {
            return !!n.call(o, l, o) !== i
        });
        if (n.nodeType) return r.grep(e, function(o) {
            return o === n !== i
        });
        if ("string" == typeof n) {
            if (Ri.test(n)) return r.filter(n, e, i);
            n = r.filter(n, e)
        }
        return r.grep(e, function(o) {
            return xt.call(n, o) > -1 !== i && 1 === o.nodeType
        })
    }
    r.filter = function(e, n, i) {
        var o = n[0];
        return i && (e = ":not(" + e + ")"), 1 === n.length && 1 === o.nodeType ? r.find.matchesSelector(o, e) ? [o] : [] : r.find.matches(e, r.grep(n, function(l) {
            return 1 === l.nodeType
        }))
    }, r.fn.extend({
        find: function(e) {
            var n, i, o = this.length,
                l = this;
            if ("string" != typeof e) return this.pushStack(r(e).filter(function() {
                for (n = 0; n < o; n++)
                    if (r.contains(l[n], this)) return !0
            }));
            for (i = this.pushStack([]), n = 0; n < o; n++) r.find(e, l[n], i);
            return o > 1 ? r.uniqueSort(i) : i
        },
        filter: function(e) {
            return this.pushStack(kn(this, e || [], !1))
        },
        not: function(e) {
            return this.pushStack(kn(this, e || [], !0))
        },
        is: function(e) {
            return !!kn(this, "string" == typeof e && Mi.test(e) ? r(e) : e || [], !1).length
        }
    });
    var ei, Fi = /^(?:\s*(<[\w\W]+>)[^>]*|#([\w-]+))$/,
        Bi = r.fn.init = function(e, n, i) {
            var o, l;
            if (!e) return this;
            if (i = i || ei, "string" == typeof e) {
                if (!(o = "<" === e[0] && ">" === e[e.length - 1] && e.length >= 3 ? [null, e, null] : Fi.exec(e)) || !o[1] && n) return !n || n.jquery ? (n || i).find(e) : this.constructor(n).find(e);
                if (o[1]) {
                    if (r.merge(this, r.parseHTML(o[1], (n = n instanceof r ? n[0] : n) && n.nodeType ? n.ownerDocument || n : J, !0)), Zn.test(o[1]) && r.isPlainObject(n))
                        for (o in n) r.isFunction(this[o]) ? this[o](n[o]) : this.attr(o, n[o]);
                    return this
                }
                return (l = J.getElementById(o[2])) && (this[0] = l, this.length = 1), this
            }
            return e.nodeType ? (this[0] = e, this.length = 1, this) : r.isFunction(e) ? void 0 !== i.ready ? i.ready(e) : e(r) : r.makeArray(e, this)
        };
    Bi.prototype = r.fn, ei = r(J);
    var ti = /^(?:parents|prev(?:Until|All))/,
        Wi = {
            children: !0,
            contents: !0,
            next: !0,
            prev: !0
        };

    function S(e, n) {
        for (;
            (e = e[n]) && 1 !== e.nodeType;);
        return e
    }
    r.fn.extend({
        has: function(e) {
            var n = r(e, this),
                i = n.length;
            return this.filter(function() {
                for (var o = 0; o < i; o++)
                    if (r.contains(this, n[o])) return !0
            })
        },
        closest: function(e, n) {
            var i, o = 0,
                l = this.length,
                a = [],
                u = "string" != typeof e && r(e);
            if (!Mi.test(e))
                for (; o < l; o++)
                    for (i = this[o]; i && i !== n; i = i.parentNode)
                        if (i.nodeType < 11 && (u ? u.index(i) > -1 : 1 === i.nodeType && r.find.matchesSelector(i, e))) {
                            a.push(i);
                            break
                        }
            return this.pushStack(a.length > 1 ? r.uniqueSort(a) : a)
        },
        index: function(e) {
            return e ? "string" == typeof e ? xt.call(r(e), this[0]) : xt.call(this, e.jquery ? e[0] : e) : this[0] && this[0].parentNode ? this.first().prevAll().length : -1
        },
        add: function(e, n) {
            return this.pushStack(r.uniqueSort(r.merge(this.get(), r(e, n))))
        },
        addBack: function(e) {
            return this.add(null == e ? this.prevObject : this.prevObject.filter(e))
        }
    }), r.each({
        parent: function(e) {
            var n = e.parentNode;
            return n && 11 !== n.nodeType ? n : null
        },
        parents: function(e) {
            return It(e, "parentNode")
        },
        parentsUntil: function(e, n, i) {
            return It(e, "parentNode", i)
        },
        next: function(e) {
            return S(e, "nextSibling")
        },
        prev: function(e) {
            return S(e, "previousSibling")
        },
        nextAll: function(e) {
            return It(e, "nextSibling")
        },
        prevAll: function(e) {
            return It(e, "previousSibling")
        },
        nextUntil: function(e, n, i) {
            return It(e, "nextSibling", i)
        },
        prevUntil: function(e, n, i) {
            return It(e, "previousSibling", i)
        },
        siblings: function(e) {
            return Hi((e.parentNode || {}).firstChild, e)
        },
        children: function(e) {
            return Hi(e.firstChild)
        },
        contents: function(e) {
            return e.contentDocument || r.merge([], e.childNodes)
        }
    }, function(e, n) {
        r.fn[e] = function(i, o) {
            var l = r.map(this, n, i);
            return "Until" !== e.slice(-5) && (o = i), o && "string" == typeof o && (l = r.filter(o, l)), this.length > 1 && (Wi[e] || r.uniqueSort(l), ti.test(e) && l.reverse()), this.pushStack(l)
        }
    });
    var Ce = /\S+/g;

    function Oe(e) {
        return e
    }

    function Pt(e) {
        throw e
    }

    function Yt(e, n, i) {
        var o;
        try {
            e && r.isFunction(o = e.promise) ? o.call(e).done(n).fail(i) : e && r.isFunction(o = e.then) ? o.call(e, n, i) : n.call(void 0, e)
        } catch (l) {
            i.call(void 0, l)
        }
    }
    r.Callbacks = function(e) {
        e = "string" == typeof e ? function hn(e) {
            var n = {};
            return r.each(e.match(Ce) || [], function(i, o) {
                n[o] = !0
            }), n
        }(e) : r.extend({}, e);
        var n, i, o, l, a = [],
            u = [],
            g = -1,
            v = function() {
                for (l = e.once, o = n = !0; u.length; g = -1)
                    for (i = u.shift(); ++g < a.length;) !1 === a[g].apply(i[0], i[1]) && e.stopOnFalse && (g = a.length, i = !1);
                e.memory || (i = !1), n = !1, l && (a = i ? [] : "")
            },
            b = {
                add: function() {
                    return a && (i && !n && (g = a.length - 1, u.push(i)), function T(D) {
                        r.each(D, function(w, A) {
                            r.isFunction(A) ? e.unique && b.has(A) || a.push(A) : A && A.length && "string" !== r.type(A) && T(A)
                        })
                    }(arguments), i && !n && v()), this
                },
                remove: function() {
                    return r.each(arguments, function(T, D) {
                        for (var w;
                            (w = r.inArray(D, a, w)) > -1;) a.splice(w, 1), w <= g && g--
                    }), this
                },
                has: function(T) {
                    return T ? r.inArray(T, a) > -1 : a.length > 0
                },
                empty: function() {
                    return a && (a = []), this
                },
                disable: function() {
                    return l = u = [], a = i = "", this
                },
                disabled: function() {
                    return !a
                },
                lock: function() {
                    return l = u = [], i || n || (a = i = ""), this
                },
                locked: function() {
                    return !!l
                },
                fireWith: function(T, D) {
                    return l || (D = [T, (D = D || []).slice ? D.slice() : D], u.push(D), n || v()), this
                },
                fire: function() {
                    return b.fireWith(this, arguments), this
                },
                fired: function() {
                    return !!o
                }
            };
        return b
    }, r.extend({
        Deferred: function(e) {
            var n = [
                    ["notify", "progress", r.Callbacks("memory"), r.Callbacks("memory"), 2],
                    ["resolve", "done", r.Callbacks("once memory"), r.Callbacks("once memory"), 0, "resolved"],
                    ["reject", "fail", r.Callbacks("once memory"), r.Callbacks("once memory"), 1, "rejected"]
                ],
                i = "pending",
                o = {
                    state: function() {
                        return i
                    },
                    always: function() {
                        return l.done(arguments).fail(arguments), this
                    },
                    catch: function(a) {
                        return o.then(null, a)
                    },
                    pipe: function() {
                        var a = arguments;
                        return r.Deferred(function(u) {
                            r.each(n, function(g, v) {
                                var b = r.isFunction(a[v[4]]) && a[v[4]];
                                l[v[1]](function() {
                                    var T = b && b.apply(this, arguments);
                                    T && r.isFunction(T.promise) ? T.promise().progress(u.notify).done(u.resolve).fail(u.reject) : u[v[0] + "With"](this, b ? [T] : arguments)
                                })
                            }), a = null
                        }).promise()
                    },
                    then: function(a, u, g) {
                        var v = 0;

                        function b(T, D, w, A) {
                            return function() {
                                var W = this,
                                    K = arguments,
                                    M = function() {
                                        var _e, Pe;
                                        if (!(T < v)) {
                                            if ((_e = w.apply(W, K)) === D.promise()) throw new TypeError("Thenable self-resolution");
                                            r.isFunction(Pe = _e && ("object" == typeof _e || "function" == typeof _e) && _e.then) ? A ? Pe.call(_e, b(v, D, Oe, A), b(v, D, Pt, A)) : (v++, Pe.call(_e, b(v, D, Oe, A), b(v, D, Pt, A), b(v, D, Oe, D.notifyWith))) : (w !== Oe && (W = void 0, K = [_e]), (A || D.resolveWith)(W, K))
                                        }
                                    },
                                    oe = A ? M : function() {
                                        try {
                                            M()
                                        } catch (_e) {
                                            r.Deferred.exceptionHook && r.Deferred.exceptionHook(_e, oe.stackTrace), T + 1 >= v && (w !== Pt && (W = void 0, K = [_e]), D.rejectWith(W, K))
                                        }
                                    };
                                T ? oe() : (r.Deferred.getStackHook && (oe.stackTrace = r.Deferred.getStackHook()), F.setTimeout(oe))
                            }
                        }
                        return r.Deferred(function(T) {
                            n[0][3].add(b(0, T, r.isFunction(g) ? g : Oe, T.notifyWith)), n[1][3].add(b(0, T, r.isFunction(a) ? a : Oe)), n[2][3].add(b(0, T, r.isFunction(u) ? u : Pt))
                        }).promise()
                    },
                    promise: function(a) {
                        return null != a ? r.extend(a, o) : o
                    }
                },
                l = {};
            return r.each(n, function(a, u) {
                var g = u[2],
                    v = u[5];
                o[u[1]] = g.add, v && g.add(function() {
                    i = v
                }, n[3 - a][2].disable, n[0][2].lock), g.add(u[3].fire), l[u[0]] = function() {
                    return l[u[0] + "With"](this === l ? void 0 : this, arguments), this
                }, l[u[0] + "With"] = g.fireWith
            }), o.promise(l), e && e.call(l, l), l
        },
        when: function(e) {
            var n = arguments.length,
                i = n,
                o = Array(i),
                l = Fe.call(arguments),
                a = r.Deferred(),
                u = function(g) {
                    return function(v) {
                        o[g] = this, l[g] = arguments.length > 1 ? Fe.call(arguments) : v, --n || a.resolveWith(o, l)
                    }
                };
            if (n <= 1 && (Yt(e, a.done(u(i)).resolve, a.reject), "pending" === a.state() || r.isFunction(l[i] && l[i].then))) return a.then();
            for (; i--;) Yt(l[i], u(i), a.reject);
            return a.promise()
        }
    });
    var $i = /^(Eval|Internal|Range|Reference|Syntax|Type|URI)Error$/;
    r.Deferred.exceptionHook = function(e, n) {
        F.console && F.console.warn && e && $i.test(e.name) && F.console.warn("jQuery.Deferred exception: " + e.message, e.stack, n)
    }, r.readyException = function(e) {
        F.setTimeout(function() {
            throw e
        })
    };
    var qt = r.Deferred();

    function fn() {
        J.removeEventListener("DOMContentLoaded", fn), F.removeEventListener("load", fn), r.ready()
    }
    r.fn.ready = function(e) {
        return qt.then(e).catch(function(n) {
            r.readyException(n)
        }), this
    }, r.extend({
        isReady: !1,
        readyWait: 1,
        holdReady: function(e) {
            e ? r.readyWait++ : r.ready(!0)
        },
        ready: function(e) {
            (!0 === e ? --r.readyWait : r.isReady) || (r.isReady = !0, !0 !== e && --r.readyWait > 0 || qt.resolveWith(J, [r]))
        }
    }), r.ready.then = qt.then, "complete" === J.readyState || "loading" !== J.readyState && !J.documentElement.doScroll ? F.setTimeout(r.ready) : (J.addEventListener("DOMContentLoaded", fn), F.addEventListener("load", fn));
    var Je = function(e, n, i, o, l, a, u) {
            var g = 0,
                v = e.length,
                b = null == i;
            if ("object" === r.type(i))
                for (g in l = !0, i) Je(e, n, g, i[g], !0, a, u);
            else if (void 0 !== o && (l = !0, r.isFunction(o) || (u = !0), b && (u ? (n.call(e, o), n = null) : (b = n, n = function(T, D, w) {
                    return b.call(r(T), w)
                })), n))
                for (; g < v; g++) n(e[g], i, u ? o : o.call(e[g], g, n(e[g], i)));
            return l ? e : b ? n.call(e) : v ? n(e[0], i) : a
        },
        we = function(e) {
            return 1 === e.nodeType || 9 === e.nodeType || !+e.nodeType
        };

    function B() {
        this.expando = r.expando + B.uid++
    }
    B.uid = 1, B.prototype = {
        cache: function(e) {
            var n = e[this.expando];
            return n || (n = {}, we(e) && (e.nodeType ? e[this.expando] = n : Object.defineProperty(e, this.expando, {
                value: n,
                configurable: !0
            }))), n
        },
        set: function(e, n, i) {
            var o, l = this.cache(e);
            if ("string" == typeof n) l[r.camelCase(n)] = i;
            else
                for (o in n) l[r.camelCase(o)] = n[o];
            return l
        },
        get: function(e, n) {
            return void 0 === n ? this.cache(e) : e[this.expando] && e[this.expando][r.camelCase(n)]
        },
        access: function(e, n, i) {
            return void 0 === n || n && "string" == typeof n && void 0 === i ? this.get(e, n) : (this.set(e, n, i), void 0 !== i ? i : n)
        },
        remove: function(e, n) {
            var i, o = e[this.expando];
            if (void 0 !== o) {
                if (void 0 !== n)
                    for ((i = (n = r.isArray(n) ? n.map(r.camelCase) : (n = r.camelCase(n)) in o ? [n] : n.match(Ce) || []).length); i--;) delete o[n[i]];
                (void 0 === n || r.isEmptyObject(o)) && (e.nodeType ? e[this.expando] = void 0 : delete e[this.expando])
            }
        },
        hasData: function(e) {
            var n = e[this.expando];
            return void 0 !== n && !r.isEmptyObject(n)
        }
    };
    var Y = new B,
        Ne = new B,
        xr = /^(?:\{[\w\W]*\}|\[[\w\W]*\])$/,
        Ht = /[A-Z]/g;

    function bt(e, n, i) {
        var o;
        if (void 0 === i && 1 === e.nodeType)
            if (o = "data-" + n.replace(Ht, "-$&").toLowerCase(), "string" == typeof(i = e.getAttribute(o))) {
                try {
                    i = "true" === i || "false" !== i && ("null" === i ? null : +i + "" === i ? +i : xr.test(i) ? JSON.parse(i) : i)
                } catch {}
                Ne.set(e, n, i)
            } else i = void 0;
        return i
    }
    r.extend({
        hasData: function(e) {
            return Ne.hasData(e) || Y.hasData(e)
        },
        data: function(e, n, i) {
            return Ne.access(e, n, i)
        },
        removeData: function(e, n) {
            Ne.remove(e, n)
        },
        _data: function(e, n, i) {
            return Y.access(e, n, i)
        },
        _removeData: function(e, n) {
            Y.remove(e, n)
        }
    }), r.fn.extend({
        data: function(e, n) {
            var i, o, l, a = this[0],
                u = a && a.attributes;
            if (void 0 === e) {
                if (this.length && (l = Ne.get(a), 1 === a.nodeType && !Y.get(a, "hasDataAttrs"))) {
                    for (i = u.length; i--;) u[i] && 0 === (o = u[i].name).indexOf("data-") && (o = r.camelCase(o.slice(5)), bt(a, o, l[o]));
                    Y.set(a, "hasDataAttrs", !0)
                }
                return l
            }
            return "object" == typeof e ? this.each(function() {
                Ne.set(this, e)
            }) : Je(this, function(g) {
                var v;
                if (a && void 0 === g) {
                    if (void 0 !== (v = Ne.get(a, e)) || void 0 !== (v = bt(a, e))) return v
                } else this.each(function() {
                    Ne.set(this, e, g)
                })
            }, null, n, arguments.length > 1, null, !0)
        },
        removeData: function(e) {
            return this.each(function() {
                Ne.remove(this, e)
            })
        }
    }), r.extend({
        queue: function(e, n, i) {
            var o;
            if (e) return o = Y.get(e, n = (n || "fx") + "queue"), i && (!o || r.isArray(i) ? o = Y.access(e, n, r.makeArray(i)) : o.push(i)), o || []
        },
        dequeue: function(e, n) {
            var i = r.queue(e, n = n || "fx"),
                o = i.length,
                l = i.shift(),
                a = r._queueHooks(e, n);
            "inprogress" === l && (l = i.shift(), o--), l && ("fx" === n && i.unshift("inprogress"), delete a.stop, l.call(e, function() {
                r.dequeue(e, n)
            }, a)), !o && a && a.empty.fire()
        },
        _queueHooks: function(e, n) {
            var i = n + "queueHooks";
            return Y.get(e, i) || Y.access(e, i, {
                empty: r.Callbacks("once memory").add(function() {
                    Y.remove(e, [n + "queue", i])
                })
            })
        }
    }), r.fn.extend({
        queue: function(e, n) {
            var i = 2;
            return "string" != typeof e && (n = e, e = "fx", i--), arguments.length < i ? r.queue(this[0], e) : void 0 === n ? this : this.each(function() {
                var o = r.queue(this, e, n);
                r._queueHooks(this, e), "fx" === e && "inprogress" !== o[0] && r.dequeue(this, e)
            })
        },
        dequeue: function(e) {
            return this.each(function() {
                r.dequeue(this, e)
            })
        },
        clearQueue: function(e) {
            return this.queue(e || "fx", [])
        },
        promise: function(e, n) {
            var i, o = 1,
                l = r.Deferred(),
                a = this,
                u = this.length,
                g = function() {
                    --o || l.resolveWith(a, [a])
                };
            for ("string" != typeof e && (n = e, e = void 0), e = e || "fx"; u--;)(i = Y.get(a[u], e + "queueHooks")) && i.empty && (o++, i.empty.add(g));
            return g(), l.promise(n)
        }
    });
    var Et = /[+-]?(?:\d*\.|)\d+(?:[eE][+-]?\d+|)/.source,
        gt = new RegExp("^(?:([+-])=|)(" + Et + ")([a-z%]*)$", "i"),
        Mt = ["Top", "Right", "Bottom", "Left"],
        dn = function(e, n) {
            return "none" === (e = n || e).style.display || "" === e.style.display && r.contains(e.ownerDocument, e) && "none" === r.css(e, "display")
        },
        Tt = function(e, n, i, o) {
            var l, a, u = {};
            for (a in n) u[a] = e.style[a], e.style[a] = n[a];
            for (a in l = i.apply(e, o || []), n) e.style[a] = u[a];
            return l
        };

    function pn(e, n, i, o) {
        var l, a = 1,
            u = 20,
            g = o ? function() {
                return o.cur()
            } : function() {
                return r.css(e, n, "")
            },
            v = g(),
            b = i && i[3] || (r.cssNumber[n] ? "" : "px"),
            T = (r.cssNumber[n] || "px" !== b && +v) && gt.exec(r.css(e, n));
        if (T && T[3] !== b) {
            b = b || T[3], i = i || [], T = +v || 1;
            do {
                r.style(e, n, (T /= a = a || ".5") + b)
            } while (a !== (a = g() / v) && 1 !== a && --u)
        }
        return i && (T = +T || +v || 0, l = i[1] ? T + (i[1] + 1) * i[2] : +i[2], o && (o.unit = b, o.start = T, o.end = l)), l
    }
    var Ze = {};

    function zi(e) {
        var n, i = e.ownerDocument,
            o = e.nodeName,
            l = Ze[o];
        return l || (n = i.body.appendChild(i.createElement(o)), l = r.css(n, "display"), n.parentNode.removeChild(n), "none" === l && (l = "block"), Ze[o] = l, l)
    }

    function Rt(e, n) {
        for (var i, o, l = [], a = 0, u = e.length; a < u; a++)(o = e[a]).style && (i = o.style.display, n ? ("none" === i && (l[a] = Y.get(o, "display") || null, l[a] || (o.style.display = "")), "" === o.style.display && dn(o) && (l[a] = zi(o))) : "none" !== i && (l[a] = "none", Y.set(o, "display", i)));
        for (a = 0; a < u; a++) null != l[a] && (e[a].style.display = l[a]);
        return e
    }
    r.fn.extend({
        show: function() {
            return Rt(this, !0)
        },
        hide: function() {
            return Rt(this)
        },
        toggle: function(e) {
            return "boolean" == typeof e ? e ? this.show() : this.hide() : this.each(function() {
                dn(this) ? r(this).show() : r(this).hide()
            })
        }
    });
    var Ui = /^(?:checkbox|radio)$/i,
        Sn = /<([a-z][^\/\0>\x20\t\r\n\f]+)/i,
        gn = /^$|\/(?:java|ecma)script/i,
        Le = {
            option: [1, "<select multiple='multiple'>", "</select>"],
            thead: [1, "<table>", "</table>"],
            col: [2, "<table><colgroup>", "</colgroup></table>"],
            tr: [2, "<table><tbody>", "</tbody></table>"],
            td: [3, "<table><tbody><tr>", "</tr></tbody></table>"],
            _default: [0, "", ""]
        };

    function je(e, n) {
        var i = typeof e.getElementsByTagName < "u" ? e.getElementsByTagName(n || "*") : typeof e.querySelectorAll < "u" ? e.querySelectorAll(n || "*") : [];
        return void 0 === n || n && r.nodeName(e, n) ? r.merge([e], i) : i
    }

    function On(e, n) {
        for (var i = 0, o = e.length; i < o; i++) Y.set(e[i], "globalEval", !n || Y.get(n[i], "globalEval"))
    }
    Le.optgroup = Le.option, Le.tbody = Le.tfoot = Le.colgroup = Le.caption = Le.thead, Le.th = Le.td;
    var n, i, ni = /<|&#?\w+;/;

    function Ct(e, n, i, o, l) {
        for (var a, u, g, v, b, T, D = n.createDocumentFragment(), w = [], A = 0, W = e.length; A < W; A++)
            if ((a = e[A]) || 0 === a)
                if ("object" === r.type(a)) r.merge(w, a.nodeType ? [a] : a);
                else if (ni.test(a)) {
            for (u = u || D.appendChild(n.createElement("div")), g = (Sn.exec(a) || ["", ""])[1].toLowerCase(), u.innerHTML = (v = Le[g] || Le._default)[1] + r.htmlPrefilter(a) + v[2], T = v[0]; T--;) u = u.lastChild;
            r.merge(w, u.childNodes), (u = D.firstChild).textContent = ""
        } else w.push(n.createTextNode(a));
        for (D.textContent = "", A = 0; a = w[A++];)
            if (o && r.inArray(a, o) > -1) l && l.push(a);
            else if (b = r.contains(a.ownerDocument, a), u = je(D.appendChild(a), "script"), b && On(u), i)
            for (T = 0; a = u[T++];) gn.test(a.type || "") && i.push(a);
        return D
    }
    n = J.createDocumentFragment().appendChild(J.createElement("div")), (i = J.createElement("input")).setAttribute("type", "radio"), i.setAttribute("checked", "checked"), i.setAttribute("name", "t"), n.appendChild(i), de.checkClone = n.cloneNode(!0).cloneNode(!0).lastChild.checked, n.innerHTML = "<textarea>x</textarea>", de.noCloneChecked = !!n.cloneNode(!0).lastChild.defaultValue;
    var Ae = J.documentElement,
        We = /^key/,
        $e = /^(?:mouse|pointer|contextmenu|drag|drop)|click/,
        Ie = /^([^.]*)(?:\.(.+)|)/;

    function Ft() {
        return !0
    }

    function et() {
        return !1
    }

    function At() {
        try {
            return J.activeElement
        } catch {}
    }

    function kt(e, n, i, o, l, a) {
        var u, g;
        if ("object" == typeof n) {
            for (g in "string" != typeof i && (o = o || i, i = void 0), n) kt(e, g, i, o, n[g], a);
            return e
        }
        if (null == o && null == l ? (l = i, o = i = void 0) : null == l && ("string" == typeof i ? (l = o, o = void 0) : (l = o, o = i, i = void 0)), !1 === l) l = et;
        else if (!l) return e;
        return 1 === a && (u = l, l = function(v) {
            return r().off(v), u.apply(this, arguments)
        }, l.guid = u.guid || (u.guid = r.guid++)), e.each(function() {
            r.event.add(this, n, l, o, i)
        })
    }
    r.event = {
        global: {},
        add: function(e, n, i, o, l) {
            var a, u, g, v, b, T, D, w, A, W, K, M = Y.get(e);
            if (M)
                for (i.handler && (i = (a = i).handler, l = a.selector), l && r.find.matchesSelector(Ae, l), i.guid || (i.guid = r.guid++), (v = M.events) || (v = M.events = {}), (u = M.handle) || (u = M.handle = function(oe) {
                        return typeof r < "u" && r.event.triggered !== oe.type ? r.event.dispatch.apply(e, arguments) : void 0
                    }), b = (n = (n || "").match(Ce) || [""]).length; b--;) A = K = (g = Ie.exec(n[b]) || [])[1], W = (g[2] || "").split(".").sort(), A && (D = r.event.special[A] || {}, D = r.event.special[A = (l ? D.delegateType : D.bindType) || A] || {}, T = r.extend({
                    type: A,
                    origType: K,
                    data: o,
                    handler: i,
                    guid: i.guid,
                    selector: l,
                    needsContext: l && r.expr.match.needsContext.test(l),
                    namespace: W.join(".")
                }, a), (w = v[A]) || ((w = v[A] = []).delegateCount = 0, D.setup && !1 !== D.setup.call(e, o, W, u) || e.addEventListener && e.addEventListener(A, u)), D.add && (D.add.call(e, T), T.handler.guid || (T.handler.guid = i.guid)), l ? w.splice(w.delegateCount++, 0, T) : w.push(T), r.event.global[A] = !0)
        },
        remove: function(e, n, i, o, l) {
            var a, u, g, v, b, T, D, w, A, W, K, M = Y.hasData(e) && Y.get(e);
            if (M && (v = M.events)) {
                for (b = (n = (n || "").match(Ce) || [""]).length; b--;)
                    if (A = K = (g = Ie.exec(n[b]) || [])[1], W = (g[2] || "").split(".").sort(), A) {
                        for (D = r.event.special[A] || {}, w = v[A = (o ? D.delegateType : D.bindType) || A] || [], g = g[2] && new RegExp("(^|\\.)" + W.join("\\.(?:.*\\.|)") + "(\\.|$)"), u = a = w.length; a--;) T = w[a], !l && K !== T.origType || i && i.guid !== T.guid || g && !g.test(T.namespace) || o && o !== T.selector && ("**" !== o || !T.selector) || (w.splice(a, 1), T.selector && w.delegateCount--, D.remove && D.remove.call(e, T));
                        u && !w.length && (D.teardown && !1 !== D.teardown.call(e, W, M.handle) || r.removeEvent(e, A, M.handle), delete v[A])
                    } else
                        for (A in v) r.event.remove(e, A + n[b], i, o, !0);
                r.isEmptyObject(v) && Y.remove(e, "handle events")
            }
        },
        dispatch: function(e) {
            var i, o, l, a, u, g, n = r.event.fix(e),
                v = new Array(arguments.length),
                b = (Y.get(this, "events") || {})[n.type] || [],
                T = r.event.special[n.type] || {};
            for (v[0] = n, i = 1; i < arguments.length; i++) v[i] = arguments[i];
            if (n.delegateTarget = this, !T.preDispatch || !1 !== T.preDispatch.call(this, n)) {
                for (g = r.event.handlers.call(this, n, b), i = 0;
                    (a = g[i++]) && !n.isPropagationStopped();)
                    for (n.currentTarget = a.elem, o = 0;
                        (u = a.handlers[o++]) && !n.isImmediatePropagationStopped();) n.rnamespace && !n.rnamespace.test(u.namespace) || (n.handleObj = u, n.data = u.data, void 0 !== (l = ((r.event.special[u.origType] || {}).handle || u.handler).apply(a.elem, v)) && !1 === (n.result = l) && (n.preventDefault(), n.stopPropagation()));
                return T.postDispatch && T.postDispatch.call(this, n), n.result
            }
        },
        handlers: function(e, n) {
            var i, o, l, a, u = [],
                g = n.delegateCount,
                v = e.target;
            if (g && v.nodeType && ("click" !== e.type || isNaN(e.button) || e.button < 1))
                for (; v !== this; v = v.parentNode || this)
                    if (1 === v.nodeType && (!0 !== v.disabled || "click" !== e.type)) {
                        for (o = [], i = 0; i < g; i++) void 0 === o[l = (a = n[i]).selector + " "] && (o[l] = a.needsContext ? r(l, this).index(v) > -1 : r.find(l, this, null, [v]).length), o[l] && o.push(a);
                        o.length && u.push({
                            elem: v,
                            handlers: o
                        })
                    }
            return g < n.length && u.push({
                elem: this,
                handlers: n.slice(g)
            }), u
        },
        addProp: function(e, n) {
            Object.defineProperty(r.Event.prototype, e, {
                enumerable: !0,
                configurable: !0,
                get: r.isFunction(n) ? function() {
                    if (this.originalEvent) return n(this.originalEvent)
                } : function() {
                    if (this.originalEvent) return this.originalEvent[e]
                },
                set: function(i) {
                    Object.defineProperty(this, e, {
                        enumerable: !0,
                        configurable: !0,
                        writable: !0,
                        value: i
                    })
                }
            })
        },
        fix: function(e) {
            return e[r.expando] ? e : new r.Event(e)
        },
        special: {
            load: {
                noBubble: !0
            },
            focus: {
                trigger: function() {
                    if (this !== At() && this.focus) return this.focus(), !1
                },
                delegateType: "focusin"
            },
            blur: {
                trigger: function() {
                    if (this === At() && this.blur) return this.blur(), !1
                },
                delegateType: "focusout"
            },
            click: {
                trigger: function() {
                    if ("checkbox" === this.type && this.click && r.nodeName(this, "input")) return this.click(), !1
                },
                _default: function(e) {
                    return r.nodeName(e.target, "a")
                }
            },
            beforeunload: {
                postDispatch: function(e) {
                    void 0 !== e.result && e.originalEvent && (e.originalEvent.returnValue = e.result)
                }
            }
        }
    }, r.removeEvent = function(e, n, i) {
        e.removeEventListener && e.removeEventListener(n, i)
    }, r.Event = function(e, n) {
        return this instanceof r.Event ? (e && e.type ? (this.originalEvent = e, this.type = e.type, this.isDefaultPrevented = e.defaultPrevented || void 0 === e.defaultPrevented && !1 === e.returnValue ? Ft : et, this.target = e.target && 3 === e.target.nodeType ? e.target.parentNode : e.target, this.currentTarget = e.currentTarget, this.relatedTarget = e.relatedTarget) : this.type = e, n && r.extend(this, n), this.timeStamp = e && e.timeStamp || r.now(), void(this[r.expando] = !0)) : new r.Event(e, n)
    }, r.Event.prototype = {
        constructor: r.Event,
        isDefaultPrevented: et,
        isPropagationStopped: et,
        isImmediatePropagationStopped: et,
        isSimulated: !1,
        preventDefault: function() {
            var e = this.originalEvent;
            this.isDefaultPrevented = Ft, e && !this.isSimulated && e.preventDefault()
        },
        stopPropagation: function() {
            var e = this.originalEvent;
            this.isPropagationStopped = Ft, e && !this.isSimulated && e.stopPropagation()
        },
        stopImmediatePropagation: function() {
            var e = this.originalEvent;
            this.isImmediatePropagationStopped = Ft, e && !this.isSimulated && e.stopImmediatePropagation(), this.stopPropagation()
        }
    }, r.each({
        altKey: !0,
        bubbles: !0,
        cancelable: !0,
        changedTouches: !0,
        ctrlKey: !0,
        detail: !0,
        eventPhase: !0,
        metaKey: !0,
        pageX: !0,
        pageY: !0,
        shiftKey: !0,
        view: !0,
        char: !0,
        charCode: !0,
        key: !0,
        keyCode: !0,
        button: !0,
        buttons: !0,
        clientX: !0,
        clientY: !0,
        offsetX: !0,
        offsetY: !0,
        pointerId: !0,
        pointerType: !0,
        screenX: !0,
        screenY: !0,
        targetTouches: !0,
        toElement: !0,
        touches: !0,
        which: function(e) {
            var n = e.button;
            return null == e.which && We.test(e.type) ? null != e.charCode ? e.charCode : e.keyCode : !e.which && void 0 !== n && $e.test(e.type) ? 1 & n ? 1 : 2 & n ? 3 : 4 & n ? 2 : 0 : e.which
        }
    }, r.event.addProp), r.each({
        mouseenter: "mouseover",
        mouseleave: "mouseout",
        pointerenter: "pointerover",
        pointerleave: "pointerout"
    }, function(e, n) {
        r.event.special[e] = {
            delegateType: n,
            bindType: n,
            handle: function(i) {
                var o, a = i.relatedTarget,
                    u = i.handleObj;
                return a && (a === this || r.contains(this, a)) || (i.type = u.origType, o = u.handler.apply(this, arguments), i.type = n), o
            }
        }
    }), r.fn.extend({
        on: function(e, n, i, o) {
            return kt(this, e, n, i, o)
        },
        one: function(e, n, i, o) {
            return kt(this, e, n, i, o, 1)
        },
        off: function(e, n, i) {
            var o, l;
            if (e && e.preventDefault && e.handleObj) return o = e.handleObj, r(e.delegateTarget).off(o.namespace ? o.origType + "." + o.namespace : o.origType, o.selector, o.handler), this;
            if ("object" == typeof e) {
                for (l in e) this.off(l, n, e[l]);
                return this
            }
            return !1 !== n && "function" != typeof n || (i = n, n = void 0), !1 === i && (i = et), this.each(function() {
                r.event.remove(this, e, i, n)
            })
        }
    });
    var Xi = /<(?!area|br|col|embed|hr|img|input|link|meta|param)(([a-z][^\/\0>\x20\t\r\n\f]*)[^>]*)\/>/gi,
        ii = /<script|<style|<link/i,
        Kt = /checked\s*(?:[^=]|=\s*.checked.)/i,
        Vi = /^true\/(.*)/,
        ri = /^\s*<!(?:\[CDATA\[|--)|(?:\]\]|--)>\s*$/g;

    function Dn(e, n) {
        return r.nodeName(e, "table") && r.nodeName(11 !== n.nodeType ? n : n.firstChild, "tr") && e.getElementsByTagName("tbody")[0] || e
    }

    function Yi(e) {
        return e.type = (null !== e.getAttribute("type")) + "/" + e.type, e
    }

    function Ki(e) {
        var n = Vi.exec(e.type);
        return n ? e.type = n[1] : e.removeAttribute("type"), e
    }

    function oi(e, n) {
        var i, o, l, a, u, g, v, b;
        if (1 === n.nodeType) {
            if (Y.hasData(e) && (a = Y.access(e), u = Y.set(n, a), b = a.events))
                for (l in delete u.handle, u.events = {}, b)
                    for (i = 0, o = b[l].length; i < o; i++) r.event.add(n, l, b[l][i]);
            Ne.hasData(e) && (g = Ne.access(e), v = r.extend({}, g), Ne.set(n, v))
        }
    }

    function Qi(e, n) {
        var i = n.nodeName.toLowerCase();
        "input" === i && Ui.test(e.type) ? n.checked = e.checked : "input" !== i && "textarea" !== i || (n.defaultValue = e.defaultValue)
    }

    function Bt(e, n, i, o) {
        n = dt.apply([], n);
        var l, a, u, g, v, b, T = 0,
            D = e.length,
            w = D - 1,
            A = n[0],
            W = r.isFunction(A);
        if (W || D > 1 && "string" == typeof A && !de.checkClone && Kt.test(A)) return e.each(function(K) {
            var M = e.eq(K);
            W && (n[0] = A.call(this, K, M.html())), Bt(M, n, i, o)
        });
        if (D && (a = (l = Ct(n, e[0].ownerDocument, !1, e, o)).firstChild, 1 === l.childNodes.length && (l = a), a || o)) {
            for (g = (u = r.map(je(l, "script"), Yi)).length; T < D; T++) v = l, T !== w && (v = r.clone(v, !0, !0), g && r.merge(u, je(v, "script"))), i.call(e[T], v, T);
            if (g)
                for (b = u[u.length - 1].ownerDocument, r.map(u, Ki), T = 0; T < g; T++) gn.test((v = u[T]).type || "") && !Y.access(v, "globalEval") && r.contains(b, v) && (v.src ? r._evalUrl && r._evalUrl(v.src) : De(v.textContent.replace(ri, ""), b))
        }
        return e
    }

    function si(e, n, i) {
        for (var o, l = n ? r.filter(n, e) : e, a = 0; null != (o = l[a]); a++) i || 1 !== o.nodeType || r.cleanData(je(o)), o.parentNode && (i && r.contains(o.ownerDocument, o) && On(je(o, "script")), o.parentNode.removeChild(o));
        return e
    }
    r.extend({
        htmlPrefilter: function(e) {
            return e.replace(Xi, "<$1></$2>")
        },
        clone: function(e, n, i) {
            var o, l, a, u, g = e.cloneNode(!0),
                v = r.contains(e.ownerDocument, e);
            if (!(de.noCloneChecked || 1 !== e.nodeType && 11 !== e.nodeType || r.isXMLDoc(e)))
                for (u = je(g), o = 0, l = (a = je(e)).length; o < l; o++) Qi(a[o], u[o]);
            if (n)
                if (i)
                    for (a = a || je(e), u = u || je(g), o = 0, l = a.length; o < l; o++) oi(a[o], u[o]);
                else oi(e, g);
            return (u = je(g, "script")).length > 0 && On(u, !v && je(e, "script")), g
        },
        cleanData: function(e) {
            for (var n, i, o, l = r.event.special, a = 0; void 0 !== (i = e[a]); a++)
                if (we(i)) {
                    if (n = i[Y.expando]) {
                        if (n.events)
                            for (o in n.events) l[o] ? r.event.remove(i, o) : r.removeEvent(i, o, n.handle);
                        i[Y.expando] = void 0
                    }
                    i[Ne.expando] && (i[Ne.expando] = void 0)
                }
        }
    }), r.fn.extend({
        detach: function(e) {
            return si(this, e, !0)
        },
        remove: function(e) {
            return si(this, e)
        },
        text: function(e) {
            return Je(this, function(n) {
                return void 0 === n ? r.text(this) : this.empty().each(function() {
                    1 !== this.nodeType && 11 !== this.nodeType && 9 !== this.nodeType || (this.textContent = n)
                })
            }, null, e, arguments.length)
        },
        append: function() {
            return Bt(this, arguments, function(e) {
                1 !== this.nodeType && 11 !== this.nodeType && 9 !== this.nodeType || Dn(this, e).appendChild(e)
            })
        },
        prepend: function() {
            return Bt(this, arguments, function(e) {
                if (1 === this.nodeType || 11 === this.nodeType || 9 === this.nodeType) {
                    var n = Dn(this, e);
                    n.insertBefore(e, n.firstChild)
                }
            })
        },
        before: function() {
            return Bt(this, arguments, function(e) {
                this.parentNode && this.parentNode.insertBefore(e, this)
            })
        },
        after: function() {
            return Bt(this, arguments, function(e) {
                this.parentNode && this.parentNode.insertBefore(e, this.nextSibling)
            })
        },
        empty: function() {
            for (var e, n = 0; null != (e = this[n]); n++) 1 === e.nodeType && (r.cleanData(je(e, !1)), e.textContent = "");
            return this
        },
        clone: function(e, n) {
            return e = null != e && e, n = n ? ? e, this.map(function() {
                return r.clone(this, e, n)
            })
        },
        html: function(e) {
            return Je(this, function(n) {
                var i = this[0] || {},
                    o = 0,
                    l = this.length;
                if (void 0 === n && 1 === i.nodeType) return i.innerHTML;
                if ("string" == typeof n && !ii.test(n) && !Le[(Sn.exec(n) || ["", ""])[1].toLowerCase()]) {
                    n = r.htmlPrefilter(n);
                    try {
                        for (; o < l; o++) 1 === (i = this[o] || {}).nodeType && (r.cleanData(je(i, !1)), i.innerHTML = n);
                        i = 0
                    } catch {}
                }
                i && this.empty().append(n)
            }, null, e, arguments.length)
        },
        replaceWith: function() {
            var e = [];
            return Bt(this, arguments, function(n) {
                var i = this.parentNode;
                r.inArray(this, e) < 0 && (r.cleanData(je(this)), i && i.replaceChild(n, this))
            }, e)
        }
    }), r.each({
        appendTo: "append",
        prependTo: "prepend",
        insertBefore: "before",
        insertAfter: "after",
        replaceAll: "replaceWith"
    }, function(e, n) {
        r.fn[e] = function(i) {
            for (var o, l = [], a = r(i), u = a.length - 1, g = 0; g <= u; g++) o = g === u ? this : this.clone(!0), r(a[g])[n](o), Ke.apply(l, o.get());
            return this.pushStack(l)
        }
    });
    var ai = /^margin/,
        Nn = new RegExp("^(" + Et + ")(?!px)[a-z%]+$", "i"),
        mn = function(e) {
            var n = e.ownerDocument.defaultView;
            return n && n.opener || (n = F), n.getComputedStyle(e)
        };

    function Qt(e, n, i) {
        var o, l, a, u, g = e.style;
        return (i = i || mn(e)) && ("" !== (u = i.getPropertyValue(n) || i[n]) || r.contains(e.ownerDocument, e) || (u = r.style(e, n)), !de.pixelMarginRight() && Nn.test(u) && ai.test(n) && (o = g.width, l = g.minWidth, a = g.maxWidth, g.minWidth = g.maxWidth = g.width = u, u = i.width, g.width = o, g.minWidth = l, g.maxWidth = a)), void 0 !== u ? u + "" : u
    }

    function tt(e, n) {
        return {
            get: function() {
                return e() ? void delete this.get : (this.get = n).apply(this, arguments)
            }
        }
    }! function() {
        function e() {
            if (u) {
                u.style.cssText = "box-sizing:border-box;position:relative;display:block;margin:auto;border:1px;padding:1px;top:1%;width:50%", u.innerHTML = "", Ae.appendChild(a);
                var g = F.getComputedStyle(u);
                n = "1%" !== g.top, l = "2px" === g.marginLeft, i = "4px" === g.width, u.style.marginRight = "50%", o = "4px" === g.marginRight, Ae.removeChild(a), u = null
            }
        }
        var n, i, o, l, a = J.createElement("div"),
            u = J.createElement("div");
        u.style && (u.style.backgroundClip = "content-box", u.cloneNode(!0).style.backgroundClip = "", de.clearCloneStyle = "content-box" === u.style.backgroundClip, a.style.cssText = "border:0;width:8px;height:0;top:0;left:-9999px;padding:0;margin-top:1px;position:absolute", a.appendChild(u), r.extend(de, {
            pixelPosition: function() {
                return e(), n
            },
            boxSizingReliable: function() {
                return e(), i
            },
            pixelMarginRight: function() {
                return e(), o
            },
            reliableMarginLeft: function() {
                return e(), l
            }
        }))
    }();
    var nt = /^(none|table(?!-c[ea]).+)/,
        vn = {
            position: "absolute",
            visibility: "hidden",
            display: "block"
        },
        ze = {
            letterSpacing: "0",
            fontWeight: "400"
        },
        li = ["Webkit", "Moz", "ms"],
        Ln = J.createElement("div").style;

    function it(e) {
        if (e in Ln) return e;
        for (var n = e[0].toUpperCase() + e.slice(1), i = li.length; i--;)
            if ((e = li[i] + n) in Ln) return e
    }

    function Wt(e, n, i) {
        var o = gt.exec(n);
        return o ? Math.max(0, o[2] - (i || 0)) + (o[3] || "px") : n
    }

    function jn(e, n, i, o, l) {
        for (var a = i === (o ? "border" : "content") ? 4 : "width" === n ? 1 : 0, u = 0; a < 4; a += 2) "margin" === i && (u += r.css(e, i + Mt[a], !0, l)), o ? ("content" === i && (u -= r.css(e, "padding" + Mt[a], !0, l)), "margin" !== i && (u -= r.css(e, "border" + Mt[a] + "Width", !0, l))) : (u += r.css(e, "padding" + Mt[a], !0, l), "padding" !== i && (u += r.css(e, "border" + Mt[a] + "Width", !0, l)));
        return u
    }

    function ci(e, n, i) {
        var o, l = !0,
            a = mn(e),
            u = "border-box" === r.css(e, "boxSizing", !1, a);
        if (e.getClientRects().length && (o = e.getBoundingClientRect()[n]), o <= 0 || null == o) {
            if (((o = Qt(e, n, a)) < 0 || null == o) && (o = e.style[n]), Nn.test(o)) return o;
            l = u && (de.boxSizingReliable() || o === e.style[n]), o = parseFloat(o) || 0
        }
        return o + jn(e, n, i || (u ? "border" : "content"), l, a) + "px"
    }

    function ye(e, n, i, o, l) {
        return new ye.prototype.init(e, n, i, o, l)
    }
    r.extend({
        cssHooks: {
            opacity: {
                get: function(e, n) {
                    if (n) {
                        var i = Qt(e, "opacity");
                        return "" === i ? "1" : i
                    }
                }
            }
        },
        cssNumber: {
            animationIterationCount: !0,
            columnCount: !0,
            fillOpacity: !0,
            flexGrow: !0,
            flexShrink: !0,
            fontWeight: !0,
            lineHeight: !0,
            opacity: !0,
            order: !0,
            orphans: !0,
            widows: !0,
            zIndex: !0,
            zoom: !0
        },
        cssProps: {
            float: "cssFloat"
        },
        style: function(e, n, i, o) {
            if (e && 3 !== e.nodeType && 8 !== e.nodeType && e.style) {
                var l, a, u, g = r.camelCase(n),
                    v = e.style;
                return n = r.cssProps[g] || (r.cssProps[g] = it(g) || g), u = r.cssHooks[n] || r.cssHooks[g], void 0 === i ? u && "get" in u && void 0 !== (l = u.get(e, !1, o)) ? l : v[n] : ("string" == (a = typeof i) && (l = gt.exec(i)) && l[1] && (i = pn(e, n, l), a = "number"), void(null != i && i == i && ("number" === a && (i += l && l[3] || (r.cssNumber[g] ? "" : "px")), de.clearCloneStyle || "" !== i || 0 !== n.indexOf("background") || (v[n] = "inherit"), u && "set" in u && void 0 === (i = u.set(e, i, o)) || (v[n] = i))))
            }
        },
        css: function(e, n, i, o) {
            var l, a, u, g = r.camelCase(n);
            return n = r.cssProps[g] || (r.cssProps[g] = it(g) || g), (u = r.cssHooks[n] || r.cssHooks[g]) && "get" in u && (l = u.get(e, !0, i)), void 0 === l && (l = Qt(e, n, o)), "normal" === l && n in ze && (l = ze[n]), "" === i || i ? (a = parseFloat(l), !0 === i || isFinite(a) ? a || 0 : l) : l
        }
    }), r.each(["height", "width"], function(e, n) {
        r.cssHooks[n] = {
            get: function(i, o, l) {
                if (o) return !nt.test(r.css(i, "display")) || i.getClientRects().length && i.getBoundingClientRect().width ? ci(i, n, l) : Tt(i, vn, function() {
                    return ci(i, n, l)
                })
            },
            set: function(i, o, l) {
                var a, u = l && mn(i),
                    g = l && jn(i, n, l, "border-box" === r.css(i, "boxSizing", !1, u), u);
                return g && (a = gt.exec(o)) && "px" !== (a[3] || "px") && (i.style[n] = o, o = r.css(i, n)), Wt(0, o, g)
            }
        }
    }), r.cssHooks.marginLeft = tt(de.reliableMarginLeft, function(e, n) {
        if (n) return (parseFloat(Qt(e, "marginLeft")) || e.getBoundingClientRect().left - Tt(e, {
            marginLeft: 0
        }, function() {
            return e.getBoundingClientRect().left
        })) + "px"
    }), r.each({
        margin: "",
        padding: "",
        border: "Width"
    }, function(e, n) {
        r.cssHooks[e + n] = {
            expand: function(i) {
                for (var o = 0, l = {}, a = "string" == typeof i ? i.split(" ") : [i]; o < 4; o++) l[e + Mt[o] + n] = a[o] || a[o - 2] || a[0];
                return l
            }
        }, ai.test(e) || (r.cssHooks[e + n].set = Wt)
    }), r.fn.extend({
        css: function(e, n) {
            return Je(this, function(i, o, l) {
                var a, u, g = {},
                    v = 0;
                if (r.isArray(o)) {
                    for (a = mn(i), u = o.length; v < u; v++) g[o[v]] = r.css(i, o[v], !1, a);
                    return g
                }
                return void 0 !== l ? r.style(i, o, l) : r.css(i, o)
            }, e, n, arguments.length > 1)
        }
    }), r.Tween = ye, ye.prototype = {
        constructor: ye,
        init: function(e, n, i, o, l, a) {
            this.elem = e, this.prop = i, this.easing = l || r.easing._default, this.options = n, this.start = this.now = this.cur(), this.end = o, this.unit = a || (r.cssNumber[i] ? "" : "px")
        },
        cur: function() {
            var e = ye.propHooks[this.prop];
            return e && e.get ? e.get(this) : ye.propHooks._default.get(this)
        },
        run: function(e) {
            var n, i = ye.propHooks[this.prop];
            return this.pos = n = this.options.duration ? r.easing[this.easing](e, this.options.duration * e, 0, 1, this.options.duration) : e, this.now = (this.end - this.start) * n + this.start, this.options.step && this.options.step.call(this.elem, this.now, this), i && i.set ? i.set(this) : ye.propHooks._default.set(this), this
        }
    }, ye.prototype.init.prototype = ye.prototype, ye.propHooks = {
        _default: {
            get: function(e) {
                var n;
                return 1 !== e.elem.nodeType || null != e.elem[e.prop] && null == e.elem.style[e.prop] ? e.elem[e.prop] : (n = r.css(e.elem, e.prop, "")) && "auto" !== n ? n : 0
            },
            set: function(e) {
                r.fx.step[e.prop] ? r.fx.step[e.prop](e) : 1 !== e.elem.nodeType || null == e.elem.style[r.cssProps[e.prop]] && !r.cssHooks[e.prop] ? e.elem[e.prop] = e.now : r.style(e.elem, e.prop, e.now + e.unit)
            }
        }
    }, ye.propHooks.scrollTop = ye.propHooks.scrollLeft = {
        set: function(e) {
            e.elem.nodeType && e.elem.parentNode && (e.elem[e.prop] = e.now)
        }
    }, r.easing = {
        linear: function(e) {
            return e
        },
        swing: function(e) {
            return .5 - Math.cos(e * Math.PI) / 2
        },
        _default: "swing"
    }, r.fx = ye.prototype.init, r.fx.step = {};
    var Gt, Ue, In = /^(?:toggle|show|hide)$/,
        Gi = /queueHooks$/;

    function Jt() {
        Ue && (F.requestAnimationFrame(Jt), r.fx.tick())
    }

    function Pn() {
        return F.setTimeout(function() {
            Gt = void 0
        }), Gt = r.now()
    }

    function rt(e, n) {
        var i, o = 0,
            l = {
                height: e
            };
        for (n = n ? 1 : 0; o < 4; o += 2 - n) l["margin" + (i = Mt[o])] = l["padding" + i] = e;
        return n && (l.opacity = l.width = e), l
    }

    function Zt(e, n, i) {
        for (var o, l = (Qe.tweeners[n] || []).concat(Qe.tweeners["*"]), a = 0, u = l.length; a < u; a++)
            if (o = l[a].call(i, n, e)) return o
    }

    function Qe(e, n, i) {
        var o, l, a = 0,
            u = Qe.prefilters.length,
            g = r.Deferred().always(function() {
                delete v.elem
            }),
            v = function() {
                if (l) return !1;
                for (var D = Gt || Pn(), w = Math.max(0, b.startTime + b.duration - D), W = 1 - (w / b.duration || 0), K = 0, M = b.tweens.length; K < M; K++) b.tweens[K].run(W);
                return g.notifyWith(e, [b, W, w]), W < 1 && M ? w : (g.resolveWith(e, [b]), !1)
            },
            b = g.promise({
                elem: e,
                props: r.extend({}, n),
                opts: r.extend(!0, {
                    specialEasing: {},
                    easing: r.easing._default
                }, i),
                originalProperties: n,
                originalOptions: i,
                startTime: Gt || Pn(),
                duration: i.duration,
                tweens: [],
                createTween: function(D, w) {
                    var A = r.Tween(e, b.opts, D, w, b.opts.specialEasing[D] || b.opts.easing);
                    return b.tweens.push(A), A
                },
                stop: function(D) {
                    var w = 0,
                        A = D ? b.tweens.length : 0;
                    if (l) return this;
                    for (l = !0; w < A; w++) b.tweens[w].run(1);
                    return D ? (g.notifyWith(e, [b, 1, 0]), g.resolveWith(e, [b, D])) : g.rejectWith(e, [b, D]), this
                }
            }),
            T = b.props;
        for (function Hn(e, n) {
                var i, o, l, a, u;
                for (i in e)
                    if (l = n[o = r.camelCase(i)], r.isArray(a = e[i]) && (l = a[1], a = e[i] = a[0]), i !== o && (e[o] = a, delete e[i]), (u = r.cssHooks[o]) && "expand" in u)
                        for (i in a = u.expand(a), delete e[o], a) i in e || (e[i] = a[i], n[i] = l);
                    else n[o] = l
            }(T, b.opts.specialEasing); a < u; a++)
            if (o = Qe.prefilters[a].call(b, e, T, b.opts)) return r.isFunction(o.stop) && (r._queueHooks(b.elem, b.opts.queue).stop = r.proxy(o.stop, o)), o;
        return r.map(T, Zt, b), r.isFunction(b.opts.start) && b.opts.start.call(e, b), r.fx.timer(r.extend(v, {
            elem: e,
            anim: b,
            queue: b.opts.queue
        })), b.progress(b.opts.progress).done(b.opts.done, b.opts.complete).fail(b.opts.fail).always(b.opts.always)
    }
    r.Animation = r.extend(Qe, {
            tweeners: {
                "*": [function(e, n) {
                    var i = this.createTween(e, n);
                    return pn(i.elem, e, gt.exec(n), i), i
                }]
            },
            tweener: function(e, n) {
                r.isFunction(e) ? (n = e, e = ["*"]) : e = e.match(Ce);
                for (var i, o = 0, l = e.length; o < l; o++)(Qe.tweeners[i = e[o]] = Qe.tweeners[i] || []).unshift(n)
            },
            prefilters: [function qn(e, n, i) {
                var o, l, a, u, g, v, b, T, D = "width" in n || "height" in n,
                    w = this,
                    A = {},
                    W = e.style,
                    K = e.nodeType && dn(e),
                    M = Y.get(e, "fxshow");
                for (o in i.queue || (null == (u = r._queueHooks(e, "fx")).unqueued && (u.unqueued = 0, g = u.empty.fire, u.empty.fire = function() {
                        u.unqueued || g()
                    }), u.unqueued++, w.always(function() {
                        w.always(function() {
                            u.unqueued--, r.queue(e, "fx").length || u.empty.fire()
                        })
                    })), n)
                    if (In.test(l = n[o])) {
                        if (delete n[o], a = a || "toggle" === l, l === (K ? "hide" : "show")) {
                            if ("show" !== l || !M || void 0 === M[o]) continue;
                            K = !0
                        }
                        A[o] = M && M[o] || r.style(e, o)
                    }
                if ((v = !r.isEmptyObject(n)) || !r.isEmptyObject(A))
                    for (o in D && 1 === e.nodeType && (i.overflow = [W.overflow, W.overflowX, W.overflowY], null == (b = M && M.display) && (b = Y.get(e, "display")), "none" === (T = r.css(e, "display")) && (b ? T = b : (Rt([e], !0), b = e.style.display || b, T = r.css(e, "display"), Rt([e]))), ("inline" === T || "inline-block" === T && null != b) && "none" === r.css(e, "float") && (v || (w.done(function() {
                            W.display = b
                        }), null == b && (b = "none" === (T = W.display) ? "" : T)), W.display = "inline-block")), i.overflow && (W.overflow = "hidden", w.always(function() {
                            W.overflow = i.overflow[0], W.overflowX = i.overflow[1], W.overflowY = i.overflow[2]
                        })), v = !1, A) v || (M ? "hidden" in M && (K = M.hidden) : M = Y.access(e, "fxshow", {
                        display: b
                    }), a && (M.hidden = !K), K && Rt([e], !0), w.done(function() {
                        for (o in K || Rt([e]), Y.remove(e, "fxshow"), A) r.style(e, o, A[o])
                    })), v = Zt(K ? M[o] : 0, o, w), o in M || (M[o] = v.start, K && (v.end = v.start, v.start = 0))
            }],
            prefilter: function(e, n) {
                n ? Qe.prefilters.unshift(e) : Qe.prefilters.push(e)
            }
        }), r.speed = function(e, n, i) {
            var o = e && "object" == typeof e ? r.extend({}, e) : {
                complete: i || !i && n || r.isFunction(e) && e,
                duration: e,
                easing: i && n || n && !r.isFunction(n) && n
            };
            return o.duration = r.fx.off || J.hidden ? 0 : "number" == typeof o.duration ? o.duration : o.duration in r.fx.speeds ? r.fx.speeds[o.duration] : r.fx.speeds._default, null != o.queue && !0 !== o.queue || (o.queue = "fx"), o.old = o.complete, o.complete = function() {
                r.isFunction(o.old) && o.old.call(this), o.queue && r.dequeue(this, o.queue)
            }, o
        }, r.fn.extend({
            fadeTo: function(e, n, i, o) {
                return this.filter(dn).css("opacity", 0).show().end().animate({
                    opacity: n
                }, e, i, o)
            },
            animate: function(e, n, i, o) {
                var l = r.isEmptyObject(e),
                    a = r.speed(n, i, o),
                    u = function() {
                        var g = Qe(this, r.extend({}, e), a);
                        (l || Y.get(this, "finish")) && g.stop(!0)
                    };
                return u.finish = u, l || !1 === a.queue ? this.each(u) : this.queue(a.queue, u)
            },
            stop: function(e, n, i) {
                var o = function(l) {
                    var a = l.stop;
                    delete l.stop, a(i)
                };
                return "string" != typeof e && (i = n, n = e, e = void 0), n && !1 !== e && this.queue(e || "fx", []), this.each(function() {
                    var l = !0,
                        a = null != e && e + "queueHooks",
                        u = r.timers,
                        g = Y.get(this);
                    if (a) g[a] && g[a].stop && o(g[a]);
                    else
                        for (a in g) g[a] && g[a].stop && Gi.test(a) && o(g[a]);
                    for (a = u.length; a--;) u[a].elem !== this || null != e && u[a].queue !== e || (u[a].anim.stop(i), l = !1, u.splice(a, 1));
                    !l && i || r.dequeue(this, e)
                })
            },
            finish: function(e) {
                return !1 !== e && (e = e || "fx"), this.each(function() {
                    var n, i = Y.get(this),
                        o = i[e + "queue"],
                        l = i[e + "queueHooks"],
                        a = r.timers,
                        u = o ? o.length : 0;
                    for (i.finish = !0, r.queue(this, e, []), l && l.stop && l.stop.call(this, !0), n = a.length; n--;) a[n].elem === this && a[n].queue === e && (a[n].anim.stop(!0), a.splice(n, 1));
                    for (n = 0; n < u; n++) o[n] && o[n].finish && o[n].finish.call(this);
                    delete i.finish
                })
            }
        }), r.each(["toggle", "show", "hide"], function(e, n) {
            var i = r.fn[n];
            r.fn[n] = function(o, l, a) {
                return null == o || "boolean" == typeof o ? i.apply(this, arguments) : this.animate(rt(n, !0), o, l, a)
            }
        }), r.each({
            slideDown: rt("show"),
            slideUp: rt("hide"),
            slideToggle: rt("toggle"),
            fadeIn: {
                opacity: "show"
            },
            fadeOut: {
                opacity: "hide"
            },
            fadeToggle: {
                opacity: "toggle"
            }
        }, function(e, n) {
            r.fn[e] = function(i, o, l) {
                return this.animate(n, i, o, l)
            }
        }), r.timers = [], r.fx.tick = function() {
            var e, n = 0,
                i = r.timers;
            for (Gt = r.now(); n < i.length; n++)(e = i[n])() || i[n] !== e || i.splice(n--, 1);
            i.length || r.fx.stop(), Gt = void 0
        }, r.fx.timer = function(e) {
            r.timers.push(e), e() ? r.fx.start() : r.timers.pop()
        }, r.fx.interval = 13, r.fx.start = function() {
            Ue || (Ue = F.requestAnimationFrame ? F.requestAnimationFrame(Jt) : F.setInterval(r.fx.tick, r.fx.interval))
        }, r.fx.stop = function() {
            F.cancelAnimationFrame ? F.cancelAnimationFrame(Ue) : F.clearInterval(Ue), Ue = null
        }, r.fx.speeds = {
            slow: 600,
            fast: 200,
            _default: 400
        }, r.fn.delay = function(e, n) {
            return e = r.fx && r.fx.speeds[e] || e, this.queue(n = n || "fx", function(i, o) {
                var l = F.setTimeout(i, e);
                o.stop = function() {
                    F.clearTimeout(l)
                }
            })
        },
        function() {
            var e = J.createElement("input"),
                i = J.createElement("select").appendChild(J.createElement("option"));
            e.type = "checkbox", de.checkOn = "" !== e.value, de.optSelected = i.selected, (e = J.createElement("input")).value = "t", e.type = "radio", de.radioValue = "t" === e.value
        }();
    var ui, en = r.expr.attrHandle;
    r.fn.extend({
        attr: function(e, n) {
            return Je(this, r.attr, e, n, arguments.length > 1)
        },
        removeAttr: function(e) {
            return this.each(function() {
                r.removeAttr(this, e)
            })
        }
    }), r.extend({
        attr: function(e, n, i) {
            var o, l, a = e.nodeType;
            if (3 !== a && 8 !== a && 2 !== a) return typeof e.getAttribute > "u" ? r.prop(e, n, i) : (1 === a && r.isXMLDoc(e) || (l = r.attrHooks[n.toLowerCase()] || (r.expr.match.bool.test(n) ? ui : void 0)), void 0 !== i ? null === i ? void r.removeAttr(e, n) : l && "set" in l && void 0 !== (o = l.set(e, i, n)) ? o : (e.setAttribute(n, i + ""), i) : l && "get" in l && null !== (o = l.get(e, n)) ? o : (o = r.find.attr(e, n)) ? ? void 0)
        },
        attrHooks: {
            type: {
                set: function(e, n) {
                    if (!de.radioValue && "radio" === n && r.nodeName(e, "input")) {
                        var i = e.value;
                        return e.setAttribute("type", n), i && (e.value = i), n
                    }
                }
            }
        },
        removeAttr: function(e, n) {
            var i, o = 0,
                l = n && n.match(Ce);
            if (l && 1 === e.nodeType)
                for (; i = l[o++];) e.removeAttribute(i)
        }
    }), ui = {
        set: function(e, n, i) {
            return !1 === n ? r.removeAttr(e, i) : e.setAttribute(i, i), i
        }
    }, r.each(r.expr.match.bool.source.match(/\w+/g), function(e, n) {
        var i = en[n] || r.find.attr;
        en[n] = function(o, l, a) {
            var u, g, v = l.toLowerCase();
            return a || (g = en[v], en[v] = u, u = null != i(o, l, a) ? v : null, en[v] = g), u
        }
    });
    var tn = /^(?:input|select|textarea|button)$/i,
        br = /^(?:a|area)$/i;
    r.fn.extend({
        prop: function(e, n) {
            return Je(this, r.prop, e, n, arguments.length > 1)
        },
        removeProp: function(e) {
            return this.each(function() {
                delete this[r.propFix[e] || e]
            })
        }
    }), r.extend({
        prop: function(e, n, i) {
            var o, l, a = e.nodeType;
            if (3 !== a && 8 !== a && 2 !== a) return 1 === a && r.isXMLDoc(e) || (l = r.propHooks[n = r.propFix[n] || n]), void 0 !== i ? l && "set" in l && void 0 !== (o = l.set(e, i, n)) ? o : e[n] = i : l && "get" in l && null !== (o = l.get(e, n)) ? o : e[n]
        },
        propHooks: {
            tabIndex: {
                get: function(e) {
                    var n = r.find.attr(e, "tabindex");
                    return n ? parseInt(n, 10) : tn.test(e.nodeName) || br.test(e.nodeName) && e.href ? 0 : -1
                }
            }
        },
        propFix: {
            for: "htmlFor",
            class: "className"
        }
    }), de.optSelected || (r.propHooks.selected = {
        get: function(e) {
            return null
        },
        set: function(e) {}
    }), r.each(["tabIndex", "readOnly", "maxLength", "cellSpacing", "cellPadding", "rowSpan", "colSpan", "useMap", "frameBorder", "contentEditable"], function() {
        r.propFix[this.toLowerCase()] = this
    });
    var Mn = /[\t\r\n\f]/g;

    function mt(e) {
        return e.getAttribute && e.getAttribute("class") || ""
    }
    r.fn.extend({
        addClass: function(e) {
            var n, i, o, l, a, u, g, v = 0;
            if (r.isFunction(e)) return this.each(function(b) {
                r(this).addClass(e.call(this, b, mt(this)))
            });
            if ("string" == typeof e && e)
                for (n = e.match(Ce) || []; i = this[v++];)
                    if (l = mt(i), o = 1 === i.nodeType && (" " + l + " ").replace(Mn, " ")) {
                        for (u = 0; a = n[u++];) o.indexOf(" " + a + " ") < 0 && (o += a + " ");
                        l !== (g = r.trim(o)) && i.setAttribute("class", g)
                    }
            return this
        },
        removeClass: function(e) {
            var n, i, o, l, a, u, g, v = 0;
            if (r.isFunction(e)) return this.each(function(b) {
                r(this).removeClass(e.call(this, b, mt(this)))
            });
            if (!arguments.length) return this.attr("class", "");
            if ("string" == typeof e && e)
                for (n = e.match(Ce) || []; i = this[v++];)
                    if (l = mt(i), o = 1 === i.nodeType && (" " + l + " ").replace(Mn, " ")) {
                        for (u = 0; a = n[u++];)
                            for (; o.indexOf(" " + a + " ") > -1;) o = o.replace(" " + a + " ", " ");
                        l !== (g = r.trim(o)) && i.setAttribute("class", g)
                    }
            return this
        },
        toggleClass: function(e, n) {
            var i = typeof e;
            return "boolean" == typeof n && "string" === i ? n ? this.addClass(e) : this.removeClass(e) : r.isFunction(e) ? this.each(function(o) {
                r(this).toggleClass(e.call(this, o, mt(this), n), n)
            }) : this.each(function() {
                var o, l, a, u;
                if ("string" === i)
                    for (l = 0, a = r(this), u = e.match(Ce) || []; o = u[l++];) a.hasClass(o) ? a.removeClass(o) : a.addClass(o);
                else void 0 !== e && "boolean" !== i || ((o = mt(this)) && Y.set(this, "__className__", o), this.setAttribute && this.setAttribute("class", o || !1 === e ? "" : Y.get(this, "__className__") || ""))
            })
        },
        hasClass: function(e) {
            var n, i, o = 0;
            for (n = " " + e + " "; i = this[o++];)
                if (1 === i.nodeType && (" " + mt(i) + " ").replace(Mn, " ").indexOf(n) > -1) return !0;
            return !1
        }
    });
    var Rn = /\r/g,
        hi = /[\x20\t\r\n\f]+/g;
    r.fn.extend({
        val: function(e) {
            var n, i, o, l = this[0];
            return arguments.length ? (o = r.isFunction(e), this.each(function(a) {
                var u;
                1 === this.nodeType && (null == (u = o ? e.call(this, a, r(this).val()) : e) ? u = "" : "number" == typeof u ? u += "" : r.isArray(u) && (u = r.map(u, function(g) {
                    return null == g ? "" : g + ""
                })), (n = r.valHooks[this.type] || r.valHooks[this.nodeName.toLowerCase()]) && "set" in n && void 0 !== n.set(this, u, "value") || (this.value = u))
            })) : l ? (n = r.valHooks[l.type] || r.valHooks[l.nodeName.toLowerCase()]) && "get" in n && void 0 !== (i = n.get(l, "value")) ? i : "string" == typeof(i = l.value) ? i.replace(Rn, "") : i ? ? "" : void 0
        }
    }), r.extend({
        valHooks: {
            option: {
                get: function(e) {
                    return r.find.attr(e, "value") ? ? r.trim(r.text(e)).replace(hi, " ")
                }
            },
            select: {
                get: function(e) {
                    for (var n, i, o = e.options, l = e.selectedIndex, a = "select-one" === e.type, u = a ? null : [], g = a ? l + 1 : o.length, v = l < 0 ? g : a ? l : 0; v < g; v++)
                        if (((i = o[v]).selected || v === l) && !i.disabled && (!i.parentNode.disabled || !r.nodeName(i.parentNode, "optgroup"))) {
                            if (n = r(i).val(), a) return n;
                            u.push(n)
                        }
                    return u
                },
                set: function(e, n) {
                    for (var i, o, l = e.options, a = r.makeArray(n), u = l.length; u--;)((o = l[u]).selected = r.inArray(r.valHooks.option.get(o), a) > -1) && (i = !0);
                    return i || (e.selectedIndex = -1), a
                }
            }
        }
    }), r.each(["radio", "checkbox"], function() {
        r.valHooks[this] = {
            set: function(e, n) {
                if (r.isArray(n)) return e.checked = r.inArray(r(e).val(), n) > -1
            }
        }, de.checkOn || (r.valHooks[this].get = function(e) {
            return null === e.getAttribute("value") ? "on" : e.value
        })
    });
    var Ji = /^(?:focusinfocus|focusoutblur)$/;
    r.extend(r.event, {
        trigger: function(e, n, i, o) {
            var l, a, u, g, v, b, T, D = [i || J],
                w = Lt.call(e, "type") ? e.type : e,
                A = Lt.call(e, "namespace") ? e.namespace.split(".") : [];
            if (a = u = i = i || J, 3 !== i.nodeType && 8 !== i.nodeType && !Ji.test(w + r.event.triggered) && (w.indexOf(".") > -1 && (A = w.split("."), w = A.shift(), A.sort()), v = w.indexOf(":") < 0 && "on" + w, (e = e[r.expando] ? e : new r.Event(w, "object" == typeof e && e)).isTrigger = o ? 2 : 3, e.namespace = A.join("."), e.rnamespace = e.namespace ? new RegExp("(^|\\.)" + A.join("\\.(?:.*\\.|)") + "(\\.|$)") : null, e.result = void 0, e.target || (e.target = i), n = null == n ? [e] : r.makeArray(n, [e]), T = r.event.special[w] || {}, o || !T.trigger || !1 !== T.trigger.apply(i, n))) {
                if (!o && !T.noBubble && !r.isWindow(i)) {
                    for (Ji.test((g = T.delegateType || w) + w) || (a = a.parentNode); a; a = a.parentNode) D.push(a), u = a;
                    u === (i.ownerDocument || J) && D.push(u.defaultView || u.parentWindow || F)
                }
                for (l = 0;
                    (a = D[l++]) && !e.isPropagationStopped();) e.type = l > 1 ? g : T.bindType || w, (b = (Y.get(a, "events") || {})[e.type] && Y.get(a, "handle")) && b.apply(a, n), (b = v && a[v]) && b.apply && we(a) && (e.result = b.apply(a, n), !1 === e.result && e.preventDefault());
                return e.type = w, o || e.isDefaultPrevented() || T._default && !1 !== T._default.apply(D.pop(), n) || !we(i) || v && r.isFunction(i[w]) && !r.isWindow(i) && ((u = i[v]) && (i[v] = null), r.event.triggered = w, i[w](), r.event.triggered = void 0, u && (i[v] = u)), e.result
            }
        },
        simulate: function(e, n, i) {
            var o = r.extend(new r.Event, i, {
                type: e,
                isSimulated: !0
            });
            r.event.trigger(o, null, n)
        }
    }), r.fn.extend({
        trigger: function(e, n) {
            return this.each(function() {
                r.event.trigger(e, n, this)
            })
        },
        triggerHandler: function(e, n) {
            var i = this[0];
            if (i) return r.event.trigger(e, n, i, !0)
        }
    }), r.each("blur focus focusin focusout resize scroll click dblclick mousedown mouseup mousemove mouseover mouseout mouseenter mouseleave change select submit keydown keypress keyup contextmenu".split(" "), function(e, n) {
        r.fn[n] = function(i, o) {
            return arguments.length > 0 ? this.on(n, null, i, o) : this.trigger(n)
        }
    }), r.fn.extend({
        hover: function(e, n) {
            return this.mouseenter(e).mouseleave(n || e)
        }
    }), de.focusin = "onfocusin" in F, de.focusin || r.each({
        focus: "focusin",
        blur: "focusout"
    }, function(e, n) {
        var i = function(o) {
            r.event.simulate(n, o.target, r.event.fix(o))
        };
        r.event.special[n] = {
            setup: function() {
                var o = this.ownerDocument || this,
                    l = Y.access(o, n);
                l || o.addEventListener(e, i, !0), Y.access(o, n, (l || 0) + 1)
            },
            teardown: function() {
                var o = this.ownerDocument || this,
                    l = Y.access(o, n) - 1;
                l ? Y.access(o, n, l) : (o.removeEventListener(e, i, !0), Y.remove(o, n))
            }
        }
    });
    var St = F.location,
        Zi = r.now(),
        Fn = /\?/;
    r.parseXML = function(e) {
        var n;
        if (!e || "string" != typeof e) return null;
        try {
            n = (new F.DOMParser).parseFromString(e, "text/xml")
        } catch {
            n = void 0
        }
        return n && !n.getElementsByTagName("parsererror").length || r.error("Invalid XML: " + e), n
    };
    var fi = /\[\]$/,
        Bn = /\r?\n/g,
        di = /^(?:submit|button|image|reset|file)$/i,
        er = /^(?:input|select|textarea|keygen)/i;

    function $t(e, n, i, o) {
        var l;
        if (r.isArray(n)) r.each(n, function(a, u) {
            i || fi.test(e) ? o(e, u) : $t(e + "[" + ("object" == typeof u && null != u ? a : "") + "]", u, i, o)
        });
        else if (i || "object" !== r.type(n)) o(e, n);
        else
            for (l in n) $t(e + "[" + l + "]", n[l], i, o)
    }
    r.param = function(e, n) {
        var i, o = [],
            l = function(a, u) {
                var g = r.isFunction(u) ? u() : u;
                o[o.length] = encodeURIComponent(a) + "=" + encodeURIComponent(g ? ? "")
            };
        if (r.isArray(e) || e.jquery && !r.isPlainObject(e)) r.each(e, function() {
            l(this.name, this.value)
        });
        else
            for (i in e) $t(i, e[i], n, l);
        return o.join("&")
    }, r.fn.extend({
        serialize: function() {
            return r.param(this.serializeArray())
        },
        serializeArray: function() {
            return this.map(function() {
                var e = r.prop(this, "elements");
                return e ? r.makeArray(e) : this
            }).filter(function() {
                var e = this.type;
                return this.name && !r(this).is(":disabled") && er.test(this.nodeName) && !di.test(e) && (this.checked || !Ui.test(e))
            }).map(function(e, n) {
                var i = r(this).val();
                return null == i ? null : r.isArray(i) ? r.map(i, function(o) {
                    return {
                        name: n.name,
                        value: o.replace(Bn, "\r\n")
                    }
                }) : {
                    name: n.name,
                    value: i.replace(Bn, "\r\n")
                }
            }).get()
        }
    });
    var pi = /%20/g,
        tr = /#.*$/,
        nr = /([?&])_=[^&]*/,
        nn = /^(.*?):[ \t]*([^\r\n]*)$/gm,
        ir = /^(?:GET|HEAD)$/,
        rr = /^\/\//,
        gi = {},
        Wn = {},
        mi = "*/".concat("*"),
        yn = J.createElement("a");

    function vi(e) {
        return function(n, i) {
            "string" != typeof n && (i = n, n = "*");
            var o, l = 0,
                a = n.toLowerCase().match(Ce) || [];
            if (r.isFunction(i))
                for (; o = a[l++];) "+" === o[0] ? (o = o.slice(1) || "*", (e[o] = e[o] || []).unshift(i)) : (e[o] = e[o] || []).push(i)
        }
    }

    function or(e, n, i, o) {
        var l = {},
            a = e === Wn;

        function u(g) {
            var v;
            return l[g] = !0, r.each(e[g] || [], function(b, T) {
                var D = T(n, i, o);
                return "string" != typeof D || a || l[D] ? a ? !(v = D) : void 0 : (n.dataTypes.unshift(D), u(D), !1)
            }), v
        }
        return u(n.dataTypes[0]) || !l["*"] && u("*")
    }

    function yi(e, n) {
        var i, o, l = r.ajaxSettings.flatOptions || {};
        for (i in n) void 0 !== n[i] && ((l[i] ? e : o || (o = {}))[i] = n[i]);
        return o && r.extend(!0, e, o), e
    }
    yn.href = St.href, r.extend({
        active: 0,
        lastModified: {},
        etag: {},
        ajaxSettings: {
            url: St.href,
            type: "GET",
            isLocal: /^(?:about|app|app-storage|.+-extension|file|res|widget):$/.test(St.protocol),
            global: !0,
            processData: !0,
            async: !0,
            contentType: "application/x-www-form-urlencoded; charset=UTF-8",
            accepts: {
                "*": mi,
                text: "text/plain",
                html: "text/html",
                xml: "application/xml, text/xml",
                json: "application/json, text/javascript"
            },
            contents: {
                xml: /\bxml\b/,
                html: /\bhtml/,
                json: /\bjson\b/
            },
            responseFields: {
                xml: "responseXML",
                text: "responseText",
                json: "responseJSON"
            },
            converters: {
                "* text": String,
                "text html": !0,
                "text json": JSON.parse,
                "text xml": r.parseXML
            },
            flatOptions: {
                url: !0,
                context: !0
            }
        },
        ajaxSetup: function(e, n) {
            return n ? yi(yi(e, r.ajaxSettings), n) : yi(r.ajaxSettings, e)
        },
        ajaxPrefilter: vi(gi),
        ajaxTransport: vi(Wn),
        ajax: function(e, n) {
            "object" == typeof e && (n = e, e = void 0);
            var i, o, l, a, u, g, v, b, T, D, w = r.ajaxSetup({}, n = n || {}),
                A = w.context || w,
                W = w.context && (A.nodeType || A.jquery) ? r(A) : r.event,
                K = r.Deferred(),
                M = r.Callbacks("once memory"),
                oe = w.statusCode || {},
                _e = {},
                Pe = {},
                ce = "canceled",
                X = {
                    readyState: 0,
                    getResponseHeader: function(ne) {
                        var me;
                        if (v) {
                            if (!a)
                                for (a = {}; me = nn.exec(l);) a[me[1].toLowerCase()] = me[2];
                            me = a[ne.toLowerCase()]
                        }
                        return me ? ? null
                    },
                    getAllResponseHeaders: function() {
                        return v ? l : null
                    },
                    setRequestHeader: function(ne, me) {
                        return null == v && (ne = Pe[ne.toLowerCase()] = Pe[ne.toLowerCase()] || ne, _e[ne] = me), this
                    },
                    overrideMimeType: function(ne) {
                        return null == v && (w.mimeType = ne), this
                    },
                    statusCode: function(ne) {
                        var me;
                        if (ne)
                            if (v) X.always(ne[X.status]);
                            else
                                for (me in ne) oe[me] = [oe[me], ne[me]];
                        return this
                    },
                    abort: function(ne) {
                        var me = ne || ce;
                        return i && i.abort(me), qe(0, me), this
                    }
                };
            if (K.promise(X), w.url = ((e || w.url || St.href) + "").replace(rr, St.protocol + "//"), w.type = n.method || n.type || w.method || w.type, w.dataTypes = (w.dataType || "*").toLowerCase().match(Ce) || [""], null == w.crossDomain) {
                g = J.createElement("a");
                try {
                    g.href = w.url, g.href = g.href, w.crossDomain = yn.protocol + "//" + yn.host != g.protocol + "//" + g.host
                } catch {
                    w.crossDomain = !0
                }
            }
            if (w.data && w.processData && "string" != typeof w.data && (w.data = r.param(w.data, w.traditional)), or(gi, w, n, X), v) return X;
            for (T in (b = r.event && w.global) && 0 == r.active++ && r.event.trigger("ajaxStart"), w.type = w.type.toUpperCase(), w.hasContent = !ir.test(w.type), o = w.url.replace(tr, ""), w.hasContent ? w.data && w.processData && 0 === (w.contentType || "").indexOf("application/x-www-form-urlencoded") && (w.data = w.data.replace(pi, "+")) : (D = w.url.slice(o.length), w.data && (o += (Fn.test(o) ? "&" : "?") + w.data, delete w.data), !1 === w.cache && (o = o.replace(nr, ""), D = (Fn.test(o) ? "&" : "?") + "_=" + Zi++ + D), w.url = o + D), w.ifModified && (r.lastModified[o] && X.setRequestHeader("If-Modified-Since", r.lastModified[o]), r.etag[o] && X.setRequestHeader("If-None-Match", r.etag[o])), (w.data && w.hasContent && !1 !== w.contentType || n.contentType) && X.setRequestHeader("Content-Type", w.contentType), X.setRequestHeader("Accept", w.dataTypes[0] && w.accepts[w.dataTypes[0]] ? w.accepts[w.dataTypes[0]] + ("*" !== w.dataTypes[0] ? ", " + mi + "; q=0.01" : "") : w.accepts["*"]), w.headers) X.setRequestHeader(T, w.headers[T]);
            if (w.beforeSend && (!1 === w.beforeSend.call(A, X, w) || v)) return X.abort();
            if (ce = "abort", M.add(w.complete), X.done(w.success), X.fail(w.error), i = or(Wn, w, n, X)) {
                if (X.readyState = 1, b && W.trigger("ajaxSend", [X, w]), v) return X;
                w.async && w.timeout > 0 && (u = F.setTimeout(function() {
                    X.abort("timeout")
                }, w.timeout));
                try {
                    v = !1, i.send(_e, qe)
                } catch (ne) {
                    if (v) throw ne;
                    qe(-1, ne)
                }
            } else qe(-1, "No Transport");

            function qe(ne, me, rn, on) {
                var ot, sn, He, vt, yt, xe = me;
                v || (v = !0, u && F.clearTimeout(u), i = void 0, l = on || "", X.readyState = ne > 0 ? 4 : 0, ot = ne >= 200 && ne < 300 || 304 === ne, rn && (vt = function sr(e, n, i) {
                    for (var o, l, a, u, g = e.contents, v = e.dataTypes;
                        "*" === v[0];) v.shift(), void 0 === o && (o = e.mimeType || n.getResponseHeader("Content-Type"));
                    if (o)
                        for (l in g)
                            if (g[l] && g[l].test(o)) {
                                v.unshift(l);
                                break
                            }
                    if (v[0] in i) a = v[0];
                    else {
                        for (l in i) {
                            if (!v[0] || e.converters[l + " " + v[0]]) {
                                a = l;
                                break
                            }
                            u || (u = l)
                        }
                        a = a || u
                    }
                    if (a) return a !== v[0] && v.unshift(a), i[a]
                }(w, X, rn)), vt = function ar(e, n, i, o) {
                    var l, a, u, g, v, b = {},
                        T = e.dataTypes.slice();
                    if (T[1])
                        for (u in e.converters) b[u.toLowerCase()] = e.converters[u];
                    for (a = T.shift(); a;)
                        if (e.responseFields[a] && (i[e.responseFields[a]] = n), !v && o && e.dataFilter && (n = e.dataFilter(n, e.dataType)), v = a, a = T.shift())
                            if ("*" === a) a = v;
                            else if ("*" !== v && v !== a) {
                        if (!(u = b[v + " " + a] || b["* " + a]))
                            for (l in b)
                                if ((g = l.split(" "))[1] === a && (u = b[v + " " + g[0]] || b["* " + g[0]])) {
                                    !0 === u ? u = b[l] : !0 !== b[l] && (a = g[0], T.unshift(g[1]));
                                    break
                                }
                        if (!0 !== u)
                            if (u && e.throws) n = u(n);
                            else try {
                                n = u(n)
                            } catch (D) {
                                return {
                                    state: "parsererror",
                                    error: u ? D : "No conversion from " + v + " to " + a
                                }
                            }
                    }
                    return {
                        state: "success",
                        data: n
                    }
                }(w, vt, X, ot), ot ? (w.ifModified && ((yt = X.getResponseHeader("Last-Modified")) && (r.lastModified[o] = yt), (yt = X.getResponseHeader("etag")) && (r.etag[o] = yt)), 204 === ne || "HEAD" === w.type ? xe = "nocontent" : 304 === ne ? xe = "notmodified" : (xe = vt.state, sn = vt.data, ot = !(He = vt.error))) : (He = xe, !ne && xe || (xe = "error", ne < 0 && (ne = 0))), X.status = ne, X.statusText = (me || xe) + "", ot ? K.resolveWith(A, [sn, xe, X]) : K.rejectWith(A, [X, xe, He]), X.statusCode(oe), oe = void 0, b && W.trigger(ot ? "ajaxSuccess" : "ajaxError", [X, w, ot ? sn : He]), M.fireWith(A, [X, xe]), b && (W.trigger("ajaxComplete", [X, w]), --r.active || r.event.trigger("ajaxStop")))
            }
            return X
        },
        getJSON: function(e, n, i) {
            return r.get(e, n, i, "json")
        },
        getScript: function(e, n) {
            return r.get(e, void 0, n, "script")
        }
    }), r.each(["get", "post"], function(e, n) {
        r[n] = function(i, o, l, a) {
            return r.isFunction(o) && (a = a || l, l = o, o = void 0), r.ajax(r.extend({
                url: i,
                type: n,
                dataType: a,
                data: o,
                success: l
            }, r.isPlainObject(i) && i))
        }
    }), r._evalUrl = function(e) {
        return r.ajax({
            url: e,
            type: "GET",
            dataType: "script",
            cache: !0,
            async: !1,
            global: !1,
            throws: !0
        })
    }, r.fn.extend({
        wrapAll: function(e) {
            var n;
            return this[0] && (r.isFunction(e) && (e = e.call(this[0])), n = r(e, this[0].ownerDocument).eq(0).clone(!0), this[0].parentNode && n.insertBefore(this[0]), n.map(function() {
                for (var i = this; i.firstElementChild;) i = i.firstElementChild;
                return i
            }).append(this)), this
        },
        wrapInner: function(e) {
            return r.isFunction(e) ? this.each(function(n) {
                r(this).wrapInner(e.call(this, n))
            }) : this.each(function() {
                var n = r(this),
                    i = n.contents();
                i.length ? i.wrapAll(e) : n.append(e)
            })
        },
        wrap: function(e) {
            var n = r.isFunction(e);
            return this.each(function(i) {
                r(this).wrapAll(n ? e.call(this, i) : e)
            })
        },
        unwrap: function(e) {
            return this.parent(e).not("body").each(function() {
                r(this).replaceWith(this.childNodes)
            }), this
        }
    }), r.expr.pseudos.hidden = function(e) {
        return !r.expr.pseudos.visible(e)
    }, r.expr.pseudos.visible = function(e) {
        return !!(e.offsetWidth || e.offsetHeight || e.getClientRects().length)
    }, r.ajaxSettings.xhr = function() {
        try {
            return new F.XMLHttpRequest
        } catch {}
    };
    var $n = {
            0: 200,
            1223: 204
        },
        _n = r.ajaxSettings.xhr();
    de.cors = !!_n && "withCredentials" in _n, de.ajax = _n = !!_n, r.ajaxTransport(function(e) {
        var n, i;
        if (de.cors || _n && !e.crossDomain) return {
            send: function(o, l) {
                var a, u = e.xhr();
                if (u.open(e.type, e.url, e.async, e.username, e.password), e.xhrFields)
                    for (a in e.xhrFields) u[a] = e.xhrFields[a];
                for (a in e.mimeType && u.overrideMimeType && u.overrideMimeType(e.mimeType), e.crossDomain || o["X-Requested-With"] || (o["X-Requested-With"] = "XMLHttpRequest"), o) u.setRequestHeader(a, o[a]);
                n = function(g) {
                    return function() {
                        n && (n = i = u.onload = u.onerror = u.onabort = u.onreadystatechange = null, "abort" === g ? u.abort() : "error" === g ? "number" != typeof u.status ? l(0, "error") : l(u.status, u.statusText) : l($n[u.status] || u.status, u.statusText, "text" !== (u.responseType || "text") || "string" != typeof u.responseText ? {
                            binary: u.response
                        } : {
                            text: u.responseText
                        }, u.getAllResponseHeaders()))
                    }
                }, u.onload = n(), i = u.onerror = n("error"), void 0 !== u.onabort ? u.onabort = i : u.onreadystatechange = function() {
                    4 === u.readyState && F.setTimeout(function() {
                        n && i()
                    })
                }, n = n("abort");
                try {
                    u.send(e.hasContent && e.data || null)
                } catch (g) {
                    if (n) throw g
                }
            },
            abort: function() {
                n && n()
            }
        }
    }), r.ajaxPrefilter(function(e) {
        e.crossDomain && (e.contents.script = !1)
    }), r.ajaxSetup({
        accepts: {
            script: "text/javascript, application/javascript, application/ecmascript, application/x-ecmascript"
        },
        contents: {
            script: /\b(?:java|ecma)script\b/
        },
        converters: {
            "text script": function(e) {
                return r.globalEval(e), e
            }
        }
    }), r.ajaxPrefilter("script", function(e) {
        void 0 === e.cache && (e.cache = !1), e.crossDomain && (e.type = "GET")
    }), r.ajaxTransport("script", function(e) {
        var n, i;
        if (e.crossDomain) return {
            send: function(o, l) {
                n = r("<script>").prop({
                    charset: e.scriptCharset,
                    src: e.url
                }).on("load error", i = function(a) {
                    n.remove(), i = null, a && l("error" === a.type ? 404 : 200, a.type)
                }), J.head.appendChild(n[0])
            },
            abort: function() {
                i && i()
            }
        }
    });
    var e, lr = [],
        wn = /(=)\?(?=&|$)|\?\?/;

    function _i(e) {
        return r.isWindow(e) ? e : 9 === e.nodeType && e.defaultView
    }
    r.ajaxSetup({
        jsonp: "callback",
        jsonpCallback: function() {
            var e = lr.pop() || r.expando + "_" + Zi++;
            return this[e] = !0, e
        }
    }), r.ajaxPrefilter("json jsonp", function(e, n, i) {
        var o, l, a, u = !1 !== e.jsonp && (wn.test(e.url) ? "url" : "string" == typeof e.data && 0 === (e.contentType || "").indexOf("application/x-www-form-urlencoded") && wn.test(e.data) && "data");
        if (u || "jsonp" === e.dataTypes[0]) return o = e.jsonpCallback = r.isFunction(e.jsonpCallback) ? e.jsonpCallback() : e.jsonpCallback, u ? e[u] = e[u].replace(wn, "$1" + o) : !1 !== e.jsonp && (e.url += (Fn.test(e.url) ? "&" : "?") + e.jsonp + "=" + o), e.converters["script json"] = function() {
            return a || r.error(o + " was not called"), a[0]
        }, e.dataTypes[0] = "json", l = F[o], F[o] = function() {
            a = arguments
        }, i.always(function() {
            void 0 === l ? r(F).removeProp(o) : F[o] = l, e[o] && (e.jsonpCallback = n.jsonpCallback, lr.push(o)), a && r.isFunction(l) && l(a[0]), a = l = void 0
        }), "script"
    }), de.createHTMLDocument = ((e = J.implementation.createHTMLDocument("").body).innerHTML = "<form></form><form></form>", 2 === e.childNodes.length), r.parseHTML = function(e, n, i) {
        return "string" != typeof e ? [] : ("boolean" == typeof n && (i = n, n = !1), n || (de.createHTMLDocument ? ((o = (n = J.implementation.createHTMLDocument("")).createElement("base")).href = J.location.href, n.head.appendChild(o)) : n = J), a = !i && [], (l = Zn.exec(e)) ? [n.createElement(l[1])] : (l = Ct([e], n, a), a && a.length && r(a).remove(), r.merge([], l.childNodes)));
        var o, l, a
    }, r.fn.load = function(e, n, i) {
        var o, l, a, u = this,
            g = e.indexOf(" ");
        return g > -1 && (o = r.trim(e.slice(g)), e = e.slice(0, g)), r.isFunction(n) ? (i = n, n = void 0) : n && "object" == typeof n && (l = "POST"), u.length > 0 && r.ajax({
            url: e,
            type: l || "GET",
            dataType: "html",
            data: n
        }).done(function(v) {
            a = arguments, u.html(o ? r("<div>").append(r.parseHTML(v)).find(o) : v)
        }).always(i && function(v, b) {
            u.each(function() {
                i.apply(this, a || [v.responseText, b, v])
            })
        }), this
    }, r.each(["ajaxStart", "ajaxStop", "ajaxComplete", "ajaxError", "ajaxSuccess", "ajaxSend"], function(e, n) {
        r.fn[n] = function(i) {
            return this.on(n, i)
        }
    }), r.expr.pseudos.animated = function(e) {
        return r.grep(r.timers, function(n) {
            return e === n.elem
        }).length
    }, r.offset = {
        setOffset: function(e, n, i) {
            var o, l, a, u, g, v, T = r.css(e, "position"),
                D = r(e),
                w = {};
            "static" === T && (e.style.position = "relative"), g = D.offset(), a = r.css(e, "top"), v = r.css(e, "left"), ("absolute" === T || "fixed" === T) && (a + v).indexOf("auto") > -1 ? (u = (o = D.position()).top, l = o.left) : (u = parseFloat(a) || 0, l = parseFloat(v) || 0), r.isFunction(n) && (n = n.call(e, i, r.extend({}, g))), null != n.top && (w.top = n.top - g.top + u), null != n.left && (w.left = n.left - g.left + l), "using" in n ? n.using.call(e, w) : D.css(w)
        }
    }, r.fn.extend({
        offset: function(e) {
            if (arguments.length) return void 0 === e ? this : this.each(function(u) {
                r.offset.setOffset(this, e, u)
            });
            var n, i, o, l, a = this[0];
            return a ? a.getClientRects().length ? (o = a.getBoundingClientRect()).width || o.height ? (i = _i(l = a.ownerDocument), {
                top: o.top + i.pageYOffset - (n = l.documentElement).clientTop,
                left: o.left + i.pageXOffset - n.clientLeft
            }) : o : {
                top: 0,
                left: 0
            } : void 0
        },
        position: function() {
            if (this[0]) {
                var e, n, i = this[0],
                    o = {
                        top: 0,
                        left: 0
                    };
                return "fixed" === r.css(i, "position") ? n = i.getBoundingClientRect() : (e = this.offsetParent(), n = this.offset(), r.nodeName(e[0], "html") || (o = e.offset()), o = {
                    top: o.top + r.css(e[0], "borderTopWidth", !0),
                    left: o.left + r.css(e[0], "borderLeftWidth", !0)
                }), {
                    top: n.top - o.top - r.css(i, "marginTop", !0),
                    left: n.left - o.left - r.css(i, "marginLeft", !0)
                }
            }
        },
        offsetParent: function() {
            return this.map(function() {
                for (var e = this.offsetParent; e && "static" === r.css(e, "position");) e = e.offsetParent;
                return e || Ae
            })
        }
    }), r.each({
        scrollLeft: "pageXOffset",
        scrollTop: "pageYOffset"
    }, function(e, n) {
        var i = "pageYOffset" === n;
        r.fn[e] = function(o) {
            return Je(this, function(l, a, u) {
                var g = _i(l);
                return void 0 === u ? g ? g[n] : l[a] : void(g ? g.scrollTo(i ? g.pageXOffset : u, i ? u : g.pageYOffset) : l[a] = u)
            }, e, o, arguments.length)
        }
    }), r.each(["top", "left"], function(e, n) {
        r.cssHooks[n] = tt(de.pixelPosition, function(i, o) {
            if (o) return o = Qt(i, n), Nn.test(o) ? r(i).position()[n] + "px" : o
        })
    }), r.each({
        Height: "height",
        Width: "width"
    }, function(e, n) {
        r.each({
            padding: "inner" + e,
            content: n,
            "": "outer" + e
        }, function(i, o) {
            r.fn[o] = function(l, a) {
                var u = arguments.length && (i || "boolean" != typeof l),
                    g = i || (!0 === l || !0 === a ? "margin" : "border");
                return Je(this, function(v, b, T) {
                    var D;
                    return r.isWindow(v) ? 0 === o.indexOf("outer") ? v["inner" + e] : v.document.documentElement["client" + e] : 9 === v.nodeType ? (D = v.documentElement, Math.max(v.body["scroll" + e], D["scroll" + e], v.body["offset" + e], D["offset" + e], D["client" + e])) : void 0 === T ? r.css(v, b, g) : r.style(v, b, T, g)
                }, n, u ? l : void 0, u)
            }
        })
    }), r.fn.extend({
        bind: function(e, n, i) {
            return this.on(e, null, n, i)
        },
        unbind: function(e, n) {
            return this.off(e, null, n)
        },
        delegate: function(e, n, i, o) {
            return this.on(n, e, i, o)
        },
        undelegate: function(e, n, i) {
            return 1 === arguments.length ? this.off(e, "**") : this.off(n, e || "**", i)
        }
    }), r.parseJSON = JSON.parse, "function" == typeof define && define.amd && define("jquery", [], function() {
        return r
    });
    var wi = F.jQuery,
        xi = F.$;
    return r.noConflict = function(e) {
        return F.$ === r && (F.$ = xi), e && F.jQuery === r && (F.jQuery = wi), r
    }, at || (F.jQuery = F.$ = r), r
}),
function(F, at) {
    "object" == typeof exports && typeof module < "u" ? module.exports = at() : "function" == typeof define && define.amd ? define(at) : (F = typeof globalThis < "u" ? globalThis : F || self).bootstrap = at()
}(this, function() {
    "use strict";
    const F = "transitionend",
        at = c => {
            let t = c.getAttribute("data-bs-target");
            if (!t || "#" === t) {
                let s = c.getAttribute("href");
                if (!s || !s.includes("#") && !s.startsWith(".")) return null;
                s.includes("#") && !s.startsWith("#") && (s = `#${s.split("#")[1]}`), t = s && "#" !== s ? s.trim() : null
            }
            return t
        },
        Ye = c => {
            const t = at(c);
            return t && document.querySelector(t) ? t : null
        },
        J = c => {
            const t = at(c);
            return t ? document.querySelector(t) : null
        },
        ji = c => {
            c.dispatchEvent(new Event(F))
        },
        Fe = c => !(!c || "object" != typeof c) && (void 0 !== c.jquery && (c = c[0]), void 0 !== c.nodeType),
        dt = c => Fe(c) ? c.jquery ? c[0] : c : "string" == typeof c && c.length > 0 ? document.querySelector(c) : null,
        Ke = (c, t, s) => {
            Object.keys(s).forEach(h => {
                const p = s[h],
                    m = t[h],
                    x = m && Fe(m) ? "element" : null == (k = m) ? `${k}` : {}.toString.call(k).match(/\s([a-z]+)/i)[1].toLowerCase();
                var k;
                if (!new RegExp(p).test(x)) throw new TypeError(`${c.toUpperCase()}: Option "${h}" provided type "${x}" but expected type "${p}".`)
            })
        },
        xt = c => !(!Fe(c) || 0 === c.getClientRects().length) && "visible" === getComputedStyle(c).getPropertyValue("visibility"),
        lt = c => !c || c.nodeType !== Node.ELEMENT_NODE || !!c.classList.contains("disabled") || (void 0 !== c.disabled ? c.disabled : c.hasAttribute("disabled") && "false" !== c.getAttribute("disabled")),
        Gn = c => {
            if (!document.documentElement.attachShadow) return null;
            if ("function" == typeof c.getRootNode) {
                const t = c.getRootNode();
                return t instanceof ShadowRoot ? t : null
            }
            return c instanceof ShadowRoot ? c : c.parentNode ? Gn(c.parentNode) : null
        },
        Lt = () => {},
        Ii = () => {
            const {
                jQuery: c
            } = window;
            return c && !document.body.hasAttribute("data-bs-no-jquery") ? c : null
        },
        de = [],
        De = () => "rtl" === document.documentElement.dir,
        Be = c => {
            var t;
            t = () => {
                const s = Ii();
                if (s) {
                    const h = c.NAME,
                        p = s.fn[h];
                    s.fn[h] = c.jQueryInterface, s.fn[h].Constructor = c, s.fn[h].noConflict = () => (s.fn[h] = p, c.jQueryInterface)
                }
            }, "loading" === document.readyState ? (de.length || document.addEventListener("DOMContentLoaded", () => {
                de.forEach(s => s())
            }), de.push(t)) : t()
        },
        r = c => {
            "function" == typeof c && c()
        },
        Pi = (c, t, s = !0) => {
            if (!s) return void r(c);
            const h = (x => {
                if (!x) return 0;
                let {
                    transitionDuration: k,
                    transitionDelay: N
                } = window.getComputedStyle(x);
                const P = Number.parseFloat(k),
                    q = Number.parseFloat(N);
                return P || q ? (k = k.split(",")[0], N = N.split(",")[0], 1e3 * (Number.parseFloat(k) + Number.parseFloat(N))) : 0
            })(t) + 5;
            let p = !1;
            const m = ({
                target: x
            }) => {
                x === t && (p = !0, t.removeEventListener(F, m), r(c))
            };
            t.addEventListener(F, m), setTimeout(() => {
                p || ji(t)
            }, h)
        },
        qi = (c, t, s, h) => {
            let p = c.indexOf(t);
            if (-1 === p) return c[!s && h ? c.length - 1 : 0];
            const m = c.length;
            return p += s ? 1 : -1, h && (p = (p + m) % m), c[Math.max(0, Math.min(p, m - 1))]
        },
        _r = /[^.]*(?=\..*)\.|.*/,
        wr = /\..*/,
        Jn = /::\d+$/,
        pt = {};
    let It = 1;
    const Hi = {
            mouseenter: "mouseover",
            mouseleave: "mouseout"
        },
        Mi = /^(mouseenter|mouseleave)/i,
        Zn = new Set(["click", "dblclick", "mouseup", "mousedown", "contextmenu", "mousewheel", "DOMMouseScroll", "mouseover", "mouseout", "mousemove", "selectstart", "selectend", "keydown", "keypress", "keyup", "orientationchange", "touchstart", "touchmove", "touchend", "touchcancel", "pointerdown", "pointermove", "pointerup", "pointerleave", "pointercancel", "gesturestart", "gesturechange", "gestureend", "focus", "blur", "change", "reset", "select", "submit", "focusin", "focusout", "load", "unload", "beforeunload", "resize", "move", "DOMContentLoaded", "readystatechange", "error", "abort", "scroll"]);

    function Ri(c, t) {
        return t && `${t}::${It++}` || c.uidEvent || It++
    }

    function kn(c) {
        const t = Ri(c);
        return c.uidEvent = t, pt[t] = pt[t] || {}, pt[t]
    }

    function ei(c, t, s = null) {
        const h = Object.keys(c);
        for (let p = 0, m = h.length; p < m; p++) {
            const x = c[h[p]];
            if (x.originalHandler === t && x.delegationSelector === s) return x
        }
        return null
    }

    function Fi(c, t, s) {
        const h = "string" == typeof t,
            p = h ? s : t;
        let m = Wi(c);
        return Zn.has(m) || (m = c), [h, p, m]
    }

    function Bi(c, t, s, h, p) {
        if ("string" != typeof t || !c) return;
        if (s || (s = h, h = null), Mi.test(t)) {
            const z = U => function(G) {
                if (!G.relatedTarget || G.relatedTarget !== G.delegateTarget && !G.delegateTarget.contains(G.relatedTarget)) return U.call(this, G)
            };
            h ? h = z(h) : s = z(s)
        }
        const [m, x, k] = Fi(t, s, h), N = kn(c), P = N[k] || (N[k] = {}), q = ei(P, x, m ? s : null);
        if (q) return void(q.oneOff = q.oneOff && p);
        const L = Ri(x, t.replace(_r, "")),
            te = m ? (z = c, U = s, G = h, function Q(ge) {
                const ae = z.querySelectorAll(U);
                for (let {
                        target: ee
                    } = ge; ee && ee !== this; ee = ee.parentNode)
                    for (let le = ae.length; le--;)
                        if (ae[le] === ee) return ge.delegateTarget = ee, Q.oneOff && S.off(z, ge.type, U, G), G.apply(ee, [ge]);
                return null
            }) : function(z, U) {
                return function G(Q) {
                    return Q.delegateTarget = z, G.oneOff && S.off(z, Q.type, U), U.apply(z, [Q])
                }
            }(c, s);
        var z, U, G;
        te.delegationSelector = m ? s : null, te.originalHandler = x, te.oneOff = p, te.uidEvent = L, P[L] = te, c.addEventListener(k, te, m)
    }

    function ti(c, t, s, h, p) {
        const m = ei(t[s], h, p);
        m && (c.removeEventListener(s, m, !!p), delete t[s][m.uidEvent])
    }

    function Wi(c) {
        return c = c.replace(wr, ""), Hi[c] || c
    }
    const S = {
            on(c, t, s, h) {
                Bi(c, t, s, h, !1)
            },
            one(c, t, s, h) {
                Bi(c, t, s, h, !0)
            },
            off(c, t, s, h) {
                if ("string" != typeof t || !c) return;
                const [p, m, x] = Fi(t, s, h), k = x !== t, N = kn(c), P = t.startsWith(".");
                if (void 0 !== m) return N && N[x] ? void ti(c, N, x, m, p ? s : null) : void 0;
                P && Object.keys(N).forEach(L => {
                    ! function(te, z, U, G) {
                        const Q = z[U] || {};
                        Object.keys(Q).forEach(ge => {
                            if (ge.includes(G)) {
                                const ae = Q[ge];
                                ti(te, z, U, ae.originalHandler, ae.delegationSelector)
                            }
                        })
                    }(c, N, L, t.slice(1))
                });
                const q = N[x] || {};
                Object.keys(q).forEach(L => {
                    const te = L.replace(Jn, "");
                    if (!k || t.includes(te)) {
                        const z = q[L];
                        ti(c, N, x, z.originalHandler, z.delegationSelector)
                    }
                })
            },
            trigger(c, t, s) {
                if ("string" != typeof t || !c) return null;
                const h = Ii(),
                    p = Wi(t),
                    m = t !== p,
                    x = Zn.has(p);
                let k, N = !0,
                    P = !0,
                    q = !1,
                    L = null;
                return m && h && (k = h.Event(t, s), h(c).trigger(k), N = !k.isPropagationStopped(), P = !k.isImmediatePropagationStopped(), q = k.isDefaultPrevented()), x ? (L = document.createEvent("HTMLEvents"), L.initEvent(p, N, !0)) : L = new CustomEvent(t, {
                    bubbles: N,
                    cancelable: !0
                }), void 0 !== s && Object.keys(s).forEach(te => {
                    Object.defineProperty(L, te, {
                        get: () => s[te]
                    })
                }), q && L.preventDefault(), P && c.dispatchEvent(L), L.defaultPrevented && void 0 !== k && k.preventDefault(), L
            }
        },
        Ce = new Map,
        hn = {
            set(c, t, s) {
                Ce.has(c) || Ce.set(c, new Map);
                const h = Ce.get(c);
                h.has(t) || 0 === h.size ? h.set(t, s) : console.error(`Bootstrap doesn't allow more than one instance per element. Bound instance: ${Array.from(h.keys())[0]}.`)
            },
            get: (c, t) => Ce.has(c) && Ce.get(c).get(t) || null,
            remove(c, t) {
                if (!Ce.has(c)) return;
                const s = Ce.get(c);
                s.delete(t), 0 === s.size && Ce.delete(c)
            }
        };
    class Oe {
        constructor(t) {
            (t = dt(t)) && (this._element = t, hn.set(this._element, this.constructor.DATA_KEY, this))
        }
        dispose() {
            hn.remove(this._element, this.constructor.DATA_KEY), S.off(this._element, this.constructor.EVENT_KEY), Object.getOwnPropertyNames(this).forEach(t => {
                this[t] = null
            })
        }
        _queueCallback(t, s, h = !0) {
            Pi(t, s, h)
        }
        static getInstance(t) {
            return hn.get(dt(t), this.DATA_KEY)
        }
        static getOrCreateInstance(t, s = {}) {
            return this.getInstance(t) || new this(t, "object" == typeof s ? s : null)
        }
        static get VERSION() {
            return "5.1.3"
        }
        static get NAME() {
            throw new Error('You have to implement the static method "NAME", for each component!')
        }
        static get DATA_KEY() {
            return `bs.${this.NAME}`
        }
        static get EVENT_KEY() {
            return `.${this.DATA_KEY}`
        }
    }
    const Pt = (c, t = "hide") => {
        const h = c.NAME;
        S.on(document, `click.dismiss${c.EVENT_KEY}`, `[data-bs-dismiss="${h}"]`, function(p) {
            if (["A", "AREA"].includes(this.tagName) && p.preventDefault(), lt(this)) return;
            const m = J(this) || this.closest(`.${h}`);
            c.getOrCreateInstance(m)[t]()
        })
    };
    class Yt extends Oe {
        static get NAME() {
            return "alert"
        }
        close() {
            if (S.trigger(this._element, "close.bs.alert").defaultPrevented) return;
            this._element.classList.remove("show");
            const t = this._element.classList.contains("fade");
            this._queueCallback(() => this._destroyElement(), this._element, t)
        }
        _destroyElement() {
            this._element.remove(), S.trigger(this._element, "closed.bs.alert"), this.dispose()
        }
        static jQueryInterface(t) {
            return this.each(function() {
                const s = Yt.getOrCreateInstance(this);
                if ("string" == typeof t) {
                    if (void 0 === s[t] || t.startsWith("_") || "constructor" === t) throw new TypeError(`No method named "${t}"`);
                    s[t](this)
                }
            })
        }
    }
    Pt(Yt, "close"), Be(Yt);
    const $i = '[data-bs-toggle="button"]';
    class qt extends Oe {
        static get NAME() {
            return "button"
        }
        toggle() {
            this._element.setAttribute("aria-pressed", this._element.classList.toggle("active"))
        }
        static jQueryInterface(t) {
            return this.each(function() {
                const s = qt.getOrCreateInstance(this);
                "toggle" === t && s[t]()
            })
        }
    }

    function fn(c) {
        return "true" === c || "false" !== c && (c === Number(c).toString() ? Number(c) : "" === c || "null" === c ? null : c)
    }

    function Je(c) {
        return c.replace(/[A-Z]/g, t => `-${t.toLowerCase()}`)
    }
    S.on(document, "click.bs.button.data-api", $i, c => {
        c.preventDefault();
        const t = c.target.closest($i);
        qt.getOrCreateInstance(t).toggle()
    }), Be(qt);
    const we = {
            setDataAttribute(c, t, s) {
                c.setAttribute(`data-bs-${Je(t)}`, s)
            },
            removeDataAttribute(c, t) {
                c.removeAttribute(`data-bs-${Je(t)}`)
            },
            getDataAttributes(c) {
                if (!c) return {};
                const t = {};
                return Object.keys(c.dataset).filter(s => s.startsWith("bs")).forEach(s => {
                    let h = s.replace(/^bs/, "");
                    h = h.charAt(0).toLowerCase() + h.slice(1, h.length), t[h] = fn(c.dataset[s])
                }), t
            },
            getDataAttribute: (c, t) => fn(c.getAttribute(`data-bs-${Je(t)}`)),
            offset(c) {
                const t = c.getBoundingClientRect();
                return {
                    top: t.top + window.pageYOffset,
                    left: t.left + window.pageXOffset
                }
            },
            position: c => ({
                top: c.offsetTop,
                left: c.offsetLeft
            })
        },
        B = {
            find: (c, t = document.documentElement) => [].concat(...Element.prototype.querySelectorAll.call(t, c)),
            findOne: (c, t = document.documentElement) => Element.prototype.querySelector.call(t, c),
            children: (c, t) => [].concat(...c.children).filter(s => s.matches(t)),
            parents(c, t) {
                const s = [];
                let h = c.parentNode;
                for (; h && h.nodeType === Node.ELEMENT_NODE && 3 !== h.nodeType;) h.matches(t) && s.push(h), h = h.parentNode;
                return s
            },
            prev(c, t) {
                let s = c.previousElementSibling;
                for (; s;) {
                    if (s.matches(t)) return [s];
                    s = s.previousElementSibling
                }
                return []
            },
            next(c, t) {
                let s = c.nextElementSibling;
                for (; s;) {
                    if (s.matches(t)) return [s];
                    s = s.nextElementSibling
                }
                return []
            },
            focusableChildren(c) {
                const t = ["a", "button", "input", "textarea", "select", "details", "[tabindex]", '[contenteditable="true"]'].map(s => `${s}:not([tabindex^="-"])`).join(", ");
                return this.find(t, c).filter(s => !lt(s) && xt(s))
            }
        },
        Y = "carousel",
        Ne = {
            interval: 5e3,
            keyboard: !0,
            slide: !1,
            pause: "hover",
            wrap: !0,
            touch: !0
        },
        xr = {
            interval: "(number|boolean)",
            keyboard: "boolean",
            slide: "(boolean|string)",
            pause: "(string|boolean)",
            wrap: "boolean",
            touch: "boolean"
        },
        Ht = "next",
        bt = "prev",
        Et = "left",
        gt = "right",
        Mt = {
            ArrowLeft: gt,
            ArrowRight: Et
        },
        dn = "slid.bs.carousel",
        Tt = "active",
        pn = ".active.carousel-item";
    class Ze extends Oe {
        constructor(t, s) {
            super(t), this._items = null, this._interval = null, this._activeElement = null, this._isPaused = !1, this._isSliding = !1, this.touchTimeout = null, this.touchStartX = 0, this.touchDeltaX = 0, this._config = this._getConfig(s), this._indicatorsElement = B.findOne(".carousel-indicators", this._element), this._touchSupported = "ontouchstart" in document.documentElement || navigator.maxTouchPoints > 0, this._pointerEvent = !!window.PointerEvent, this._addEventListeners()
        }
        static get Default() {
            return Ne
        }
        static get NAME() {
            return Y
        }
        next() {
            this._slide(Ht)
        }
        nextWhenVisible() {
            !document.hidden && xt(this._element) && this.next()
        }
        prev() {
            this._slide(bt)
        }
        pause(t) {
            t || (this._isPaused = !0), B.findOne(".carousel-item-next, .carousel-item-prev", this._element) && (ji(this._element), this.cycle(!0)), clearInterval(this._interval), this._interval = null
        }
        cycle(t) {
            t || (this._isPaused = !1), this._interval && (clearInterval(this._interval), this._interval = null), this._config && this._config.interval && !this._isPaused && (this._updateInterval(), this._interval = setInterval((document.visibilityState ? this.nextWhenVisible : this.next).bind(this), this._config.interval))
        }
        to(t) {
            this._activeElement = B.findOne(pn, this._element);
            const s = this._getItemIndex(this._activeElement);
            if (!(t > this._items.length - 1 || t < 0)) {
                if (!this._isSliding) return s === t ? (this.pause(), void this.cycle()) : void this._slide(t > s ? Ht : bt, this._items[t]);
                S.one(this._element, dn, () => this.to(t))
            }
        }
        _getConfig(t) {
            return t = { ...Ne,
                ...we.getDataAttributes(this._element),
                ..."object" == typeof t ? t : {}
            }, Ke(Y, t, xr), t
        }
        _handleSwipe() {
            const t = Math.abs(this.touchDeltaX);
            if (t <= 40) return;
            const s = t / this.touchDeltaX;
            this.touchDeltaX = 0, s && this._slide(s > 0 ? gt : Et)
        }
        _addEventListeners() {
            this._config.keyboard && S.on(this._element, "keydown.bs.carousel", t => this._keydown(t)), "hover" === this._config.pause && (S.on(this._element, "mouseenter.bs.carousel", t => this.pause(t)), S.on(this._element, "mouseleave.bs.carousel", t => this.cycle(t))), this._config.touch && this._touchSupported && this._addTouchEventListeners()
        }
        _addTouchEventListeners() {
            const t = m => this._pointerEvent && ("pen" === m.pointerType || "touch" === m.pointerType),
                s = m => {
                    t(m) ? this.touchStartX = m.clientX : this._pointerEvent || (this.touchStartX = m.touches[0].clientX)
                },
                h = m => {
                    this.touchDeltaX = m.touches && m.touches.length > 1 ? 0 : m.touches[0].clientX - this.touchStartX
                },
                p = m => {
                    t(m) && (this.touchDeltaX = m.clientX - this.touchStartX), this._handleSwipe(), "hover" === this._config.pause && (this.pause(), this.touchTimeout && clearTimeout(this.touchTimeout), this.touchTimeout = setTimeout(x => this.cycle(x), 500 + this._config.interval))
                };
            B.find(".carousel-item img", this._element).forEach(m => {
                S.on(m, "dragstart.bs.carousel", x => x.preventDefault())
            }), this._pointerEvent ? (S.on(this._element, "pointerdown.bs.carousel", m => s(m)), S.on(this._element, "pointerup.bs.carousel", m => p(m)), this._element.classList.add("pointer-event")) : (S.on(this._element, "touchstart.bs.carousel", m => s(m)), S.on(this._element, "touchmove.bs.carousel", m => h(m)), S.on(this._element, "touchend.bs.carousel", m => p(m)))
        }
        _keydown(t) {
            if (/input|textarea/i.test(t.target.tagName)) return;
            const s = Mt[t.key];
            s && (t.preventDefault(), this._slide(s))
        }
        _getItemIndex(t) {
            return this._items = t && t.parentNode ? B.find(".carousel-item", t.parentNode) : [], this._items.indexOf(t)
        }
        _getItemByOrder(t, s) {
            return qi(this._items, s, t === Ht, this._config.wrap)
        }
        _triggerSlideEvent(t, s) {
            const h = this._getItemIndex(t),
                p = this._getItemIndex(B.findOne(pn, this._element));
            return S.trigger(this._element, "slide.bs.carousel", {
                relatedTarget: t,
                direction: s,
                from: p,
                to: h
            })
        }
        _setActiveIndicatorElement(t) {
            if (this._indicatorsElement) {
                const s = B.findOne(".active", this._indicatorsElement);
                s.classList.remove(Tt), s.removeAttribute("aria-current");
                const h = B.find("[data-bs-target]", this._indicatorsElement);
                for (let p = 0; p < h.length; p++)
                    if (Number.parseInt(h[p].getAttribute("data-bs-slide-to"), 10) === this._getItemIndex(t)) {
                        h[p].classList.add(Tt), h[p].setAttribute("aria-current", "true");
                        break
                    }
            }
        }
        _updateInterval() {
            const t = this._activeElement || B.findOne(pn, this._element);
            if (!t) return;
            const s = Number.parseInt(t.getAttribute("data-bs-interval"), 10);
            s ? (this._config.defaultInterval = this._config.defaultInterval || this._config.interval, this._config.interval = s) : this._config.interval = this._config.defaultInterval || this._config.interval
        }
        _slide(t, s) {
            const h = this._directionToOrder(t),
                p = B.findOne(pn, this._element),
                m = this._getItemIndex(p),
                x = s || this._getItemByOrder(h, p),
                k = this._getItemIndex(x),
                N = !!this._interval,
                P = h === Ht,
                q = P ? "carousel-item-start" : "carousel-item-end",
                L = P ? "carousel-item-next" : "carousel-item-prev",
                te = this._orderToDirection(h);
            if (x && x.classList.contains(Tt)) return void(this._isSliding = !1);
            if (this._isSliding || this._triggerSlideEvent(x, te).defaultPrevented || !p || !x) return;
            this._isSliding = !0, N && this.pause(), this._setActiveIndicatorElement(x), this._activeElement = x;
            const z = () => {
                S.trigger(this._element, dn, {
                    relatedTarget: x,
                    direction: te,
                    from: m,
                    to: k
                })
            };
            this._element.classList.contains("slide") ? (x.classList.add(L), p.classList.add(q), x.classList.add(q), this._queueCallback(() => {
                x.classList.remove(q, L), x.classList.add(Tt), p.classList.remove(Tt, L, q), this._isSliding = !1, setTimeout(z, 0)
            }, p, !0)) : (p.classList.remove(Tt), x.classList.add(Tt), this._isSliding = !1, z()), N && this.cycle()
        }
        _directionToOrder(t) {
            return [gt, Et].includes(t) ? De() ? t === Et ? bt : Ht : t === Et ? Ht : bt : t
        }
        _orderToDirection(t) {
            return [Ht, bt].includes(t) ? De() ? t === bt ? Et : gt : t === bt ? gt : Et : t
        }
        static carouselInterface(t, s) {
            const h = Ze.getOrCreateInstance(t, s);
            let {
                _config: p
            } = h;
            "object" == typeof s && (p = { ...p,
                ...s
            });
            const m = "string" == typeof s ? s : p.slide;
            if ("number" == typeof s) h.to(s);
            else if ("string" == typeof m) {
                if (void 0 === h[m]) throw new TypeError(`No method named "${m}"`);
                h[m]()
            } else p.interval && p.ride && (h.pause(), h.cycle())
        }
        static jQueryInterface(t) {
            return this.each(function() {
                Ze.carouselInterface(this, t)
            })
        }
        static dataApiClickHandler(t) {
            const s = J(this);
            if (!s || !s.classList.contains("carousel")) return;
            const h = { ...we.getDataAttributes(s),
                    ...we.getDataAttributes(this)
                },
                p = this.getAttribute("data-bs-slide-to");
            p && (h.interval = !1), Ze.carouselInterface(s, h), p && Ze.getInstance(s).to(p), t.preventDefault()
        }
    }
    S.on(document, "click.bs.carousel.data-api", "[data-bs-slide], [data-bs-slide-to]", Ze.dataApiClickHandler), S.on(window, "load.bs.carousel.data-api", () => {
        const c = B.find('[data-bs-ride="carousel"]');
        for (let t = 0, s = c.length; t < s; t++) Ze.carouselInterface(c[t], Ze.getInstance(c[t]))
    }), Be(Ze);
    const zi = "collapse",
        Rt = {
            toggle: !0,
            parent: null
        },
        Ui = {
            toggle: "boolean",
            parent: "(null|element)"
        },
        Sn = "show",
        gn = "collapse",
        Le = "collapsing",
        je = "collapsed",
        On = ":scope .collapse .collapse",
        ni = '[data-bs-toggle="collapse"]';
    class Ct extends Oe {
        constructor(t, s) {
            super(t), this._isTransitioning = !1, this._config = this._getConfig(s), this._triggerArray = [];
            const h = B.find(ni);
            for (let p = 0, m = h.length; p < m; p++) {
                const x = h[p],
                    k = Ye(x),
                    N = B.find(k).filter(P => P === this._element);
                null !== k && N.length && (this._selector = k, this._triggerArray.push(x))
            }
            this._initializeChildren(), this._config.parent || this._addAriaAndCollapsedClass(this._triggerArray, this._isShown()), this._config.toggle && this.toggle()
        }
        static get Default() {
            return Rt
        }
        static get NAME() {
            return zi
        }
        toggle() {
            this._isShown() ? this.hide() : this.show()
        }
        show() {
            if (this._isTransitioning || this._isShown()) return;
            let t, s = [];
            if (this._config.parent) {
                const x = B.find(On, this._config.parent);
                s = B.find(".collapse.show, .collapse.collapsing", this._config.parent).filter(k => !x.includes(k))
            }
            const h = B.findOne(this._selector);
            if (s.length) {
                const x = s.find(k => h !== k);
                if (t = x ? Ct.getInstance(x) : null, t && t._isTransitioning) return
            }
            if (S.trigger(this._element, "show.bs.collapse").defaultPrevented) return;
            s.forEach(x => {
                h !== x && Ct.getOrCreateInstance(x, {
                    toggle: !1
                }).hide(), t || hn.set(x, "bs.collapse", null)
            });
            const p = this._getDimension();
            this._element.classList.remove(gn), this._element.classList.add(Le), this._element.style[p] = 0, this._addAriaAndCollapsedClass(this._triggerArray, !0), this._isTransitioning = !0;
            const m = `scroll${p[0].toUpperCase()+p.slice(1)}`;
            this._queueCallback(() => {
                this._isTransitioning = !1, this._element.classList.remove(Le), this._element.classList.add(gn, Sn), this._element.style[p] = "", S.trigger(this._element, "shown.bs.collapse")
            }, this._element, !0), this._element.style[p] = `${this._element[m]}px`
        }
        hide() {
            if (this._isTransitioning || !this._isShown() || S.trigger(this._element, "hide.bs.collapse").defaultPrevented) return;
            const t = this._getDimension();
            this._element.style[t] = `${this._element.getBoundingClientRect()[t]}px`, this._element.classList.add(Le), this._element.classList.remove(gn, Sn);
            const s = this._triggerArray.length;
            for (let h = 0; h < s; h++) {
                const p = this._triggerArray[h],
                    m = J(p);
                m && !this._isShown(m) && this._addAriaAndCollapsedClass([p], !1)
            }
            this._isTransitioning = !0, this._element.style[t] = "", this._queueCallback(() => {
                this._isTransitioning = !1, this._element.classList.remove(Le), this._element.classList.add(gn), S.trigger(this._element, "hidden.bs.collapse")
            }, this._element, !0)
        }
        _isShown(t = this._element) {
            return t.classList.contains(Sn)
        }
        _getConfig(t) {
            return (t = { ...Rt,
                ...we.getDataAttributes(this._element),
                ...t
            }).toggle = !!t.toggle, t.parent = dt(t.parent), Ke(zi, t, Ui), t
        }
        _getDimension() {
            return this._element.classList.contains("collapse-horizontal") ? "width" : "height"
        }
        _initializeChildren() {
            if (!this._config.parent) return;
            const t = B.find(On, this._config.parent);
            B.find(ni, this._config.parent).filter(s => !t.includes(s)).forEach(s => {
                const h = J(s);
                h && this._addAriaAndCollapsedClass([s], this._isShown(h))
            })
        }
        _addAriaAndCollapsedClass(t, s) {
            t.length && t.forEach(h => {
                s ? h.classList.remove(je) : h.classList.add(je), h.setAttribute("aria-expanded", s)
            })
        }
        static jQueryInterface(t) {
            return this.each(function() {
                const s = {};
                "string" == typeof t && /show|hide/.test(t) && (s.toggle = !1);
                const h = Ct.getOrCreateInstance(this, s);
                if ("string" == typeof t) {
                    if (void 0 === h[t]) throw new TypeError(`No method named "${t}"`);
                    h[t]()
                }
            })
        }
    }
    S.on(document, "click.bs.collapse.data-api", ni, function(c) {
        ("A" === c.target.tagName || c.delegateTarget && "A" === c.delegateTarget.tagName) && c.preventDefault();
        const t = Ye(this);
        B.find(t).forEach(s => {
            Ct.getOrCreateInstance(s, {
                toggle: !1
            }).toggle()
        })
    }), Be(Ct);
    var Ae = "top",
        We = "bottom",
        $e = "right",
        Ie = "left",
        Ft = "auto",
        et = [Ae, We, $e, Ie],
        At = "start",
        kt = "end",
        Xi = "clippingParents",
        ii = "viewport",
        Kt = "popper",
        Vi = "reference",
        ri = et.reduce(function(c, t) {
            return c.concat([t + "-" + At, t + "-" + kt])
        }, []),
        Dn = [].concat(et, [Ft]).reduce(function(c, t) {
            return c.concat([t, t + "-" + At, t + "-" + kt])
        }, []),
        Yi = "beforeRead",
        oi = "afterRead",
        Qi = "beforeMain",
        si = "afterMain",
        ai = "beforeWrite",
        mn = "afterWrite",
        Qt = [Yi, "read", oi, Qi, "main", si, ai, "write", mn];

    function tt(c) {
        return c ? (c.nodeName || "").toLowerCase() : null
    }

    function nt(c) {
        if (null == c) return window;
        if ("[object Window]" !== c.toString()) {
            var t = c.ownerDocument;
            return t && t.defaultView || window
        }
        return c
    }

    function vn(c) {
        return c instanceof nt(c).Element || c instanceof Element
    }

    function ze(c) {
        return c instanceof nt(c).HTMLElement || c instanceof HTMLElement
    }

    function li(c) {
        return typeof ShadowRoot < "u" && (c instanceof nt(c).ShadowRoot || c instanceof ShadowRoot)
    }
    const Ln = {
        name: "applyStyles",
        enabled: !0,
        phase: "write",
        fn: function(c) {
            var t = c.state;
            Object.keys(t.elements).forEach(function(s) {
                var h = t.styles[s] || {},
                    p = t.attributes[s] || {},
                    m = t.elements[s];
                ze(m) && tt(m) && (Object.assign(m.style, h), Object.keys(p).forEach(function(x) {
                    var k = p[x];
                    !1 === k ? m.removeAttribute(x) : m.setAttribute(x, !0 === k ? "" : k)
                }))
            })
        },
        effect: function(c) {
            var t = c.state,
                s = {
                    popper: {
                        position: t.options.strategy,
                        left: "0",
                        top: "0",
                        margin: "0"
                    },
                    arrow: {
                        position: "absolute"
                    },
                    reference: {}
                };
            return Object.assign(t.elements.popper.style, s.popper), t.styles = s, t.elements.arrow && Object.assign(t.elements.arrow.style, s.arrow),
                function() {
                    Object.keys(t.elements).forEach(function(h) {
                        var p = t.elements[h],
                            m = t.attributes[h] || {},
                            x = Object.keys(t.styles.hasOwnProperty(h) ? t.styles[h] : s[h]).reduce(function(k, N) {
                                return k[N] = "", k
                            }, {});
                        ze(p) && tt(p) && (Object.assign(p.style, x), Object.keys(m).forEach(function(k) {
                            p.removeAttribute(k)
                        }))
                    })
                }
        },
        requires: ["computeStyles"]
    };

    function it(c) {
        return c.split("-")[0]
    }

    function Wt(c, t) {
        var s = c.getBoundingClientRect();
        return {
            width: s.width / 1,
            height: s.height / 1,
            top: s.top / 1,
            right: s.right / 1,
            bottom: s.bottom / 1,
            left: s.left / 1,
            x: s.left / 1,
            y: s.top / 1
        }
    }

    function jn(c) {
        var t = Wt(c),
            s = c.offsetWidth,
            h = c.offsetHeight;
        return Math.abs(t.width - s) <= 1 && (s = t.width), Math.abs(t.height - h) <= 1 && (h = t.height), {
            x: c.offsetLeft,
            y: c.offsetTop,
            width: s,
            height: h
        }
    }

    function ci(c, t) {
        var s = t.getRootNode && t.getRootNode();
        if (c.contains(t)) return !0;
        if (s && li(s)) {
            var h = t;
            do {
                if (h && c.isSameNode(h)) return !0;
                h = h.parentNode || h.host
            } while (h)
        }
        return !1
    }

    function ye(c) {
        return nt(c).getComputedStyle(c)
    }

    function Gt(c) {
        return ["table", "td", "th"].indexOf(tt(c)) >= 0
    }

    function Ue(c) {
        return ((vn(c) ? c.ownerDocument : c.document) || window.document).documentElement
    }

    function In(c) {
        return "html" === tt(c) ? c : c.assignedSlot || c.parentNode || (li(c) ? c.host : null) || Ue(c)
    }

    function Gi(c) {
        return ze(c) && "fixed" !== ye(c).position ? c.offsetParent : null
    }

    function Jt(c) {
        for (var t = nt(c), s = Gi(c); s && Gt(s) && "static" === ye(s).position;) s = Gi(s);
        return s && ("html" === tt(s) || "body" === tt(s) && "static" === ye(s).position) ? t : s || function(h) {
            var p = -1 !== navigator.userAgent.toLowerCase().indexOf("firefox");
            if (-1 !== navigator.userAgent.indexOf("Trident") && ze(h) && "fixed" === ye(h).position) return null;
            for (var m = In(h); ze(m) && ["html", "body"].indexOf(tt(m)) < 0;) {
                var x = ye(m);
                if ("none" !== x.transform || "none" !== x.perspective || "paint" === x.contain || -1 !== ["transform", "perspective"].indexOf(x.willChange) || p && "filter" === x.willChange || p && x.filter && "none" !== x.filter) return m;
                m = m.parentNode
            }
            return null
        }(c) || t
    }

    function Pn(c) {
        return ["top", "bottom"].indexOf(c) >= 0 ? "x" : "y"
    }
    var rt = Math.max,
        Zt = Math.min,
        qn = Math.round;

    function Hn(c, t, s) {
        return rt(c, Zt(t, s))
    }

    function Qe(c) {
        return Object.assign({}, {
            top: 0,
            right: 0,
            bottom: 0,
            left: 0
        }, c)
    }

    function ui(c, t) {
        return t.reduce(function(s, h) {
            return s[h] = c, s
        }, {})
    }
    const en = {
        name: "arrow",
        enabled: !0,
        phase: "main",
        fn: function(c) {
            var t, fe, ve, s = c.state,
                h = c.name,
                p = c.options,
                m = s.elements.arrow,
                x = s.modifiersData.popperOffsets,
                k = it(s.placement),
                N = Pn(k),
                P = [Ie, $e].indexOf(k) >= 0 ? "height" : "width";
            if (m && x) {
                var q = (ve = s, Qe("number" != typeof(fe = "function" == typeof(fe = p.padding) ? fe(Object.assign({}, ve.rects, {
                        placement: ve.placement
                    })) : fe) ? fe : ui(fe, et))),
                    L = jn(m),
                    te = "y" === N ? Ae : Ie,
                    z = "y" === N ? We : $e,
                    U = s.rects.reference[P] + s.rects.reference[N] - x[N] - s.rects.popper[P],
                    G = x[N] - s.rects.reference[N],
                    Q = Jt(m),
                    ge = Q ? "y" === N ? Q.clientHeight || 0 : Q.clientWidth || 0 : 0,
                    ie = ge / 2 - L[P] / 2 + (U / 2 - G / 2),
                    re = Hn(q[te], ie, ge - L[P] - q[z]);
                s.modifiersData[h] = ((t = {})[N] = re, t.centerOffset = re - ie, t)
            }
        },
        effect: function(c) {
            var t = c.state,
                s = c.options.element,
                h = void 0 === s ? "[data-popper-arrow]" : s;
            null != h && ("string" != typeof h || (h = t.elements.popper.querySelector(h))) && ci(t.elements.popper, h) && (t.elements.arrow = h)
        },
        requires: ["popperOffsets"],
        requiresIfExists: ["preventOverflow"]
    };

    function tn(c) {
        return c.split("-")[1]
    }
    var br = {
        top: "auto",
        right: "auto",
        bottom: "auto",
        left: "auto"
    };

    function Mn(c) {
        var t, Me, ht, Te, s = c.popper,
            h = c.popperRect,
            p = c.placement,
            m = c.variation,
            x = c.offsets,
            k = c.position,
            N = c.gpuAcceleration,
            P = c.adaptive,
            q = c.roundOffsets,
            L = !0 === q ? (ht = (Me = x).y, Te = window.devicePixelRatio || 1, {
                x: qn(qn(Me.x * Te) / Te) || 0,
                y: qn(qn(ht * Te) / Te) || 0
            }) : "function" == typeof q ? q(x) : x,
            te = L.x,
            z = void 0 === te ? 0 : te,
            U = L.y,
            G = void 0 === U ? 0 : U,
            Q = x.hasOwnProperty("x"),
            ge = x.hasOwnProperty("y"),
            ae = Ie,
            ee = Ae,
            le = window;
        if (P) {
            var ie = Jt(s),
                re = "clientHeight",
                he = "clientWidth";
            ie === nt(s) && "static" !== ye(ie = Ue(s)).position && "absolute" === k && (re = "scrollHeight", he = "scrollWidth"), p !== Ae && (p !== Ie && p !== $e || m !== kt) || (ee = We, G -= ie[re] - h.height, G *= N ? 1 : -1), p !== Ie && (p !== Ae && p !== We || m !== kt) || (ae = $e, z -= ie[he] - h.width, z *= N ? 1 : -1)
        }
        var fe, ve = Object.assign({
            position: k
        }, P && br);
        return Object.assign({}, ve, N ? ((fe = {})[ee] = ge ? "0" : "", fe[ae] = Q ? "0" : "", fe.transform = (le.devicePixelRatio || 1) <= 1 ? "translate(" + z + "px, " + G + "px)" : "translate3d(" + z + "px, " + G + "px, 0)", fe) : ((t = {})[ee] = ge ? G + "px" : "", t[ae] = Q ? z + "px" : "", t.transform = "", t))
    }
    const mt = {
        name: "computeStyles",
        enabled: !0,
        phase: "beforeWrite",
        fn: function(c) {
            var t = c.state,
                s = c.options,
                h = s.gpuAcceleration,
                p = void 0 === h || h,
                m = s.adaptive,
                x = void 0 === m || m,
                k = s.roundOffsets,
                N = void 0 === k || k,
                P = {
                    placement: it(t.placement),
                    variation: tn(t.placement),
                    popper: t.elements.popper,
                    popperRect: t.rects.popper,
                    gpuAcceleration: p
                };
            null != t.modifiersData.popperOffsets && (t.styles.popper = Object.assign({}, t.styles.popper, Mn(Object.assign({}, P, {
                offsets: t.modifiersData.popperOffsets,
                position: t.options.strategy,
                adaptive: x,
                roundOffsets: N
            })))), null != t.modifiersData.arrow && (t.styles.arrow = Object.assign({}, t.styles.arrow, Mn(Object.assign({}, P, {
                offsets: t.modifiersData.arrow,
                position: "absolute",
                adaptive: !1,
                roundOffsets: N
            })))), t.attributes.popper = Object.assign({}, t.attributes.popper, {
                "data-popper-placement": t.placement
            })
        },
        data: {}
    };
    var Rn = {
        passive: !0
    };
    const hi = {
        name: "eventListeners",
        enabled: !0,
        phase: "write",
        fn: function() {},
        effect: function(c) {
            var t = c.state,
                s = c.instance,
                h = c.options,
                p = h.scroll,
                m = void 0 === p || p,
                x = h.resize,
                k = void 0 === x || x,
                N = nt(t.elements.popper),
                P = [].concat(t.scrollParents.reference, t.scrollParents.popper);
            return m && P.forEach(function(q) {
                    q.addEventListener("scroll", s.update, Rn)
                }), k && N.addEventListener("resize", s.update, Rn),
                function() {
                    m && P.forEach(function(q) {
                        q.removeEventListener("scroll", s.update, Rn)
                    }), k && N.removeEventListener("resize", s.update, Rn)
                }
        },
        data: {}
    };
    var Ji = {
        left: "right",
        right: "left",
        bottom: "top",
        top: "bottom"
    };

    function St(c) {
        return c.replace(/left|right|bottom|top/g, function(t) {
            return Ji[t]
        })
    }
    var Zi = {
        start: "end",
        end: "start"
    };

    function Fn(c) {
        return c.replace(/start|end/g, function(t) {
            return Zi[t]
        })
    }

    function fi(c) {
        var t = nt(c);
        return {
            scrollLeft: t.pageXOffset,
            scrollTop: t.pageYOffset
        }
    }

    function Bn(c) {
        return Wt(Ue(c)).left + fi(c).scrollLeft
    }

    function di(c) {
        var t = ye(c);
        return /auto|scroll|overlay|hidden/.test(t.overflow + t.overflowY + t.overflowX)
    }

    function er(c) {
        return ["html", "body", "#document"].indexOf(tt(c)) >= 0 ? c.ownerDocument.body : ze(c) && di(c) ? c : er(In(c))
    }

    function $t(c, t) {
        var s;
        void 0 === t && (t = []);
        var h = er(c),
            p = h === (null == (s = c.ownerDocument) ? void 0 : s.body),
            m = nt(h),
            x = p ? [m].concat(m.visualViewport || [], di(h) ? h : []) : h,
            k = t.concat(x);
        return p ? k : k.concat($t(In(x)))
    }

    function pi(c) {
        return Object.assign({}, c, {
            left: c.x,
            top: c.y,
            right: c.x + c.width,
            bottom: c.y + c.height
        })
    }

    function tr(c, t) {
        return t === ii ? pi((h = nt(s = c), x = (p = Ue(s)).clientWidth, k = p.clientHeight, N = 0, P = 0, (m = h.visualViewport) && (x = m.width, k = m.height, /^((?!chrome|android).)*safari/i.test(navigator.userAgent) || (N = m.offsetLeft, P = m.offsetTop)), {
            width: x,
            height: k,
            x: N + Bn(s),
            y: P
        })) : ze(t) ? function(s) {
            var h = Wt(s);
            return h.top = h.top + s.clientTop, h.left = h.left + s.clientLeft, h.bottom = h.top + s.clientHeight, h.right = h.left + s.clientWidth, h.width = s.clientWidth, h.height = s.clientHeight, h.x = h.left, h.y = h.top, h
        }(t) : pi(function(s) {
            var h, p = Ue(s),
                m = fi(s),
                x = null == (h = s.ownerDocument) ? void 0 : h.body,
                k = rt(p.scrollWidth, p.clientWidth, x ? x.scrollWidth : 0, x ? x.clientWidth : 0),
                N = rt(p.scrollHeight, p.clientHeight, x ? x.scrollHeight : 0, x ? x.clientHeight : 0),
                P = -m.scrollLeft + Bn(s),
                q = -m.scrollTop;
            return "rtl" === ye(x || p).direction && (P += rt(p.clientWidth, x ? x.clientWidth : 0) - k), {
                width: k,
                height: N,
                x: P,
                y: q
            }
        }(Ue(c)));
        var s, h, p, m, x, k, N, P
    }

    function nr(c) {
        var t, s = c.reference,
            h = c.element,
            p = c.placement,
            m = p ? it(p) : null,
            x = p ? tn(p) : null,
            k = s.x + s.width / 2 - h.width / 2,
            N = s.y + s.height / 2 - h.height / 2;
        switch (m) {
            case Ae:
                t = {
                    x: k,
                    y: s.y - h.height
                };
                break;
            case We:
                t = {
                    x: k,
                    y: s.y + s.height
                };
                break;
            case $e:
                t = {
                    x: s.x + s.width,
                    y: N
                };
                break;
            case Ie:
                t = {
                    x: s.x - h.width,
                    y: N
                };
                break;
            default:
                t = {
                    x: s.x,
                    y: s.y
                }
        }
        var P = m ? Pn(m) : null;
        if (null != P) {
            var q = "y" === P ? "height" : "width";
            switch (x) {
                case At:
                    t[P] = t[P] - (s[q] / 2 - h[q] / 2);
                    break;
                case kt:
                    t[P] = t[P] + (s[q] / 2 - h[q] / 2)
            }
        }
        return t
    }

    function nn(c, t) {
        void 0 === t && (t = {});
        var Xe, ht, Te, be, An, Ge, Cn, Xt, Re, h = t.placement,
            p = void 0 === h ? c.placement : h,
            m = t.boundary,
            x = void 0 === m ? Xi : m,
            k = t.rootBoundary,
            N = void 0 === k ? ii : k,
            P = t.elementContext,
            q = void 0 === P ? Kt : P,
            L = t.altBoundary,
            te = void 0 !== L && L,
            z = t.padding,
            U = void 0 === z ? 0 : z,
            G = Qe("number" != typeof U ? U : ui(U, et)),
            ge = c.rects.popper,
            ae = c.elements[te ? q === Kt ? Vi : Kt : q],
            ee = (Xe = vn(ae) ? ae : ae.contextElement || Ue(c.elements.popper), Te = N, Cn = "clippingParents" === (ht = x) ? (An = $t(In(be = Xe)), vn(Ge = ["absolute", "fixed"].indexOf(ye(be).position) >= 0 && ze(be) ? Jt(be) : be) ? An.filter(function(Ve) {
                return vn(Ve) && ci(Ve, Ge) && "body" !== tt(Ve)
            }) : []) : [].concat(ht), Re = (Xt = [].concat(Cn, [Te])).reduce(function(be, An) {
                var Ge = tr(Xe, An);
                return be.top = rt(Ge.top, be.top), be.right = Zt(Ge.right, be.right), be.bottom = Zt(Ge.bottom, be.bottom), be.left = rt(Ge.left, be.left), be
            }, tr(Xe, Xt[0])), Re.width = Re.right - Re.left, Re.height = Re.bottom - Re.top, Re.x = Re.left, Re.y = Re.top, Re),
            le = Wt(c.elements.reference),
            ie = nr({
                reference: le,
                element: ge,
                strategy: "absolute",
                placement: p
            }),
            re = pi(Object.assign({}, ge, ie)),
            he = q === Kt ? re : le,
            fe = {
                top: ee.top - he.top + G.top,
                bottom: he.bottom - ee.bottom + G.bottom,
                left: ee.left - he.left + G.left,
                right: he.right - ee.right + G.right
            },
            ve = c.modifiersData.offset;
        if (q === Kt && ve) {
            var Me = ve[p];
            Object.keys(fe).forEach(function(Xe) {
                var ht = [$e, We].indexOf(Xe) >= 0 ? 1 : -1,
                    Te = [Ae, We].indexOf(Xe) >= 0 ? "y" : "x";
                fe[Xe] += Me[Te] * ht
            })
        }
        return fe
    }
    const ir = {
        name: "flip",
        enabled: !0,
        phase: "main",
        fn: function(c) {
            var t = c.state,
                s = c.options,
                h = c.name;
            if (!t.modifiersData[h]._skip) {
                for (var p = s.mainAxis, m = void 0 === p || p, x = s.altAxis, k = void 0 === x || x, N = s.fallbackPlacements, P = s.padding, q = s.boundary, L = s.rootBoundary, te = s.altBoundary, z = s.flipVariations, U = void 0 === z || z, G = s.allowedAutoPlacements, Q = t.options.placement, ge = it(Q), ae = N || (ge !== Q && U ? function(Ve) {
                        if (it(Ve) === Ft) return [];
                        var ft = St(Ve);
                        return [Fn(Ve), ft, Fn(ft)]
                    }(Q) : [St(Q)]), ee = [Q].concat(ae).reduce(function(Ve, ft) {
                        return Ve.concat(it(ft) === Ft ? function Er(c, t) {
                            void 0 === t && (t = {});
                            var p = t.boundary,
                                m = t.rootBoundary,
                                x = t.padding,
                                k = t.flipVariations,
                                N = t.allowedAutoPlacements,
                                P = void 0 === N ? Dn : N,
                                q = tn(t.placement),
                                L = q ? k ? ri : ri.filter(function(U) {
                                    return tn(U) === q
                                }) : et,
                                te = L.filter(function(U) {
                                    return P.indexOf(U) >= 0
                                });
                            0 === te.length && (te = L);
                            var z = te.reduce(function(U, G) {
                                return U[G] = nn(c, {
                                    placement: G,
                                    boundary: p,
                                    rootBoundary: m,
                                    padding: x
                                })[it(G)], U
                            }, {});
                            return Object.keys(z).sort(function(U, G) {
                                return z[U] - z[G]
                            })
                        }(t, {
                            placement: ft,
                            boundary: q,
                            rootBoundary: L,
                            padding: P,
                            flipVariations: U,
                            allowedAutoPlacements: G
                        }) : ft)
                    }, []), le = t.rects.reference, ie = t.rects.popper, re = new Map, he = !0, fe = ee[0], ve = 0; ve < ee.length; ve++) {
                    var Me = ee[ve],
                        Xe = it(Me),
                        ht = tn(Me) === At,
                        Te = [Ae, We].indexOf(Xe) >= 0,
                        Cn = Te ? "width" : "height",
                        Xt = nn(t, {
                            placement: Me,
                            boundary: q,
                            rootBoundary: L,
                            altBoundary: te,
                            padding: P
                        }),
                        Vt = Te ? ht ? $e : Ie : ht ? We : Ae;
                    le[Cn] > ie[Cn] && (Vt = St(Vt));
                    var Re = St(Vt),
                        be = [];
                    if (m && be.push(Xt[Xe] <= 0), k && be.push(Xt[Vt] <= 0, Xt[Re] <= 0), be.every(function(Ve) {
                            return Ve
                        })) {
                        fe = Me, he = !1;
                        break
                    }
                    re.set(Me, be)
                }
                if (he)
                    for (var An = function(Ve) {
                            var ft = ee.find(function(vr) {
                                var Li = re.get(vr);
                                if (Li) return Li.slice(0, Ve).every(function(Qn) {
                                    return Qn
                                })
                            });
                            if (ft) return fe = ft, "break"
                        }, Ge = U ? 3 : 1; Ge > 0 && "break" !== An(Ge); Ge--);
                t.placement !== fe && (t.modifiersData[h]._skip = !0, t.placement = fe, t.reset = !0)
            }
        },
        requiresIfExists: ["offset"],
        data: {
            _skip: !1
        }
    };

    function rr(c, t, s) {
        return void 0 === s && (s = {
            x: 0,
            y: 0
        }), {
            top: c.top - t.height - s.y,
            right: c.right - t.width + s.x,
            bottom: c.bottom - t.height + s.y,
            left: c.left - t.width - s.x
        }
    }

    function gi(c) {
        return [Ae, $e, We, Ie].some(function(t) {
            return c[t] >= 0
        })
    }
    const Wn = {
            name: "hide",
            enabled: !0,
            phase: "main",
            requiresIfExists: ["preventOverflow"],
            fn: function(c) {
                var t = c.state,
                    s = c.name,
                    h = t.rects.reference,
                    p = t.rects.popper,
                    m = t.modifiersData.preventOverflow,
                    x = nn(t, {
                        elementContext: "reference"
                    }),
                    k = nn(t, {
                        altBoundary: !0
                    }),
                    N = rr(x, h),
                    P = rr(k, p, m),
                    q = gi(N),
                    L = gi(P);
                t.modifiersData[s] = {
                    referenceClippingOffsets: N,
                    popperEscapeOffsets: P,
                    isReferenceHidden: q,
                    hasPopperEscaped: L
                }, t.attributes.popper = Object.assign({}, t.attributes.popper, {
                    "data-popper-reference-hidden": q,
                    "data-popper-escaped": L
                })
            }
        },
        mi = {
            name: "offset",
            enabled: !0,
            phase: "main",
            requires: ["popperOffsets"],
            fn: function(c) {
                var t = c.state,
                    h = c.name,
                    p = c.options.offset,
                    m = void 0 === p ? [0, 0] : p,
                    x = Dn.reduce(function(q, L) {
                        return q[L] = (z = t.rects, U = m, G = it(te = L), Q = [Ie, Ae].indexOf(G) >= 0 ? -1 : 1, ae = (ae = (ge = "function" == typeof U ? U(Object.assign({}, z, {
                            placement: te
                        })) : U)[0]) || 0, ee = ((ee = ge[1]) || 0) * Q, [Ie, $e].indexOf(G) >= 0 ? {
                            x: ee,
                            y: ae
                        } : {
                            x: ae,
                            y: ee
                        }), q;
                        var te, z, U, G, Q, ge, ae, ee
                    }, {}),
                    k = x[t.placement],
                    P = k.y;
                null != t.modifiersData.popperOffsets && (t.modifiersData.popperOffsets.x += k.x, t.modifiersData.popperOffsets.y += P), t.modifiersData[h] = x
            }
        },
        yn = {
            name: "popperOffsets",
            enabled: !0,
            phase: "read",
            fn: function(c) {
                var t = c.state;
                t.modifiersData[c.name] = nr({
                    reference: t.rects.reference,
                    element: t.rects.popper,
                    strategy: "absolute",
                    placement: t.placement
                })
            },
            data: {}
        },
        vi = {
            name: "preventOverflow",
            enabled: !0,
            phase: "main",
            fn: function(c) {
                var t = c.state,
                    s = c.options,
                    h = c.name,
                    p = s.mainAxis,
                    m = void 0 === p || p,
                    x = s.altAxis,
                    k = void 0 !== x && x,
                    te = s.tether,
                    z = void 0 === te || te,
                    U = s.tetherOffset,
                    G = void 0 === U ? 0 : U,
                    Q = nn(t, {
                        boundary: s.boundary,
                        rootBoundary: s.rootBoundary,
                        padding: s.padding,
                        altBoundary: s.altBoundary
                    }),
                    ge = it(t.placement),
                    ae = tn(t.placement),
                    ee = !ae,
                    le = Pn(ge),
                    ie = "x" === le ? "y" : "x",
                    re = t.modifiersData.popperOffsets,
                    he = t.rects.reference,
                    fe = t.rects.popper,
                    ve = "function" == typeof G ? G(Object.assign({}, t.rects, {
                        placement: t.placement
                    })) : G,
                    Me = {
                        x: 0,
                        y: 0
                    };
                if (re) {
                    if (m || k) {
                        var Xe = "y" === le ? Ae : Ie,
                            ht = "y" === le ? We : $e,
                            Te = "y" === le ? "height" : "width",
                            Cn = re[le],
                            Xt = re[le] + Q[Xe],
                            Vt = re[le] - Q[ht],
                            Re = z ? -fe[Te] / 2 : 0,
                            be = ae === At ? he[Te] : fe[Te],
                            An = ae === At ? -fe[Te] : -he[Te],
                            Ge = t.elements.arrow,
                            Ve = z && Ge ? jn(Ge) : {
                                width: 0,
                                height: 0
                            },
                            ft = t.modifiersData["arrow#persistent"] ? t.modifiersData["arrow#persistent"].padding : {
                                top: 0,
                                right: 0,
                                bottom: 0,
                                left: 0
                            },
                            vr = ft[Xe],
                            Li = ft[ht],
                            Qn = Hn(0, he[Te], Ve[Te]),
                            Ir = ee ? he[Te] / 2 - Re - Qn - vr - ve : be - Qn - vr - ve,
                            Pr = ee ? -he[Te] / 2 + Re + Qn + Li + ve : An + Qn + Li + ve,
                            Ar = t.elements.arrow && Jt(t.elements.arrow),
                            kr = t.modifiersData.offset ? t.modifiersData.offset[t.placement][le] : 0,
                            Sr = re[le] + Ir - kr - (Ar ? "y" === le ? Ar.clientTop || 0 : Ar.clientLeft || 0 : 0),
                            Or = re[le] + Pr - kr;
                        if (m) {
                            var Dr = Hn(z ? Zt(Xt, Sr) : Xt, Cn, z ? rt(Vt, Or) : Vt);
                            re[le] = Dr, Me[le] = Dr - Cn
                        }
                        if (k) {
                            var yr = re[ie],
                                Nr = yr + Q["x" === le ? Ae : Ie],
                                Lr = yr - Q["x" === le ? We : $e],
                                jr = Hn(z ? Zt(Nr, Sr) : Nr, yr, z ? rt(Lr, Or) : Lr);
                            re[ie] = jr, Me[ie] = jr - yr
                        }
                    }
                    t.modifiersData[h] = Me
                }
            },
            requiresIfExists: ["offset"]
        };

    function or(c, t, s) {
        void 0 === s && (s = !1);
        var h = ze(t);
        ze(t) && t.getBoundingClientRect();
        var p, m, x = Ue(t),
            k = Wt(c),
            N = {
                scrollLeft: 0,
                scrollTop: 0
            },
            P = {
                x: 0,
                y: 0
            };
        return (h || !h && !s) && (("body" !== tt(t) || di(x)) && (N = (p = t) !== nt(p) && ze(p) ? {
            scrollLeft: (m = p).scrollLeft,
            scrollTop: m.scrollTop
        } : fi(p)), ze(t) ? ((P = Wt(t)).x += t.clientLeft, P.y += t.clientTop) : x && (P.x = Bn(x))), {
            x: k.left + N.scrollLeft - P.x,
            y: k.top + N.scrollTop - P.y,
            width: k.width,
            height: k.height
        }
    }

    function yi(c) {
        var t = new Map,
            s = new Set,
            h = [];

        function p(m) {
            s.add(m.name), [].concat(m.requires || [], m.requiresIfExists || []).forEach(function(x) {
                if (!s.has(x)) {
                    var k = t.get(x);
                    k && p(k)
                }
            }), h.push(m)
        }
        return c.forEach(function(m) {
            t.set(m.name, m)
        }), c.forEach(function(m) {
            s.has(m.name) || p(m)
        }), h
    }
    var sr = {
        placement: "bottom",
        modifiers: [],
        strategy: "absolute"
    };

    function ar() {
        for (var c = arguments.length, t = new Array(c), s = 0; s < c; s++) t[s] = arguments[s];
        return !t.some(function(h) {
            return !(h && "function" == typeof h.getBoundingClientRect)
        })
    }

    function $n(c) {
        void 0 === c && (c = {});
        var s = c.defaultModifiers,
            h = void 0 === s ? [] : s,
            p = c.defaultOptions,
            m = void 0 === p ? sr : p;
        return function(x, k, N) {
            void 0 === N && (N = m);
            var P, q, L = {
                    placement: "bottom",
                    orderedModifiers: [],
                    options: Object.assign({}, sr, m),
                    modifiersData: {},
                    elements: {
                        reference: x,
                        popper: k
                    },
                    attributes: {},
                    styles: {}
                },
                te = [],
                z = !1,
                U = {
                    state: L,
                    setOptions: function(Q) {
                        var ge = "function" == typeof Q ? Q(L.options) : Q;
                        G(), L.options = Object.assign({}, m, L.options, ge), L.scrollParents = {
                            reference: vn(x) ? $t(x) : x.contextElement ? $t(x.contextElement) : [],
                            popper: $t(k)
                        };
                        var ae, ee, ie, re, le = (ae = [].concat(h, L.options.modifiers), ee = ae.reduce(function(ie, re) {
                            var he = ie[re.name];
                            return ie[re.name] = he ? Object.assign({}, he, re, {
                                options: Object.assign({}, he.options, re.options),
                                data: Object.assign({}, he.data, re.data)
                            }) : re, ie
                        }, {}), ie = Object.keys(ee).map(function(ie) {
                            return ee[ie]
                        }), re = yi(ie), Qt.reduce(function(he, fe) {
                            return he.concat(re.filter(function(ve) {
                                return ve.phase === fe
                            }))
                        }, []));
                        return L.orderedModifiers = le.filter(function(ie) {
                            return ie.enabled
                        }), L.orderedModifiers.forEach(function(ie) {
                            var he = ie.options,
                                ve = ie.effect;
                            if ("function" == typeof ve) {
                                var Me = ve({
                                    state: L,
                                    name: ie.name,
                                    instance: U,
                                    options: void 0 === he ? {} : he
                                });
                                te.push(Me || function() {})
                            }
                        }), U.update()
                    },
                    forceUpdate: function() {
                        if (!z) {
                            var Q = L.elements,
                                ge = Q.reference,
                                ae = Q.popper;
                            if (ar(ge, ae)) {
                                L.rects = {
                                    reference: or(ge, Jt(ae), "fixed" === L.options.strategy),
                                    popper: jn(ae)
                                }, L.reset = !1, L.placement = L.options.placement, L.orderedModifiers.forEach(function(ve) {
                                    return L.modifiersData[ve.name] = Object.assign({}, ve.data)
                                });
                                for (var ee = 0; ee < L.orderedModifiers.length; ee++)
                                    if (!0 !== L.reset) {
                                        var le = L.orderedModifiers[ee],
                                            ie = le.fn,
                                            re = le.options;
                                        "function" == typeof ie && (L = ie({
                                            state: L,
                                            options: void 0 === re ? {} : re,
                                            name: le.name,
                                            instance: U
                                        }) || L)
                                    } else L.reset = !1, ee = -1
                            }
                        }
                    },
                    update: (P = function() {
                        return new Promise(function(Q) {
                            U.forceUpdate(), Q(L)
                        })
                    }, function() {
                        return q || (q = new Promise(function(Q) {
                            Promise.resolve().then(function() {
                                q = void 0, Q(P())
                            })
                        })), q
                    }),
                    destroy: function() {
                        G(), z = !0
                    }
                };
            if (!ar(x, k)) return U;

            function G() {
                te.forEach(function(Q) {
                    return Q()
                }), te = []
            }
            return U.setOptions(N).then(function(Q) {
                !z && N.onFirstUpdate && N.onFirstUpdate(Q)
            }), U
        }
    }
    var _n = $n(),
        lr = $n({
            defaultModifiers: [hi, yn, mt, Ln]
        }),
        wn = $n({
            defaultModifiers: [hi, yn, mt, Ln, mi, ir, vi, en, Wn]
        });
    const _i = Object.freeze({
            __proto__: null,
            popperGenerator: $n,
            detectOverflow: nn,
            createPopperBase: _n,
            createPopper: wn,
            createPopperLite: lr,
            top: Ae,
            bottom: We,
            right: $e,
            left: Ie,
            auto: Ft,
            basePlacements: et,
            start: At,
            end: kt,
            clippingParents: Xi,
            viewport: ii,
            popper: Kt,
            reference: Vi,
            variationPlacements: ri,
            placements: Dn,
            beforeRead: Yi,
            read: "read",
            afterRead: oi,
            beforeMain: Qi,
            main: "main",
            afterMain: si,
            beforeWrite: ai,
            write: "write",
            afterWrite: mn,
            modifierPhases: Qt,
            applyStyles: Ln,
            arrow: en,
            computeStyles: mt,
            eventListeners: hi,
            flip: ir,
            hide: Wn,
            offset: mi,
            popperOffsets: yn,
            preventOverflow: vi
        }),
        wi = "dropdown",
        xi = "Escape",
        e = "Space",
        n = "ArrowUp",
        i = "ArrowDown",
        o = new RegExp("ArrowUp|ArrowDown|Escape"),
        l = "click.bs.dropdown.data-api",
        a = "keydown.bs.dropdown.data-api",
        u = "show",
        g = '[data-bs-toggle="dropdown"]',
        v = ".dropdown-menu",
        b = De() ? "top-end" : "top-start",
        T = De() ? "top-start" : "top-end",
        D = De() ? "bottom-end" : "bottom-start",
        w = De() ? "bottom-start" : "bottom-end",
        A = De() ? "left-start" : "right-start",
        W = De() ? "right-start" : "left-start",
        K = {
            offset: [0, 2],
            boundary: "clippingParents",
            reference: "toggle",
            display: "dynamic",
            popperConfig: null,
            autoClose: !0
        },
        M = {
            offset: "(array|string|function)",
            boundary: "(string|element)",
            reference: "(string|element|object)",
            display: "string",
            popperConfig: "(null|object|function)",
            autoClose: "(boolean|string)"
        };
    class oe extends Oe {
        constructor(t, s) {
            super(t), this._popper = null, this._config = this._getConfig(s), this._menu = this._getMenuElement(), this._inNavbar = this._detectNavbar()
        }
        static get Default() {
            return K
        }
        static get DefaultType() {
            return M
        }
        static get NAME() {
            return wi
        }
        toggle() {
            return this._isShown() ? this.hide() : this.show()
        }
        show() {
            if (lt(this._element) || this._isShown(this._menu)) return;
            const t = {
                relatedTarget: this._element
            };
            if (S.trigger(this._element, "show.bs.dropdown", t).defaultPrevented) return;
            const s = oe.getParentFromElement(this._element);
            this._inNavbar ? we.setDataAttribute(this._menu, "popper", "none") : this._createPopper(s), "ontouchstart" in document.documentElement && !s.closest(".navbar-nav") && [].concat(...document.body.children).forEach(h => S.on(h, "mouseover", Lt)), this._element.focus(), this._element.setAttribute("aria-expanded", !0), this._menu.classList.add(u), this._element.classList.add(u), S.trigger(this._element, "shown.bs.dropdown", t)
        }
        hide() {
            !lt(this._element) && this._isShown(this._menu) && this._completeHide({
                relatedTarget: this._element
            })
        }
        dispose() {
            this._popper && this._popper.destroy(), super.dispose()
        }
        update() {
            this._inNavbar = this._detectNavbar(), this._popper && this._popper.update()
        }
        _completeHide(t) {
            S.trigger(this._element, "hide.bs.dropdown", t).defaultPrevented || ("ontouchstart" in document.documentElement && [].concat(...document.body.children).forEach(s => S.off(s, "mouseover", Lt)), this._popper && this._popper.destroy(), this._menu.classList.remove(u), this._element.classList.remove(u), this._element.setAttribute("aria-expanded", "false"), we.removeDataAttribute(this._menu, "popper"), S.trigger(this._element, "hidden.bs.dropdown", t))
        }
        _getConfig(t) {
            if (t = { ...this.constructor.Default,
                    ...we.getDataAttributes(this._element),
                    ...t
                }, Ke(wi, t, this.constructor.DefaultType), "object" == typeof t.reference && !Fe(t.reference) && "function" != typeof t.reference.getBoundingClientRect) throw new TypeError(`${wi.toUpperCase()}: Option "reference" provided type "object" without a required "getBoundingClientRect" method.`);
            return t
        }
        _createPopper(t) {
            if (void 0 === _i) throw new TypeError("Bootstrap's dropdowns require Popper (https://popper.js.org)");
            let s = this._element;
            "parent" === this._config.reference ? s = t : Fe(this._config.reference) ? s = dt(this._config.reference) : "object" == typeof this._config.reference && (s = this._config.reference);
            const h = this._getPopperConfig(),
                p = h.modifiers.find(m => "applyStyles" === m.name && !1 === m.enabled);
            this._popper = wn(s, this._menu, h), p && we.setDataAttribute(this._menu, "popper", "static")
        }
        _isShown(t = this._element) {
            return t.classList.contains(u)
        }
        _getMenuElement() {
            return B.next(this._element, v)[0]
        }
        _getPlacement() {
            const t = this._element.parentNode;
            if (t.classList.contains("dropend")) return A;
            if (t.classList.contains("dropstart")) return W;
            const s = "end" === getComputedStyle(this._menu).getPropertyValue("--bs-position").trim();
            return t.classList.contains("dropup") ? s ? T : b : s ? w : D
        }
        _detectNavbar() {
            return null !== this._element.closest(".navbar")
        }
        _getOffset() {
            const {
                offset: t
            } = this._config;
            return "string" == typeof t ? t.split(",").map(s => Number.parseInt(s, 10)) : "function" == typeof t ? s => t(s, this._element) : t
        }
        _getPopperConfig() {
            const t = {
                placement: this._getPlacement(),
                modifiers: [{
                    name: "preventOverflow",
                    options: {
                        boundary: this._config.boundary
                    }
                }, {
                    name: "offset",
                    options: {
                        offset: this._getOffset()
                    }
                }]
            };
            return "static" === this._config.display && (t.modifiers = [{
                name: "applyStyles",
                enabled: !1
            }]), { ...t,
                ..."function" == typeof this._config.popperConfig ? this._config.popperConfig(t) : this._config.popperConfig
            }
        }
        _selectMenuItem({
            key: t,
            target: s
        }) {
            const h = B.find(".dropdown-menu .dropdown-item:not(.disabled):not(:disabled)", this._menu).filter(xt);
            h.length && qi(h, s, t === i, !h.includes(s)).focus()
        }
        static jQueryInterface(t) {
            return this.each(function() {
                const s = oe.getOrCreateInstance(this, t);
                if ("string" == typeof t) {
                    if (void 0 === s[t]) throw new TypeError(`No method named "${t}"`);
                    s[t]()
                }
            })
        }
        static clearMenus(t) {
            if (t && (2 === t.button || "keyup" === t.type && "Tab" !== t.key)) return;
            const s = B.find(g);
            for (let h = 0, p = s.length; h < p; h++) {
                const m = oe.getInstance(s[h]);
                if (!m || !1 === m._config.autoClose || !m._isShown()) continue;
                const x = {
                    relatedTarget: m._element
                };
                if (t) {
                    const k = t.composedPath(),
                        N = k.includes(m._menu);
                    if (k.includes(m._element) || "inside" === m._config.autoClose && !N || "outside" === m._config.autoClose && N || m._menu.contains(t.target) && ("keyup" === t.type && "Tab" === t.key || /input|select|option|textarea|form/i.test(t.target.tagName))) continue;
                    "click" === t.type && (x.clickEvent = t)
                }
                m._completeHide(x)
            }
        }
        static getParentFromElement(t) {
            return J(t) || t.parentNode
        }
        static dataApiKeydownHandler(t) {
            if (/input|textarea/i.test(t.target.tagName) ? t.key === e || t.key !== xi && (t.key !== i && t.key !== n || t.target.closest(v)) : !o.test(t.key)) return;
            const s = this.classList.contains(u);
            if (!s && t.key === xi || (t.preventDefault(), t.stopPropagation(), lt(this))) return;
            const h = this.matches(g) ? this : B.prev(this, g)[0],
                p = oe.getOrCreateInstance(h);
            if (t.key !== xi) return t.key === n || t.key === i ? (s || p.show(), void p._selectMenuItem(t)) : void(s && t.key !== e || oe.clearMenus());
            p.hide()
        }
    }
    S.on(document, a, g, oe.dataApiKeydownHandler), S.on(document, a, v, oe.dataApiKeydownHandler), S.on(document, l, oe.clearMenus), S.on(document, "keyup.bs.dropdown.data-api", oe.clearMenus), S.on(document, l, g, function(c) {
        c.preventDefault(), oe.getOrCreateInstance(this).toggle()
    }), Be(oe);
    const _e = ".fixed-top, .fixed-bottom, .is-fixed, .sticky-top",
        Pe = ".sticky-top";
    class ce {
        constructor() {
            this._element = document.body
        }
        getWidth() {
            const t = document.documentElement.clientWidth;
            return Math.abs(window.innerWidth - t)
        }
        hide() {
            const t = this.getWidth();
            this._disableOverFlow(), this._setElementAttributes(this._element, "paddingRight", s => s + t), this._setElementAttributes(_e, "paddingRight", s => s + t), this._setElementAttributes(Pe, "marginRight", s => s - t)
        }
        _disableOverFlow() {
            this._saveInitialAttribute(this._element, "overflow"), this._element.style.overflow = "hidden"
        }
        _setElementAttributes(t, s, h) {
            const p = this.getWidth();
            this._applyManipulationCallback(t, m => {
                if (m !== this._element && window.innerWidth > m.clientWidth + p) return;
                this._saveInitialAttribute(m, s);
                const x = window.getComputedStyle(m)[s];
                m.style[s] = `${h(Number.parseFloat(x))}px`
            })
        }
        reset() {
            this._resetElementAttributes(this._element, "overflow"), this._resetElementAttributes(this._element, "paddingRight"), this._resetElementAttributes(_e, "paddingRight"), this._resetElementAttributes(Pe, "marginRight")
        }
        _saveInitialAttribute(t, s) {
            const h = t.style[s];
            h && we.setDataAttribute(t, s, h)
        }
        _resetElementAttributes(t, s) {
            this._applyManipulationCallback(t, h => {
                const p = we.getDataAttribute(h, s);
                void 0 === p ? h.style.removeProperty(s) : (we.removeDataAttribute(h, s), h.style[s] = p)
            })
        }
        _applyManipulationCallback(t, s) {
            Fe(t) ? s(t) : B.find(t, this._element).forEach(s)
        }
        isOverflowing() {
            return this.getWidth() > 0
        }
    }
    const X = {
            className: "modal-backdrop",
            isVisible: !0,
            isAnimated: !1,
            rootElement: "body",
            clickCallback: null
        },
        qe = {
            className: "string",
            isVisible: "boolean",
            isAnimated: "boolean",
            rootElement: "(element|string)",
            clickCallback: "(function|null)"
        },
        me = "mousedown.bs.backdrop";
    class rn {
        constructor(t) {
            this._config = this._getConfig(t), this._isAppended = !1, this._element = null
        }
        show(t) {
            this._config.isVisible ? (this._append(), this._config.isAnimated && this._getElement(), this._getElement().classList.add("show"), this._emulateAnimation(() => {
                r(t)
            })) : r(t)
        }
        hide(t) {
            this._config.isVisible ? (this._getElement().classList.remove("show"), this._emulateAnimation(() => {
                this.dispose(), r(t)
            })) : r(t)
        }
        _getElement() {
            if (!this._element) {
                const t = document.createElement("div");
                t.className = this._config.className, this._config.isAnimated && t.classList.add("fade"), this._element = t
            }
            return this._element
        }
        _getConfig(t) {
            return (t = { ...X,
                ..."object" == typeof t ? t : {}
            }).rootElement = dt(t.rootElement), Ke("backdrop", t, qe), t
        }
        _append() {
            this._isAppended || (this._config.rootElement.append(this._getElement()), S.on(this._getElement(), me, () => {
                r(this._config.clickCallback)
            }), this._isAppended = !0)
        }
        dispose() {
            this._isAppended && (S.off(this._element, me), this._element.remove(), this._isAppended = !1)
        }
        _emulateAnimation(t) {
            Pi(t, this._getElement(), this._config.isAnimated)
        }
    }
    const on = {
            trapElement: null,
            autofocus: !0
        },
        ot = {
            trapElement: "element",
            autofocus: "boolean"
        },
        sn = ".bs.focustrap",
        He = "backward";
    class vt {
        constructor(t) {
            this._config = this._getConfig(t), this._isActive = !1, this._lastTabNavDirection = null
        }
        activate() {
            const {
                trapElement: t,
                autofocus: s
            } = this._config;
            this._isActive || (s && t.focus(), S.off(document, sn), S.on(document, "focusin.bs.focustrap", h => this._handleFocusin(h)), S.on(document, "keydown.tab.bs.focustrap", h => this._handleKeydown(h)), this._isActive = !0)
        }
        deactivate() {
            this._isActive && (this._isActive = !1, S.off(document, sn))
        }
        _handleFocusin(t) {
            const {
                target: s
            } = t, {
                trapElement: h
            } = this._config;
            if (s === document || s === h || h.contains(s)) return;
            const p = B.focusableChildren(h);
            0 === p.length ? h.focus() : this._lastTabNavDirection === He ? p[p.length - 1].focus() : p[0].focus()
        }
        _handleKeydown(t) {
            "Tab" === t.key && (this._lastTabNavDirection = t.shiftKey ? He : "forward")
        }
        _getConfig(t) {
            return t = { ...on,
                ..."object" == typeof t ? t : {}
            }, Ke("focustrap", t, ot), t
        }
    }
    const bi = {
            backdrop: !0,
            keyboard: !0,
            focus: !0
        },
        zt = {
            backdrop: "(boolean|string)",
            keyboard: "boolean",
            focus: "boolean"
        },
        zn = "hidden.bs.modal",
        ue = "show.bs.modal",
        Ot = "resize.bs.modal",
        Ei = "click.dismiss.bs.modal",
        Un = "keydown.dismiss.bs.modal",
        cr = "mousedown.dismiss.bs.modal",
        xn = "modal-open",
        Ti = "modal-static";
    class Ut extends Oe {
        constructor(t, s) {
            super(t), this._config = this._getConfig(s), this._dialog = B.findOne(".modal-dialog", this._element), this._backdrop = this._initializeBackDrop(), this._focustrap = this._initializeFocusTrap(), this._isShown = !1, this._ignoreBackdropClick = !1, this._isTransitioning = !1, this._scrollBar = new ce
        }
        static get Default() {
            return bi
        }
        static get NAME() {
            return "modal"
        }
        toggle(t) {
            return this._isShown ? this.hide() : this.show(t)
        }
        show(t) {
            this._isShown || this._isTransitioning || S.trigger(this._element, ue, {
                relatedTarget: t
            }).defaultPrevented || (this._isShown = !0, this._isAnimated() && (this._isTransitioning = !0), this._scrollBar.hide(), document.body.classList.add(xn), this._adjustDialog(), this._setEscapeEvent(), this._setResizeEvent(), S.on(this._dialog, cr, () => {
                S.one(this._element, "mouseup.dismiss.bs.modal", s => {
                    s.target === this._element && (this._ignoreBackdropClick = !0)
                })
            }), this._showBackdrop(() => this._showElement(t)))
        }
        hide() {
            if (!this._isShown || this._isTransitioning || S.trigger(this._element, "hide.bs.modal").defaultPrevented) return;
            this._isShown = !1;
            const t = this._isAnimated();
            t && (this._isTransitioning = !0), this._setEscapeEvent(), this._setResizeEvent(), this._focustrap.deactivate(), this._element.classList.remove("show"), S.off(this._element, Ei), S.off(this._dialog, cr), this._queueCallback(() => this._hideModal(), this._element, t)
        }
        dispose() {
            [window, this._dialog].forEach(t => S.off(t, ".bs.modal")), this._backdrop.dispose(), this._focustrap.deactivate(), super.dispose()
        }
        handleUpdate() {
            this._adjustDialog()
        }
        _initializeBackDrop() {
            return new rn({
                isVisible: !!this._config.backdrop,
                isAnimated: this._isAnimated()
            })
        }
        _initializeFocusTrap() {
            return new vt({
                trapElement: this._element
            })
        }
        _getConfig(t) {
            return t = { ...bi,
                ...we.getDataAttributes(this._element),
                ..."object" == typeof t ? t : {}
            }, Ke("modal", t, zt), t
        }
        _showElement(t) {
            const s = this._isAnimated(),
                h = B.findOne(".modal-body", this._dialog);
            this._element.parentNode && this._element.parentNode.nodeType === Node.ELEMENT_NODE || document.body.append(this._element), this._element.style.display = "block", this._element.removeAttribute("aria-hidden"), this._element.setAttribute("aria-modal", !0), this._element.setAttribute("role", "dialog"), this._element.scrollTop = 0, h && (h.scrollTop = 0), this._element.classList.add("show"), this._queueCallback(() => {
                this._config.focus && this._focustrap.activate(), this._isTransitioning = !1, S.trigger(this._element, "shown.bs.modal", {
                    relatedTarget: t
                })
            }, this._dialog, s)
        }
        _setEscapeEvent() {
            this._isShown ? S.on(this._element, Un, t => {
                this._config.keyboard && "Escape" === t.key ? (t.preventDefault(), this.hide()) : this._config.keyboard || "Escape" !== t.key || this._triggerBackdropTransition()
            }) : S.off(this._element, Un)
        }
        _setResizeEvent() {
            this._isShown ? S.on(window, Ot, () => this._adjustDialog()) : S.off(window, Ot)
        }
        _hideModal() {
            this._element.style.display = "none", this._element.setAttribute("aria-hidden", !0), this._element.removeAttribute("aria-modal"), this._element.removeAttribute("role"), this._isTransitioning = !1, this._backdrop.hide(() => {
                document.body.classList.remove(xn), this._resetAdjustments(), this._scrollBar.reset(), S.trigger(this._element, zn)
            })
        }
        _showBackdrop(t) {
            S.on(this._element, Ei, s => {
                this._ignoreBackdropClick ? this._ignoreBackdropClick = !1 : s.target === s.currentTarget && (!0 === this._config.backdrop ? this.hide() : "static" === this._config.backdrop && this._triggerBackdropTransition())
            }), this._backdrop.show(t)
        }
        _isAnimated() {
            return this._element.classList.contains("fade")
        }
        _triggerBackdropTransition() {
            if (S.trigger(this._element, "hidePrevented.bs.modal").defaultPrevented) return;
            const {
                classList: t,
                scrollHeight: s,
                style: h
            } = this._element, p = s > document.documentElement.clientHeight;
            !p && "hidden" === h.overflowY || t.contains(Ti) || (p || (h.overflowY = "hidden"), t.add(Ti), this._queueCallback(() => {
                t.remove(Ti), p || this._queueCallback(() => {
                    h.overflowY = ""
                }, this._dialog)
            }, this._dialog), this._element.focus())
        }
        _adjustDialog() {
            const t = this._element.scrollHeight > document.documentElement.clientHeight,
                s = this._scrollBar.getWidth(),
                h = s > 0;
            (!h && t && !De() || h && !t && De()) && (this._element.style.paddingLeft = `${s}px`), (h && !t && !De() || !h && t && De()) && (this._element.style.paddingRight = `${s}px`)
        }
        _resetAdjustments() {
            this._element.style.paddingLeft = "", this._element.style.paddingRight = ""
        }
        static jQueryInterface(t, s) {
            return this.each(function() {
                const h = Ut.getOrCreateInstance(this, t);
                if ("string" == typeof t) {
                    if (void 0 === h[t]) throw new TypeError(`No method named "${t}"`);
                    h[t](s)
                }
            })
        }
    }
    S.on(document, "click.bs.modal.data-api", '[data-bs-toggle="modal"]', function(c) {
        const t = J(this);
        ["A", "AREA"].includes(this.tagName) && c.preventDefault(), S.one(t, ue, h => {
            h.defaultPrevented || S.one(t, zn, () => {
                xt(this) && this.focus()
            })
        });
        const s = B.findOne(".modal.show");
        s && Ut.getInstance(s).hide(), Ut.getOrCreateInstance(t).toggle(this)
    }), Pt(Ut), Be(Ut);
    const hr = "offcanvas",
        fr = {
            backdrop: !0,
            keyboard: !0,
            scroll: !1
        },
        Xn = {
            backdrop: "boolean",
            keyboard: "boolean",
            scroll: "boolean"
        },
        pr = ".offcanvas.show",
        an = "hidden.bs.offcanvas";
    class Dt extends Oe {
        constructor(t, s) {
            super(t), this._config = this._getConfig(s), this._isShown = !1, this._backdrop = this._initializeBackDrop(), this._focustrap = this._initializeFocusTrap(), this._addEventListeners()
        }
        static get NAME() {
            return hr
        }
        static get Default() {
            return fr
        }
        toggle(t) {
            return this._isShown ? this.hide() : this.show(t)
        }
        show(t) {
            this._isShown || S.trigger(this._element, "show.bs.offcanvas", {
                relatedTarget: t
            }).defaultPrevented || (this._isShown = !0, this._element.style.visibility = "visible", this._backdrop.show(), this._config.scroll || (new ce).hide(), this._element.removeAttribute("aria-hidden"), this._element.setAttribute("aria-modal", !0), this._element.setAttribute("role", "dialog"), this._element.classList.add("show"), this._queueCallback(() => {
                this._config.scroll || this._focustrap.activate(), S.trigger(this._element, "shown.bs.offcanvas", {
                    relatedTarget: t
                })
            }, this._element, !0))
        }
        hide() {
            this._isShown && (S.trigger(this._element, "hide.bs.offcanvas").defaultPrevented || (this._focustrap.deactivate(), this._element.blur(), this._isShown = !1, this._element.classList.remove("show"), this._backdrop.hide(), this._queueCallback(() => {
                this._element.setAttribute("aria-hidden", !0), this._element.removeAttribute("aria-modal"), this._element.removeAttribute("role"), this._element.style.visibility = "hidden", this._config.scroll || (new ce).reset(), S.trigger(this._element, an)
            }, this._element, !0)))
        }
        dispose() {
            this._backdrop.dispose(), this._focustrap.deactivate(), super.dispose()
        }
        _getConfig(t) {
            return t = { ...fr,
                ...we.getDataAttributes(this._element),
                ..."object" == typeof t ? t : {}
            }, Ke(hr, t, Xn), t
        }
        _initializeBackDrop() {
            return new rn({
                className: "offcanvas-backdrop",
                isVisible: this._config.backdrop,
                isAnimated: !0,
                rootElement: this._element.parentNode,
                clickCallback: () => this.hide()
            })
        }
        _initializeFocusTrap() {
            return new vt({
                trapElement: this._element
            })
        }
        _addEventListeners() {
            S.on(this._element, "keydown.dismiss.bs.offcanvas", t => {
                this._config.keyboard && "Escape" === t.key && this.hide()
            })
        }
        static jQueryInterface(t) {
            return this.each(function() {
                const s = Dt.getOrCreateInstance(this, t);
                if ("string" == typeof t) {
                    if (void 0 === s[t] || t.startsWith("_") || "constructor" === t) throw new TypeError(`No method named "${t}"`);
                    s[t](this)
                }
            })
        }
    }
    S.on(document, "click.bs.offcanvas.data-api", '[data-bs-toggle="offcanvas"]', function(c) {
        const t = J(this);
        if (["A", "AREA"].includes(this.tagName) && c.preventDefault(), lt(this)) return;
        S.one(t, an, () => {
            xt(this) && this.focus()
        });
        const s = B.findOne(pr);
        s && s !== t && Dt.getInstance(s).hide(), Dt.getOrCreateInstance(t).toggle(this)
    }), S.on(window, "load.bs.offcanvas.data-api", () => B.find(pr).forEach(c => Dt.getOrCreateInstance(c).show())), Pt(Dt), Be(Dt);
    const Ci = new Set(["background", "cite", "href", "itemtype", "longdesc", "poster", "src", "xlink:href"]),
        _t = /^(?:(?:https?|mailto|ftp|tel|file|sms):|[^#&/:?]*(?:[#/?]|$))/i,
        wt = /^data:(?:image\/(?:bmp|gif|jpeg|jpg|png|tiff|webp)|video\/(?:mpeg|mp4|ogg|webm)|audio\/(?:mp3|oga|ogg|opus));base64,[\d+/a-z]+=*$/i,
        gr = (c, t) => {
            const s = c.nodeName.toLowerCase();
            if (t.includes(s)) return !Ci.has(s) || !(!_t.test(c.nodeValue) && !wt.test(c.nodeValue));
            const h = t.filter(p => p instanceof RegExp);
            for (let p = 0, m = h.length; p < m; p++)
                if (h[p].test(s)) return !0;
            return !1
        };

    function Ai(c, t, s) {
        if (!c.length) return c;
        if (s && "function" == typeof s) return s(c);
        const h = (new window.DOMParser).parseFromString(c, "text/html"),
            p = [].concat(...h.body.querySelectorAll("*"));
        for (let m = 0, x = p.length; m < x; m++) {
            const k = p[m],
                N = k.nodeName.toLowerCase();
            if (!Object.keys(t).includes(N)) {
                k.remove();
                continue
            }
            const P = [].concat(...k.attributes),
                q = [].concat(t["*"] || [], t[N] || []);
            P.forEach(L => {
                gr(L, q) || k.removeAttribute(L.nodeName)
            })
        }
        return h.body.innerHTML
    }
    const ki = "tooltip",
        Tr = new Set(["sanitize", "allowList", "sanitizeFn"]),
        pe = {
            animation: "boolean",
            template: "string",
            title: "(string|element|function)",
            trigger: "string",
            delay: "(number|object)",
            html: "boolean",
            selector: "(string|boolean)",
            placement: "(string|function)",
            offset: "(array|string|function)",
            container: "(string|element|boolean)",
            fallbackPlacements: "array",
            boundary: "(string|element)",
            customClass: "(string|function)",
            sanitize: "boolean",
            sanitizeFn: "(null|function)",
            allowList: "object",
            popperConfig: "(null|object|function)"
        },
        Si = {
            AUTO: "auto",
            TOP: "top",
            RIGHT: De() ? "left" : "right",
            BOTTOM: "bottom",
            LEFT: De() ? "right" : "left"
        },
        st = {
            animation: !0,
            template: '<div class="tooltip" role="tooltip"><div class="tooltip-arrow"></div><div class="tooltip-inner"></div></div>',
            trigger: "hover focus",
            title: "",
            delay: 0,
            html: !1,
            selector: !1,
            placement: "top",
            offset: [0, 0],
            container: !1,
            fallbackPlacements: ["top", "right", "bottom", "left"],
            boundary: "clippingParents",
            customClass: "",
            sanitize: !0,
            sanitizeFn: null,
            allowList: {
                "*": ["class", "dir", "id", "lang", "role", /^aria-[\w-]*$/i],
                a: ["target", "href", "title", "rel"],
                area: [],
                b: [],
                br: [],
                col: [],
                code: [],
                div: [],
                em: [],
                hr: [],
                h1: [],
                h2: [],
                h3: [],
                h4: [],
                h5: [],
                h6: [],
                i: [],
                img: ["src", "srcset", "alt", "title", "width", "height"],
                li: [],
                ol: [],
                p: [],
                pre: [],
                s: [],
                small: [],
                span: [],
                sub: [],
                sup: [],
                strong: [],
                u: [],
                ul: []
            },
            popperConfig: null
        },
        ct = {
            HIDE: "hide.bs.tooltip",
            HIDDEN: "hidden.bs.tooltip",
            SHOW: "show.bs.tooltip",
            SHOWN: "shown.bs.tooltip",
            INSERTED: "inserted.bs.tooltip",
            CLICK: "click.bs.tooltip",
            FOCUSIN: "focusin.bs.tooltip",
            FOCUSOUT: "focusout.bs.tooltip",
            MOUSEENTER: "mouseenter.bs.tooltip",
            MOUSELEAVE: "mouseleave.bs.tooltip"
        },
        ln = "fade",
        cn = "show",
        bn = "show",
        Di = ".tooltip-inner",
        Vn = "hide.bs.modal",
        En = "hover";
    class ut extends Oe {
        constructor(t, s) {
            if (void 0 === _i) throw new TypeError("Bootstrap's tooltips require Popper (https://popper.js.org)");
            super(t), this._isEnabled = !0, this._timeout = 0, this._hoverState = "", this._activeTrigger = {}, this._popper = null, this._config = this._getConfig(s), this.tip = null, this._setListeners()
        }
        static get Default() {
            return st
        }
        static get NAME() {
            return ki
        }
        static get Event() {
            return ct
        }
        static get DefaultType() {
            return pe
        }
        enable() {
            this._isEnabled = !0
        }
        disable() {
            this._isEnabled = !1
        }
        toggleEnabled() {
            this._isEnabled = !this._isEnabled
        }
        toggle(t) {
            if (this._isEnabled)
                if (t) {
                    const s = this._initializeOnDelegatedTarget(t);
                    s._activeTrigger.click = !s._activeTrigger.click, s._isWithActiveTrigger() ? s._enter(null, s) : s._leave(null, s)
                } else {
                    if (this.getTipElement().classList.contains(cn)) return void this._leave(null, this);
                    this._enter(null, this)
                }
        }
        dispose() {
            clearTimeout(this._timeout), S.off(this._element.closest(".modal"), Vn, this._hideModalHandler), this.tip && this.tip.remove(), this._disposePopper(), super.dispose()
        }
        show() {
            if ("none" === this._element.style.display) throw new Error("Please use show on visible elements");
            if (!this.isWithContent() || !this._isEnabled) return;
            const t = S.trigger(this._element, this.constructor.Event.SHOW),
                s = Gn(this._element),
                h = null === s ? this._element.ownerDocument.documentElement.contains(this._element) : s.contains(this._element);
            if (t.defaultPrevented || !h) return;
            "tooltip" === this.constructor.NAME && this.tip && this.getTitle() !== this.tip.querySelector(Di).innerHTML && (this._disposePopper(), this.tip.remove(), this.tip = null);
            const p = this.getTipElement(),
                m = (L => {
                    do {
                        L += Math.floor(1e6 * Math.random())
                    } while (document.getElementById(L));
                    return L
                })(this.constructor.NAME);
            p.setAttribute("id", m), this._element.setAttribute("aria-describedby", m), this._config.animation && p.classList.add(ln);
            const x = "function" == typeof this._config.placement ? this._config.placement.call(this, p, this._element) : this._config.placement,
                k = this._getAttachment(x);
            this._addAttachmentClass(k);
            const {
                container: N
            } = this._config;
            hn.set(p, this.constructor.DATA_KEY, this), this._element.ownerDocument.documentElement.contains(this.tip) || (N.append(p), S.trigger(this._element, this.constructor.Event.INSERTED)), this._popper ? this._popper.update() : this._popper = wn(this._element, p, this._getPopperConfig(k)), p.classList.add(cn);
            const P = this._resolvePossibleFunction(this._config.customClass);
            P && p.classList.add(...P.split(" ")), "ontouchstart" in document.documentElement && [].concat(...document.body.children).forEach(L => {
                S.on(L, "mouseover", Lt)
            });
            const q = this.tip.classList.contains(ln);
            this._queueCallback(() => {
                const L = this._hoverState;
                this._hoverState = null, S.trigger(this._element, this.constructor.Event.SHOWN), "out" === L && this._leave(null, this)
            }, this.tip, q)
        }
        hide() {
            if (!this._popper) return;
            const t = this.getTipElement();
            if (S.trigger(this._element, this.constructor.Event.HIDE).defaultPrevented) return;
            t.classList.remove(cn), "ontouchstart" in document.documentElement && [].concat(...document.body.children).forEach(h => S.off(h, "mouseover", Lt)), this._activeTrigger.click = !1, this._activeTrigger.focus = !1, this._activeTrigger.hover = !1;
            const s = this.tip.classList.contains(ln);
            this._queueCallback(() => {
                this._isWithActiveTrigger() || (this._hoverState !== bn && t.remove(), this._cleanTipClass(), this._element.removeAttribute("aria-describedby"), S.trigger(this._element, this.constructor.Event.HIDDEN), this._disposePopper())
            }, this.tip, s), this._hoverState = ""
        }
        update() {
            null !== this._popper && this._popper.update()
        }
        isWithContent() {
            return !!this.getTitle()
        }
        getTipElement() {
            if (this.tip) return this.tip;
            const t = document.createElement("div");
            t.innerHTML = this._config.template;
            const s = t.children[0];
            return this.setContent(s), s.classList.remove(ln, cn), this.tip = s, this.tip
        }
        setContent(t) {
            this._sanitizeAndSetContent(t, this.getTitle(), Di)
        }
        _sanitizeAndSetContent(t, s, h) {
            const p = B.findOne(h, t);
            s || !p ? this.setElementContent(p, s) : p.remove()
        }
        setElementContent(t, s) {
            if (null !== t) return Fe(s) ? (s = dt(s), void(this._config.html ? s.parentNode !== t && (t.innerHTML = "", t.append(s)) : t.textContent = s.textContent)) : void(this._config.html ? (this._config.sanitize && (s = Ai(s, this._config.allowList, this._config.sanitizeFn)), t.innerHTML = s) : t.textContent = s)
        }
        getTitle() {
            const t = this._element.getAttribute("data-bs-original-title") || this._config.title;
            return this._resolvePossibleFunction(t)
        }
        updateAttachment(t) {
            return "right" === t ? "end" : "left" === t ? "start" : t
        }
        _initializeOnDelegatedTarget(t, s) {
            return s || this.constructor.getOrCreateInstance(t.delegateTarget, this._getDelegateConfig())
        }
        _getOffset() {
            const {
                offset: t
            } = this._config;
            return "string" == typeof t ? t.split(",").map(s => Number.parseInt(s, 10)) : "function" == typeof t ? s => t(s, this._element) : t
        }
        _resolvePossibleFunction(t) {
            return "function" == typeof t ? t.call(this._element) : t
        }
        _getPopperConfig(t) {
            const s = {
                placement: t,
                modifiers: [{
                    name: "flip",
                    options: {
                        fallbackPlacements: this._config.fallbackPlacements
                    }
                }, {
                    name: "offset",
                    options: {
                        offset: this._getOffset()
                    }
                }, {
                    name: "preventOverflow",
                    options: {
                        boundary: this._config.boundary
                    }
                }, {
                    name: "arrow",
                    options: {
                        element: `.${this.constructor.NAME}-arrow`
                    }
                }, {
                    name: "onChange",
                    enabled: !0,
                    phase: "afterWrite",
                    fn: h => this._handlePopperPlacementChange(h)
                }],
                onFirstUpdate: h => {
                    h.options.placement !== h.placement && this._handlePopperPlacementChange(h)
                }
            };
            return { ...s,
                ..."function" == typeof this._config.popperConfig ? this._config.popperConfig(s) : this._config.popperConfig
            }
        }
        _addAttachmentClass(t) {
            this.getTipElement().classList.add(`${this._getBasicClassPrefix()}-${this.updateAttachment(t)}`)
        }
        _getAttachment(t) {
            return Si[t.toUpperCase()]
        }
        _setListeners() {
            this._config.trigger.split(" ").forEach(t => {
                if ("click" === t) S.on(this._element, this.constructor.Event.CLICK, this._config.selector, s => this.toggle(s));
                else if ("manual" !== t) {
                    const h = t === En ? this.constructor.Event.MOUSELEAVE : this.constructor.Event.FOCUSOUT;
                    S.on(this._element, t === En ? this.constructor.Event.MOUSEENTER : this.constructor.Event.FOCUSIN, this._config.selector, p => this._enter(p)), S.on(this._element, h, this._config.selector, p => this._leave(p))
                }
            }), this._hideModalHandler = () => {
                this._element && this.hide()
            }, S.on(this._element.closest(".modal"), Vn, this._hideModalHandler), this._config.selector ? this._config = { ...this._config,
                trigger: "manual",
                selector: ""
            } : this._fixTitle()
        }
        _fixTitle() {
            const t = this._element.getAttribute("title"),
                s = typeof this._element.getAttribute("data-bs-original-title");
            (t || "string" !== s) && (this._element.setAttribute("data-bs-original-title", t || ""), !t || this._element.getAttribute("aria-label") || this._element.textContent || this._element.setAttribute("aria-label", t), this._element.setAttribute("title", ""))
        }
        _enter(t, s) {
            s = this._initializeOnDelegatedTarget(t, s), t && (s._activeTrigger["focusin" === t.type ? "focus" : En] = !0), s.getTipElement().classList.contains(cn) || s._hoverState === bn ? s._hoverState = bn : (clearTimeout(s._timeout), s._hoverState = bn, s._config.delay && s._config.delay.show ? s._timeout = setTimeout(() => {
                s._hoverState === bn && s.show()
            }, s._config.delay.show) : s.show())
        }
        _leave(t, s) {
            s = this._initializeOnDelegatedTarget(t, s), t && (s._activeTrigger["focusout" === t.type ? "focus" : En] = s._element.contains(t.relatedTarget)), s._isWithActiveTrigger() || (clearTimeout(s._timeout), s._hoverState = "out", s._config.delay && s._config.delay.hide ? s._timeout = setTimeout(() => {
                "out" === s._hoverState && s.hide()
            }, s._config.delay.hide) : s.hide())
        }
        _isWithActiveTrigger() {
            for (const t in this._activeTrigger)
                if (this._activeTrigger[t]) return !0;
            return !1
        }
        _getConfig(t) {
            const s = we.getDataAttributes(this._element);
            return Object.keys(s).forEach(h => {
                Tr.has(h) && delete s[h]
            }), (t = { ...this.constructor.Default,
                ...s,
                ..."object" == typeof t && t ? t : {}
            }).container = !1 === t.container ? document.body : dt(t.container), "number" == typeof t.delay && (t.delay = {
                show: t.delay,
                hide: t.delay
            }), "number" == typeof t.title && (t.title = t.title.toString()), "number" == typeof t.content && (t.content = t.content.toString()), Ke(ki, t, this.constructor.DefaultType), t.sanitize && (t.template = Ai(t.template, t.allowList, t.sanitizeFn)), t
        }
        _getDelegateConfig() {
            const t = {};
            for (const s in this._config) this.constructor.Default[s] !== this._config[s] && (t[s] = this._config[s]);
            return t
        }
        _cleanTipClass() {
            const t = this.getTipElement(),
                s = new RegExp(`(^|\\s)${this._getBasicClassPrefix()}\\S+`, "g"),
                h = t.getAttribute("class").match(s);
            null !== h && h.length > 0 && h.map(p => p.trim()).forEach(p => t.classList.remove(p))
        }
        _getBasicClassPrefix() {
            return "bs-tooltip"
        }
        _handlePopperPlacementChange(t) {
            const {
                state: s
            } = t;
            s && (this.tip = s.elements.popper, this._cleanTipClass(), this._addAttachmentClass(this._getAttachment(s.placement)))
        }
        _disposePopper() {
            this._popper && (this._popper.destroy(), this._popper = null)
        }
        static jQueryInterface(t) {
            return this.each(function() {
                const s = ut.getOrCreateInstance(this, t);
                if ("string" == typeof t) {
                    if (void 0 === s[t]) throw new TypeError(`No method named "${t}"`);
                    s[t]()
                }
            })
        }
    }
    Be(ut);
    const Ni = { ...ut.Default,
            placement: "right",
            offset: [0, 8],
            trigger: "click",
            content: "",
            template: '<div class="popover" role="tooltip"><div class="popover-arrow"></div><h3 class="popover-header"></h3><div class="popover-body"></div></div>'
        },
        Cr = { ...ut.DefaultType,
            content: "(string|element|function)"
        },
        Yn = {
            HIDE: "hide.bs.popover",
            HIDDEN: "hidden.bs.popover",
            SHOW: "show.bs.popover",
            SHOWN: "shown.bs.popover",
            INSERTED: "inserted.bs.popover",
            CLICK: "click.bs.popover",
            FOCUSIN: "focusin.bs.popover",
            FOCUSOUT: "focusout.bs.popover",
            MOUSEENTER: "mouseenter.bs.popover",
            MOUSELEAVE: "mouseleave.bs.popover"
        };
    class un extends ut {
        static get Default() {
            return Ni
        }
        static get NAME() {
            return "popover"
        }
        static get Event() {
            return Yn
        }
        static get DefaultType() {
            return Cr
        }
        isWithContent() {
            return this.getTitle() || this._getContent()
        }
        setContent(t) {
            this._sanitizeAndSetContent(t, this.getTitle(), ".popover-header"), this._sanitizeAndSetContent(t, this._getContent(), ".popover-body")
        }
        _getContent() {
            return this._resolvePossibleFunction(this._config.content)
        }
        _getBasicClassPrefix() {
            return "bs-popover"
        }
        static jQueryInterface(t) {
            return this.each(function() {
                const s = un.getOrCreateInstance(this, t);
                if ("string" == typeof t) {
                    if (void 0 === s[t]) throw new TypeError(`No method named "${t}"`);
                    s[t]()
                }
            })
        }
    }
    Be(un);
    const Kn = "scrollspy",
        mr = {
            offset: 10,
            method: "auto",
            target: ""
        },
        f = {
            offset: "number",
            method: "string",
            target: "(string|element)"
        },
        d = "active",
        y = ".nav-link, .list-group-item, .dropdown-item",
        E = "position";
    class _ extends Oe {
        constructor(t, s) {
            super(t), this._scrollElement = "BODY" === this._element.tagName ? window : this._element, this._config = this._getConfig(s), this._offsets = [], this._targets = [], this._activeTarget = null, this._scrollHeight = 0, S.on(this._scrollElement, "scroll.bs.scrollspy", () => this._process()), this.refresh(), this._process()
        }
        static get Default() {
            return mr
        }
        static get NAME() {
            return Kn
        }
        refresh() {
            const s = "auto" === this._config.method ? this._scrollElement === this._scrollElement.window ? "offset" : E : this._config.method,
                h = s === E ? this._getScrollTop() : 0;
            this._offsets = [], this._targets = [], this._scrollHeight = this._getScrollHeight(), B.find(y, this._config.target).map(p => {
                const m = Ye(p),
                    x = m ? B.findOne(m) : null;
                if (x) {
                    const k = x.getBoundingClientRect();
                    if (k.width || k.height) return [we[s](x).top + h, m]
                }
                return null
            }).filter(p => p).sort((p, m) => p[0] - m[0]).forEach(p => {
                this._offsets.push(p[0]), this._targets.push(p[1])
            })
        }
        dispose() {
            S.off(this._scrollElement, ".bs.scrollspy"), super.dispose()
        }
        _getConfig(t) {
            return (t = { ...mr,
                ...we.getDataAttributes(this._element),
                ..."object" == typeof t && t ? t : {}
            }).target = dt(t.target) || document.documentElement, Ke(Kn, t, f), t
        }
        _getScrollTop() {
            return this._scrollElement === window ? this._scrollElement.pageYOffset : this._scrollElement.scrollTop
        }
        _getScrollHeight() {
            return this._scrollElement.scrollHeight || Math.max(document.body.scrollHeight, document.documentElement.scrollHeight)
        }
        _getOffsetHeight() {
            return this._scrollElement === window ? window.innerHeight : this._scrollElement.getBoundingClientRect().height
        }
        _process() {
            const t = this._getScrollTop() + this._config.offset,
                s = this._getScrollHeight(),
                h = this._config.offset + s - this._getOffsetHeight();
            if (this._scrollHeight !== s && this.refresh(), t >= h) {
                const p = this._targets[this._targets.length - 1];
                this._activeTarget !== p && this._activate(p)
            } else {
                if (this._activeTarget && t < this._offsets[0] && this._offsets[0] > 0) return this._activeTarget = null, void this._clear();
                for (let p = this._offsets.length; p--;) this._activeTarget !== this._targets[p] && t >= this._offsets[p] && (void 0 === this._offsets[p + 1] || t < this._offsets[p + 1]) && this._activate(this._targets[p])
            }
        }
        _activate(t) {
            this._activeTarget = t, this._clear();
            const s = y.split(",").map(p => `${p}[data-bs-target="${t}"],${p}[href="${t}"]`),
                h = B.findOne(s.join(","), this._config.target);
            h.classList.add(d), h.classList.contains("dropdown-item") ? B.findOne(".dropdown-toggle", h.closest(".dropdown")).classList.add(d) : B.parents(h, ".nav, .list-group").forEach(p => {
                B.prev(p, ".nav-link, .list-group-item").forEach(m => m.classList.add(d)), B.prev(p, ".nav-item").forEach(m => {
                    B.children(m, ".nav-link").forEach(x => x.classList.add(d))
                })
            }), S.trigger(this._scrollElement, "activate.bs.scrollspy", {
                relatedTarget: t
            })
        }
        _clear() {
            B.find(y, this._config.target).filter(t => t.classList.contains(d)).forEach(t => t.classList.remove(d))
        }
        static jQueryInterface(t) {
            return this.each(function() {
                const s = _.getOrCreateInstance(this, t);
                if ("string" == typeof t) {
                    if (void 0 === s[t]) throw new TypeError(`No method named "${t}"`);
                    s[t]()
                }
            })
        }
    }
    S.on(window, "load.bs.scrollspy.data-api", () => {
        B.find('[data-bs-spy="scroll"]').forEach(c => new _(c))
    }), Be(_);
    const C = "active",
        O = "fade",
        j = "show",
        I = ".active",
        V = ":scope > li > .active";
    class H extends Oe {
        static get NAME() {
            return "tab"
        }
        show() {
            if (this._element.parentNode && this._element.parentNode.nodeType === Node.ELEMENT_NODE && this._element.classList.contains(C)) return;
            let t;
            const s = J(this._element),
                h = this._element.closest(".nav, .list-group");
            h && (t = B.find("UL" === h.nodeName || "OL" === h.nodeName ? V : I, h), t = t[t.length - 1]);
            const p = t ? S.trigger(t, "hide.bs.tab", {
                relatedTarget: this._element
            }) : null;
            if (S.trigger(this._element, "show.bs.tab", {
                    relatedTarget: t
                }).defaultPrevented || null !== p && p.defaultPrevented) return;
            this._activate(this._element, h);
            const m = () => {
                S.trigger(t, "hidden.bs.tab", {
                    relatedTarget: this._element
                }), S.trigger(this._element, "shown.bs.tab", {
                    relatedTarget: t
                })
            };
            s ? this._activate(s, s.parentNode, m) : m()
        }
        _activate(t, s, h) {
            const p = (!s || "UL" !== s.nodeName && "OL" !== s.nodeName ? B.children(s, I) : B.find(V, s))[0],
                m = h && p && p.classList.contains(O),
                x = () => this._transitionComplete(t, p, h);
            p && m ? (p.classList.remove(j), this._queueCallback(x, t, !0)) : x()
        }
        _transitionComplete(t, s, h) {
            if (s) {
                s.classList.remove(C);
                const m = B.findOne(":scope > .dropdown-menu .active", s.parentNode);
                m && m.classList.remove(C), "tab" === s.getAttribute("role") && s.setAttribute("aria-selected", !1)
            }
            t.classList.add(C), "tab" === t.getAttribute("role") && t.setAttribute("aria-selected", !0), t.classList.contains(O) && t.classList.add(j);
            let p = t.parentNode;
            if (p && "LI" === p.nodeName && (p = p.parentNode), p && p.classList.contains("dropdown-menu")) {
                const m = t.closest(".dropdown");
                m && B.find(".dropdown-toggle", m).forEach(x => x.classList.add(C)), t.setAttribute("aria-expanded", !0)
            }
            h && h()
        }
        static jQueryInterface(t) {
            return this.each(function() {
                const s = H.getOrCreateInstance(this);
                if ("string" == typeof t) {
                    if (void 0 === s[t]) throw new TypeError(`No method named "${t}"`);
                    s[t]()
                }
            })
        }
    }
    S.on(document, "click.bs.tab.data-api", '[data-bs-toggle="tab"], [data-bs-toggle="pill"], [data-bs-toggle="list"]', function(c) {
        ["A", "AREA"].includes(this.tagName) && c.preventDefault(), lt(this) || H.getOrCreateInstance(this).show()
    }), Be(H);
    const $ = "toast",
        Z = "hide",
        se = "show",
        R = "showing",
        Ee = {
            animation: "boolean",
            autohide: "boolean",
            delay: "number"
        },
        ke = {
            animation: !0,
            autohide: !0,
            delay: 5e3
        };
    class Se extends Oe {
        constructor(t, s) {
            super(t), this._config = this._getConfig(s), this._timeout = null, this._hasMouseInteraction = !1, this._hasKeyboardInteraction = !1, this._setListeners()
        }
        static get DefaultType() {
            return Ee
        }
        static get Default() {
            return ke
        }
        static get NAME() {
            return $
        }
        show() {
            S.trigger(this._element, "show.bs.toast").defaultPrevented || (this._clearTimeout(), this._config.animation && this._element.classList.add("fade"), this._element.classList.remove(Z), this._element.classList.add(se), this._element.classList.add(R), this._queueCallback(() => {
                this._element.classList.remove(R), S.trigger(this._element, "shown.bs.toast"), this._maybeScheduleHide()
            }, this._element, this._config.animation))
        }
        hide() {
            this._element.classList.contains(se) && (S.trigger(this._element, "hide.bs.toast").defaultPrevented || (this._element.classList.add(R), this._queueCallback(() => {
                this._element.classList.add(Z), this._element.classList.remove(R), this._element.classList.remove(se), S.trigger(this._element, "hidden.bs.toast")
            }, this._element, this._config.animation)))
        }
        dispose() {
            this._clearTimeout(), this._element.classList.contains(se) && this._element.classList.remove(se), super.dispose()
        }
        _getConfig(t) {
            return t = { ...ke,
                ...we.getDataAttributes(this._element),
                ..."object" == typeof t && t ? t : {}
            }, Ke($, t, this.constructor.DefaultType), t
        }
        _maybeScheduleHide() {
            this._config.autohide && (this._hasMouseInteraction || this._hasKeyboardInteraction || (this._timeout = setTimeout(() => {
                this.hide()
            }, this._config.delay)))
        }
        _onInteraction(t, s) {
            switch (t.type) {
                case "mouseover":
                case "mouseout":
                    this._hasMouseInteraction = s;
                    break;
                case "focusin":
                case "focusout":
                    this._hasKeyboardInteraction = s
            }
            if (s) return void this._clearTimeout();
            const h = t.relatedTarget;
            this._element === h || this._element.contains(h) || this._maybeScheduleHide()
        }
        _setListeners() {
            S.on(this._element, "mouseover.bs.toast", t => this._onInteraction(t, !0)), S.on(this._element, "mouseout.bs.toast", t => this._onInteraction(t, !1)), S.on(this._element, "focusin.bs.toast", t => this._onInteraction(t, !0)), S.on(this._element, "focusout.bs.toast", t => this._onInteraction(t, !1))
        }
        _clearTimeout() {
            clearTimeout(this._timeout), this._timeout = null
        }
        static jQueryInterface(t) {
            return this.each(function() {
                const s = Se.getOrCreateInstance(this, t);
                if ("string" == typeof t) {
                    if (void 0 === s[t]) throw new TypeError(`No method named "${t}"`);
                    s[t](this)
                }
            })
        }
    }
    return Pt(Se), Be(Se), {
        Alert: Yt,
        Button: qt,
        Carousel: Ze,
        Collapse: Ct,
        Dropdown: oe,
        Modal: Ut,
        Offcanvas: Dt,
        Popover: un,
        ScrollSpy: _,
        Tab: H,
        Toast: Se,
        Tooltip: ut
    }
});